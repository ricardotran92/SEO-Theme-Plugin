<?php

namespace Yoast\WP\SEO\Premium\Exceptions\Remote_Request;

/**
 * Class to manage a 503 - service unavailable response.
 */
class Service_Unavailable_Exception extends Remote_Request_Exception {

}
