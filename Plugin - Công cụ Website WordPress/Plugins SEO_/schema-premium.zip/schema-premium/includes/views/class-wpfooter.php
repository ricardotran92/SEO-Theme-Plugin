<?php
/**
 * @package Schema Premium - Class Schema WPFooter
 * @category Core
 * @author Hesham Zebida
 * @version 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
	
if ( ! class_exists('Schema_WP_WPFooter') ) :
	/**
	 * Schema WPFooter
	 *
	 * @since 1.0.0
	 */
	class Schema_WP_WPFooter {
		
		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			$this->init();
		}
	
		/**
		* Init
		*
		* @since 1.0.0
	 	*/
		public function init() {
			
			add_action( 'schema_output_after_after', array( $this, 'output_markup' ), 30 );

			add_filter( 'schema_WebPage_hasPart', array( $this, 'add_markup' ), 30 );
		}
		
		/**
		* Get markup output
		*
		* @since 1.0.0
		* @return array
		*/
		public function output_markup() {
			
			// Filter this and return false to disable the function
			//
			$enabled = apply_filters( 'schema_wp_output_wpfooter_enabled', true );
			//
			if ( ! $enabled )
				return;
			
			// Check if markup type is set to Combines in plugin settings
			// @since 1.2.3 
			//
			$schema_output_type = schema_wp_get_option('schema_output_type');
			//
			if ( isset($schema_output_type) && $schema_output_type == 'combined' ) 
				return;

			// Check if enabled
			//
			$enabled = schema_wp_get_option( 'wpfooter_enable' );
			//
			if ( isset($enabled) && $enabled == 'enabled' ) {	
				// Add action to hook to this function
				do_action( 'schema_wp_action_wpfooter' );
				
				$markup = new Schema_WP_Output();
				$markup->json_output( $this->get_markup() );
			}
		}
		
		/**
		* Add markup
		*
		* @since 1.2.3
		* @return array
		*/
		public function add_markup( $schema ) {

			// Check if enabled
			//
			$enabled = schema_wp_get_option( 'wpfooter_enable' );
			//
			if ( isset($enabled) && $enabled == 'enabled' ) {	

				$schema[] = $this->get_markup();
			}

			return $schema;
		}

		/**
		* Get markup
		*
		* @since 1.0.0
		* @return array
		*/
		public function get_markup() {
			
			global $wp_query;
			
			// Get post type
			//
			$post_type 		= get_post_type();
			
			// Set defaults
			//
			$headline  		= wp_filter_nohtml_kses( get_the_title() );
			$description 	= get_bloginfo( 'description' );
			$url			= get_bloginfo( 'url' );
			
			if ( is_single() || is_singular() ) {
				
				// Single and singular pages
				//

				// Get enabled post types
				//
				$schema_enabled = schema_wp_cpt_get_enabled_post_types();
				
				if ( in_array( $post_type, $schema_enabled ) ) {
					 	
					// Single and singular pages
					//
					$headline 		= wp_filter_nohtml_kses( get_the_title() );
					$description 	= schema_wp_get_description();
					$url			= get_permalink();
				}

			} elseif ( is_404() ) {
				
				// 404
				//
				$headline		= __( 'Page not found', 'schema-premium' );
				$description 	= __('It looks like nothing was found at this location!', 'schema-premium');
				$url			= '';
			
			} elseif ( is_front_page() && is_home() ) {
				
				// Default homepage
				//
				$headline 		= get_bloginfo( 'name' );
				$description 	= get_bloginfo( 'description' );
				$url			= get_bloginfo( 'url' );
			
			} elseif ( is_front_page() ) {
				
				// Static homepage
				//
				$headline 		= get_bloginfo( 'name' );
				$description 	= get_bloginfo( 'description' );
				$url			= get_bloginfo( 'url' );
			
			} elseif ( is_home() ) {
				
				// Blog page
				//
				$headline 		= get_bloginfo( 'name' );
				$description 	= get_bloginfo( 'description' );
				$url			= schema_wp_get_blog_posts_page_url();
			
			} elseif ( is_archive() ) {
				
				// Archive pages
				//
				$headline 		= get_the_archive_title();
				$description 	= get_the_archive_description();
				$url			= '';

			} elseif ( is_post_type_archive() ) {
				
				// Post type archive pages
				//
				$headline 	 	= post_type_archive_title( __(''), false );
				$obj 		 	= get_post_type_object($post_type);
				$description 	= isset($obj->description) ? $obj->description : '';
				$url			= schema_premium_get_archive_link($post_type) ? schema_premium_get_archive_link($post_type) : get_home_url();

			} elseif ( is_search() ) {
				
				// Search
				//
				$query			= get_search_query();
				$headline 		= sprintf( __( 'Search Results for &#8220;%s&#8221;' ), $query );
				$url			= get_search_link( $query );
				$description	= $wp_query->found_posts.' search results found for "'.$query.'".';
			
			}
			
			/*
			*	WPHeader
			*/
			$footer = array(
				'@context' 		=> 'https://schema.org/',
				'@type'			=> 'WPFooter',
				'url'			=> $url,
				'headline'		=> wp_strip_all_tags($headline),
				'description'	=> wp_trim_words( wp_strip_all_tags($description), 18, '...' ),
			);
	
			// Add copyrightYear to Footer singulars
			if (is_singular() ) {
				$footer['copyrightYear'] = 	get_the_date('Y');
			}
	
			return apply_filters( 'schema_wpfooter_output', $footer );
		}
	}
	
	new Schema_WP_WPFooter();
	
endif;
