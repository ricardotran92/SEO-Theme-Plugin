<?php
/**
 * @package 	Schema Premium - Class Schema WPHeader
 * @category 	Core
 * @author 		Hesham Zebida
 * @version 	1.0.0
 * @since 		1.2.3
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
	
if ( ! class_exists('Schema_WP_SiteNavigationElement') ) :
	/**
	 * Schema WPHeader
	 *
	 * @since 1.0.0
	 */
	class Schema_WP_SiteNavigationElement {
		
		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			$this->init();
		}
	
		/**
		* Init
		*
		* @since 1.0.0
	 	*/
		public function init() {

			add_action( 'schema_output_before_before', array( $this, 'output_markup' ), 20 );

			add_filter( 'schema_WebPage_hasPart', array( $this, 'add_markup' ), 20 );
			
		}
		
		/**
		* Get markup output
		*
		* @since 1.0.0
		* @return array
		*/
		public function output_markup() {
			
			// Filter this and return false to disable the function
			$enabled = apply_filters( 'schema_wp_output_site_nav_element_enabled', true );
			//
			if ( ! $enabled )
				return;
			
			// Check if markup type is set to Combines in plugin settings
			// @since 1.2.3 
			//
			$schema_output_type = schema_wp_get_option('schema_output_type');
			//
			if ( isset($schema_output_type) && $schema_output_type == 'combined' ) 
				return;

			// Check if enabled
			//
			$enabled = schema_wp_get_option( 'site_nav_element_enable' );
			//
			if ( isset($enabled) && $enabled == 'enabled' ) {		
				// Add action to hook to this function
				do_action( 'schema_wp_action_site_nav_element' );
				
				$markup = new Schema_WP_Output();
				$markup->json_output( $this->get_markup() );
			}
		}

		/**
		* Add markup
		*
		* @since 1.0.0
		* @return array
		*/
		public function add_markup( $schema ) {
			
			// Check if enabled
			//
			$enabled = schema_wp_get_option( 'site_nav_element_enable' );
			//
			if ( isset($enabled) && $enabled == 'enabled' ) {	

				$schema[] = $this->get_markup();
			}

			return $schema;
		}

		/**
		* Get markup
		*
		* @since 1.0.0
		* @return array
		*/
		public function get_markup() {

			// Check if enabled
			//
			$enabled = schema_wp_get_option( 'site_nav_element_enable' );
			//
			if ( isset($enabled) && $enabled == 'enabled' ) {	

				$menu = schema_wp_get_option( 'site_nav_element_menu' );

				if ( isset( $menu )  ) {
					
					$site_nav = get_transient( 'schema_site_nav_element' );

					if ( false === $site_nav ) {

						$items_array = wp_get_nav_menu_items( $menu );
						
						if ( $items_array ) {
							
							$name_array  = array();
							$url_array   = array();
				
							foreach ( (array) $items_array as $key => $menu_item ) {
								$url_array[]  = $menu_item->url;
								$name_array[] = $menu_item->title;
							}
				
							if ( count( $items_array ) > 0 ) {
								$site_nav = array(
									"@context" => "https://schema.org",
									"@type"    => "SiteNavigationElement",
									"name"     => $name_array,
									"url"      => $url_array
								);
								//return (array) $args;

								set_transient( 'schema_site_nav_element', $site_nav,  24 * HOUR_IN_SECONDS );
							}
						}
					
					}

					return apply_filters( 'schema_SiteNavigationElement_output', (array) $site_nav );
				}
			}
		}


	}
	
	new Schema_WP_SiteNavigationElement();
	
endif;
