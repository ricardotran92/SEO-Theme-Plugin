<?php
/**
 * @package 	Schema Premium - Extension : Combined, to combine schema.org types that is enabled on same entry
 * @category 	Core
 * @author 		Hesham Zebida
 * @version 	1.0 
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


if ( ! class_exists('Schema_Premium_Combined_Markup') ) :
	/**
	 * Class
	 *
	 * @since 1.0.0
	 */
	class Schema_Premium_Combined_Markup {
		
		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			$this->init();
		}
	
		/**
		* Init
		*
		* @since 1.0.0
	 	*/
		public function init() {
		
			add_filter( 'schema_singular_output', 			array( $this, 'combined_markup' ), 99 );
			add_filter( 'schema_output_Blog', 				array( $this, 'combined_markup' ), 99 );
			add_filter( 'schema_terms_output', 				array( $this, 'combined_markup' ), 99 );
			add_filter( 'schema_post_type_archive_output', 	array( $this, 'combined_markup' ), 99 );
			add_filter( 'schema_author_archive_output', 	array( $this, 'combined_markup' ), 99 );
			
			add_filter( 'schema_combined_markup', 			array( $this, 'speakable' ) );
		}
		
		/**
		* Graph
		*
		* @since 1.0.0
		* @return string
		*/
		public function combined_markup( $schemas ) {
			
			//echo'<pre>';print_r($schemas);echo'</pre>';exit;
			
			// Check if markup type is set to Combines in plugin settings
			//
			$schema_output_type = schema_wp_get_option('schema_output_type');
			//
			if ( $schema_output_type != 'combined' ) 
				return $schemas;
			
			// Define variables
			//
			$types	= array();
			$markup = array();

			// Combine multiple schema.org types 
			//
			if ( isset($schemas) && is_array($schemas) && ! empty($schemas)) {

				// is_admin
				//
				if ( is_admin() ) {

					foreach ( $schemas as $key => $schema ) {
						if ( is_array($schema) ) {
							$types[] = $schema['@type'];
							$markup = array_merge($schema, $markup);
						}
					}
					
					$markup['@type'] = $types;

					return $markup;
				}

				// Single post
				//
				if ( is_singular() && ! is_home() && ! is_front_page() ) {

					//$schemas = array_reverse($schemas);

					foreach ( $schemas as $key => $schema ) {
						if ( is_array($schema) && isset($schema['@type']) ) {
							$types[] = $schema['@type'];
							$markup = array_merge($schema, $markup);
						}
					}
					
					$markup['@type'] = $types;
				}

				// Front Static Page
				//
				if ( is_front_page() && 'page' == get_option('show_on_front') ) {
					
					foreach ( $schemas as $key => $schema ) {
						if ( is_array($schema) ) {
							$types[] = $schema['@type'];
							$markup = array_merge($schema, $markup);
						}
					}
					
					$markup['@type'] = $types;
				}
				
				// Archives
				//
				if ( is_archive() || is_post_type_archive() || is_author() || schema_wp_is_blog() ) {
					
					$markup = $schemas;
				}

				// Add mainEntityOfPage
				//
				$markup['mainEntityOfPage'] = $this->WebPage( $markup );
			}
			
			// Return final output
			//
			return apply_filters( 'schema_combined_markup', $markup );
		}

		/**
		* WebPage
		*
		* @since 1.0.0
		* @return array
		*/
		public function WebPage( $schema ) {
			
			global $post;

			if ( ! isset($post->ID) ) {
				$post_id = schema_premium_get_post_ID();
				$post = get_post($post_id);
			}
			
			// Debug
			//echo'<pre>';print_r($schema);echo'</pre>';

			if ( isset($schema['name']) && $schema['name'] != '' ) {
				$name = $schema['name'];
			} else {
				$name = isset($schema['headline']) ? $schema['headline'] : '';
			}

			if ( isset($schema['url']) && $schema['url'] != '' ) {
				$url = $schema['url'];
			} else {
				global $wp;
				$url = home_url( add_query_arg( array(), $wp->request ) );
			}

			// WebPage markup
			//
			$WebPage = array(
				'@type' => 'WebPage',
				'@id'	=> $url . '#webpage',
				'url'	=> $url,
				'name'	=> $name 
			);

			// Single posts
			//
			if ( is_singular() && ! is_home() && ! is_front_page() ) {

				$WebPage['@type'] = array( 'WebPage', 'ItemPage' );
			}

			// Author archive
			//
			if ( is_author() ) {
					
				$name	= isset($schema['name']) ? $schema['name'] : $schema['headline'];
				$url  	= isset($schema['url']) ? $schema['url'] : esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );
				
				$WebPage['@type']	= array( 'WebPage', 'ItemPage' );
				$WebPage['@id'] 	= $url . '#webpage';
				$WebPage['url'] 	= $url;
				$WebPage['name']	= $name;
			}

			// @type == 'Person'
			//
			if ( isset($schema['@type']) && $schema['@type'] == 'Person' ) {
					
				$WebPage['@type'] = array( 'WebPage', 'ProfilePage' );
			}

			// Home & Front Page
			//
			if ( is_home() && is_front_page() ) {
					
				$url = get_home_url();

				$WebPage['@id']	= $url . '#webpage';
				$WebPage['url']	= $url;
			}

			if ( isset($schema['description']) ) {
				$WebPage['description'] = $schema['description'];
			}
			
			if ( function_exists('get_locale') ) {
				$WebPage['inLanguage'] = get_locale(); //'en-US',
			}

			if ( isset($post->ID) ) {

				$WebPage['datePublished'] 	= isset($schema['datePublished']) ? $schema['datePublished'] : get_the_date( 'c', $post->ID );
				$WebPage['dateModified'] 	= isset($schema['dateModified']) ? $schema['dateModified'] : get_the_date( 'c', $post->ID );
				
				$WebPage['lastReviewed'] 	= isset($schema['dateModified']) ? $schema['dateModified'] : get_the_date( 'c', $post->ID );
				$WebPage['reviewedBy'] 		= isset($schema['author']) ? $schema['author'] : schema_wp_get_author_array( $post->ID );
			
			}

			// Primary Image Of Page
			//
			if ( isset($schema['image']) && ! empty($schema['image']) ) {
				$WebPage['primaryImageOfPage'] = $schema['image'];
			}

			// Breadcrumb
			//
			$breadcrumb = $this->breadcrumb($post->ID);
			//
			if ( ! empty($breadcrumb) ) {
				$WebPage['breadcrumb'] = $breadcrumb;
			}
			
			// SiteLinks Search Box
			//
			$Website = schema_premium_get_sitelinks_search_box_markup();
			//
			if ( ! empty($Website) ) {
				$WebPage['isPartOf'] = $Website;
			}

			// hasPart
			//
			$hasPart = apply_filters('schema_WebPage_hasPart', array() );
			//
			if ( ! empty($hasPart) ) {
				$WebPage['hasPart'] = $hasPart;
			}
			
			/*
			if ( is_front_page() && 'page' == get_option('show_on_front') ) {
				$url = get_home_url();
			} elseif ( is_author() ) {
				$url = esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );
			} else {
				$url = isset($schema['url']) ? $schema['url'] : '';
			}
			*/

			$WebPage['potentialAction'] = array(
				'@type'	 => 'ReadAction',
				'target' => array(
					'@type'			=> 'EntryPoint',
					'urlTemplate'	=> $url
				)
			);
			
			/*
			// WebPage markup
			//
			$WebPage = array(
				'@type' 				=> 'WebPage',
				'@id'					=> $schema['url'] . '#webpage',
				'url'					=> $schema['url'],
				'name'					=> $name,
				'datePublished'			=> isset($schema['datePublished']) ?: get_the_date( 'c', $post->ID ),
				'dateModified'			=> isset($schema['dateModified']) ?: get_post_modified_time( 'c', false, $post->ID, false ),
				'lastReviewed'			=> isset($schema['dateModified']) ?: get_post_modified_time( 'c', false, $post->ID, false ),
				'reviewedBy'			=> isset($schema['author']) ?: schema_wp_get_author_array( $post->ID ),
				'description'			=> $schema['description'],
				'inLanguage'			=> get_locale(), //'en-US',
				'isPartOf'				=> $Website,
				'primaryImageOfPage'	=> $primaryImageOfPage,
				'potentialAction'		=> array(
					'@type'	 => 'ReadAction',
					'target' => array(
						'@type'			=> 'EntryPoint',
						'urlTemplate'	=> $schema['url']
					)
				)
			);
			*/

			return apply_filters( 'schema_WebPage', $WebPage );
		}

		/**
		* Breadcrumbs
		*
		* @since 	1.0.0
		* @return 	string
		*/
		public function breadcrumb( $post_id = null ) {
			
			if ( class_exists('SCHEMA_WP_Breadcrumbs') ) {

				$breadcrumb_enabled = schema_wp_get_option( 'breadcrumbs_enable' );

				if ( isset($breadcrumb_enabled) && $breadcrumb_enabled == 'enabled' ) {
					
					$breadcrumbs = SCHEMA_WP_Breadcrumbs::instance();
					$breadcrumb  = $breadcrumbs->get_crumbs($post_id);

					if ( ! empty($breadcrumb) ) {
						return $breadcrumb;
					}	
				}
			}
		}

		/**
		* Speakable
		*
		* @since 1.0.0
		* @return string
		*/
		public function speakable( $schema ) {
			
			if ( empty($schema) ) return;
		
			$speakable_enabled = schema_wp_get_option( 'speakable_enabled' );

			if ( isset($speakable_enabled) && $speakable_enabled == 'enabled' ) {
				
				$speakable = schema_premium_get_speakable();
			
				if ( ! empty( $speakable ) ) {
					$schema['mainEntityOfPage']['speakable'] = $speakable;
				}
			}
	
			return $schema;
		}

	}

	$schema_combined_markup = new Schema_Premium_Combined_Markup();

endif;
