<?php
/**
 *  SEO extention
 *
 *  Adds SEO features
 * 
 *  @version 1.0.0
 *  @since 1.2.6
 */
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists('Schema_Premium_SEO') ) :

	class Schema_Premium_SEO {

		public function __construct() {

			add_action( 'acf/init',	array( $this, 'seo_acf_fields' ), 99 );
			
			add_filter('acf/load_field/key=field_schema_seo_preview', array( $this, 'seo_preview' ) );

			add_filter('acf/load_field/key=field_schema_seo_check', array( $this, 'seo_check' ) );

			add_action( 'schema_output_meta', array( $this, 'meta_output' ), 10 );

			add_action( 'after_setup_theme', array( $this, 'meta_output' )	);

			add_action('acf/input/admin_footer', array( $this, 'admin_footer' )	); 
		}

		/**
		* Output meta
		*
		* @since 1.0.0
		* @return void
		*/
		public function meta_output() {
			
			global $post;

			if ( ! isset($post->ID) )
				return;

			if ( is_singular() ) {
		
				$title 					= schema_wp_get_the_title($post->ID);
				//$excerpt 				= get_the_excerpt($post->ID);
				$description 			= schema_wp_get_description($post->ID);
				$permalink				= get_the_permalink($post->ID);
				//$next_post_permalink 	= get_permalink( get_adjacent_post(false,'',false)->ID ); 
				//$prev_post_permalink 	= get_permalink( get_adjacent_post(false,'',true)->ID );
				$media 					= schema_wp_get_media($post->ID); 
				$twitter_url 			= schema_wp_get_option('twitter');
				$twitter_id_site 		= schema_premium_get_twitter_id_from_profile_url( $twitter_url );
				
				// Debug
				//
				//echo'<pre>'; print_r( $post ); echo'</pre>';
				//echo'<pre>'; print_r( $media ); echo'</pre>';

				$this->do_meta_title( $title );
				$this->do_meta_property( 'description', $description );
				$this->do_meta_link( 'canonical', $permalink );

				// Basic open graph meta
				//
				$this->do_meta_property( 'og:locale', get_locale() );
				$this->do_meta_property( 'og:type', 'article' );
				$this->do_meta_property( 'og:title', $title );
				$this->do_meta_property( 'og:description', $description );
				$this->do_meta_property( 'og:url', $permalink );
				$this->do_meta_property( 'og:site_name', get_bloginfo( 'name' ) );
				
				// Article meta
				//
				$this->do_meta_property( 'article:published_time', get_the_date('c', $post->ID) );
				$this->do_meta_property( 'article:modified_time',  get_the_modified_date('c', $post->ID) );
				$this->do_meta_property( 'article:updated_time', get_the_date('c', $post->ID) );

				// Image open graph meta
				//
				if (isset($media['url'])) { 
					$this->do_meta_property( 'og:image', $media['url'] );
					$this->do_meta_property( 'og:image:secure_url', $media['url'] );
				} 
				if (isset($media['width'])) { $this->do_meta_property( 'og:image:width', $media['width'] ); } 
				if (isset($media['height'])) { $this->do_meta_property( 'og:image:height', $media['height'] ); } 
				if (isset($media['alt'])) { $this->do_meta_property( 'og:image:alt', $media['alt'] ); } 
				if (isset($media['encodingFormat'])) { $this->do_meta_property( 'og:image:type', $media['encodingFormat'] ); } 


				// Facebook meta
				//
				// source: https://developers.facebook.com/docs/sharing/webmasters/#markup
				// source: https://developers.facebook.com/tools/debug/
				//
				//$this->do_meta_property( 'fb:app_id', 'APP-ID' );

				// Twitter meta
				//
				// source: https://developer.twitter.com/en/docs/twitter-for-websites/cards/guides/getting-started#opengraph
				//
				//
				$this->do_meta_name( 'twitter:card', 'summary_large_image' );
				$this->do_meta_name( 'twitter:site', $twitter_id_site ); // @username for the content creator / author.
				$this->do_meta_name( 'twitter:creator', '@hishaman' ); // @username for the website used in the card footer
				$this->do_meta_name( 'twitter:title', $title );
				$this->do_meta_name( 'twitter:description', $description );
				if (isset($media['url'])) { $this->do_meta_name( 'twitter:image', $media['url'] ); }
				$this->do_meta_name( 'twitter:label1', __('Written by', 'schema-premium') );
				$this->do_meta_name( 'twitter:data1', get_the_author_meta('display_name', $post->post_author) );
				
				/*
			?>
			<title><?php echo $title; ?></title> 
			<meta name="description" content="<?php echo $description; ?>" /> 
			<link rel="canonical" href="<?php echo $permalink; ?>" /> 
			<!-- <link rel="next" href="<?php //echo $next_post_permalink; ?>" /> -->
			
			<meta property="og:locale" content="<?php echo get_locale(); ?>" />
			<meta property="og:type" content="article" />
			<meta property="og:title" content="<?php echo $title; ?>" />
			<meta property="og:description" content="<?php echo $description; ?>" />
			<meta property="og:url" content="<?php echo $permalink; ?>" />
			<meta property="og:site_name" content="<?php echo get_bloginfo( 'name' ); ?>" />
			
			<meta property="article:published_time" content="<?php echo get_the_date('c', $post->ID); ?>" />
			<meta property="article:modified_time" content="<?php echo get_the_modified_date('c', $post->ID); ?>" />
			<meta property="article:updated_time" content="<?php echo get_the_date('c', $post->ID); ?>" />

			<meta property="og:image" content="<?php echo $media['url']; ?>" />
			<meta property="og:image:secure_url" content="<?php echo $media['url']; ?>" />
			<meta property="og:image:width" content="<?php echo $media['width']; ?>" />
			<meta property="og:image:height" content="<?php echo $media['height']; ?>" />
			<meta property="og:image:alt" content="<?php echo $media['alt']; ?>" />
			<meta property="og:image:type" content="<?php echo $media['encodingFormat']; ?>" />
			
			<meta property="fb:app_id:type" content="APP-ID" />
			
			<meta name="twitter:card" content="summary_large_image" />
			<meta name="twitter:creator" content="@hishaman" />
			<meta name="twitter:site" content="<?php echo $twitter_id_site; ?>" />
			<meta name="twitter:title" content="<?php echo $title; ?>" />
			<meta name="twitter:description" content="<?php echo $description; ?>" />
			<meta name="twitter:image" content="<?php echo $media['url']; ?>" />
			<meta name="twitter:label1" content="Written by" />
			<meta name="twitter:data1" content="<?php echo get_the_author_meta('display_name', $post->post_author); ?>" />
			<?php

			*/

			} // end if is_singular
			

			// Debug
			/*if (current_user_can( 'manage_options' )) {
					echo'<pre>'; print_r( $schema ); echo'</pre>';
					exit;
					echo 'Execution time in seconds: ' . (microtime(true) - $time_start) . '<br>';
			}
			*/
		}

		/**
		* Meta title output 
		*
		* @since 1.0.0
		* @return void
		*/
		public function do_meta_title( $title = '' ) {

			if ( isset($title) && $title != '' ) {

				echo '<title>' . $title . '</title>' . PHP_EOL;
			}
			
		}

		/**
		* Meta property output  
		*
		* @since 1.0.0
		* @return void
		*/
		public function do_meta_property( $property, $content ) {

			if ( isset($property) && $property != '' && isset($content) && $content != '' ) {
				
				echo '<meta property="' . $property .'" content="' . $content . '" />' . PHP_EOL;
			}
			 
		}

		/**
		* Meta name output 
		*
		* @since 1.0.0
		* @return void
		*/
		public function do_meta_name( $name, $content ) {

			if ( isset($name) && $name != '' && isset($content) && $content != '' ) {
				
				echo '<meta name="' . $name .'" content="' . $content . '" />' . PHP_EOL;
			}
			 
		}

		/**
		* Meta link output 
		*
		* @since 1.0.0
		* @return void
		*/
		public function do_meta_link( $rel, $href ) {

			if ( isset($rel) && $rel != '' && isset($href) && $href != '' ) {
				 
				echo '<link rel="' . $rel .'" href="' . $href .'" />' . PHP_EOL;
			}
			 
		}
		
		/**
		* Remove tags and links in wp_gead taht is inserted by theme
		*
		* @since 1.0.0
		* @return void
		*/
		public function remove_render_head_parts() {

			remove_action( 	'wp_head', 	'_wp_render_title_tag',	1 );
			remove_action(	'wp_head', 	'rel_canonical');
		}

		/**
		* SEO ACF fields 
		*
		* @since 1.0.0
		* @return void
		*/
		public function seo_acf_fields() {

			$post_id = isset($_GET['post']) ? $_GET['post'] : 0;

			$post = get_post($post_id);

			if( function_exists('acf_add_local_field') ):
				
				$title 		= schema_wp_get_the_title($post_id);
				$slug 		= isset($post->post_name) ? $post->post_name : '';
				//$excerpt 	= get_the_excerpt($post->ID);
				$description = schema_premium_get_truncate_to_word(schema_wp_get_description($post_id, 'short', true), 160);

				// Add SEO tab
				//
				acf_add_local_field( array(
					'key' 		=> 'field_schema_seo_tab',
					'name' 		=> 'schema_seo_tab',
					'label' 	=> __('SEO', 'schema-premium'),
					'type' 		=> 'tab',
					'parent' 	=> 'group_schema_properties',
					'placement' => 'left',
					'endpoint'	=> 0,
				) );

				// SEO Preview : Message
				//
				//
				acf_add_local_field(array(
					'key' 		=> 'field_schema_seo_preview',
					'label' 	=> __('Search Results Preview', 'schema-premium'),
					'name' 		=> 'schema_seo_preview',
					'type' 		=> 'message',
					'parent' 	=> 'group_schema_properties',
					'message'	=> __('Preview goes here...', 'schema-premium'),
					'instructions'	=> __('This is how your page will appear when this post shows up in the search results.', 'schema-premium')
				));

				// SEO Title
				// 
				acf_add_local_field(array(
					'key' 			=> 'feild_schema_seo_title',
					'label' 		=> __('Meta Title', 'schema-premium'),
					'name' 			=> 'schema_seo_title',
					'type' 			=> 'schema_seo_title',
					'parent' 		=> 'group_schema_properties',
					'default_value' => '',
					'placeholder' 	=> $title,
					'maxLength_seo' => 60,
					'instructions'	=> __('This is what will appear in the first line when this post shows up in the search results.', 'schema-premium')
				));

				// SEO Description
				// 
				acf_add_local_field(array(
					'key' 			=> 'feild_schema_seo_description',
					'label' 		=> __('Meta Description', 'schema-premium'),
					'name' 			=> 'schema_seo_description',
					'type' 			=> 'schema_seo_description',
					'parent' 		=> 'group_schema_properties',
					'default_value' => '',
					'placeholder' 	=> $description,
					'maxLength_seo' => 160,
					'rows'			=> 3,
					'instructions'	=> __('This is what will appear as the description when this post shows up in the search results.', 'schema-premium')
				));

				// SEO Permalink - Slug
				//
				acf_add_local_field(array(
					'key' 			=> 'feild_schema_seo_permalink',
					'label' 		=> __('Permalink', 'schema-premium'),
					'name' 			=> 'schema_seo_permalink',
					'type' 			=> 'schema_seo_permalink',
					'parent' 		=> 'group_schema_properties',
					'default_value' => $slug,
					'placeholder' 	=> $slug,
					'maxLength_seo' => 75,
					'instructions'	=> __('This is the unique URL of this page, displayed below the post title in the search results.', 'schema-premium')
				));

				// Focus Keyword
				// 
				acf_add_local_field(array(
					'key' 			=> 'feild_schema_seo_focus_keywords',
					'label' 		=> __('Focus Keywords', 'schema-premium'),
					'name' 			=> 'schema_seo_focus_keywords',
					'type' 			=> 'schema_seo_focus_keyword',
					'parent' 		=> 'group_schema_properties',
					'default_value' => '',
					'placeholder' 	=> __('Add keyword', 'schema-premium'),
					'instructions'	=> __('Focus keywords are the words you want your page to rank for.', 'schema-premium')
				));
			
				// SEO Check : Message
				//
				//
				acf_add_local_field(array(
					'key' 		=> 'field_schema_seo_check',
					'label' 	=> __('SEO Check', 'schema-premium'),
					'name' 		=> 'schema_seo_check',
					'type' 		=> 'message',
					'parent' 	=> 'group_schema_properties',
					'message'	=> __('Preview goes here...', 'schema-premium'),
					'instructions'	=> __('This is how your page will appear when this post shows up in the search results.', 'schema-premium')
				));

			endif;
		}

		/**
		* Set SEO Preview in ACF message field
		*
		* @since 1.0.0
		* @return $field
		*/
		public function seo_preview( $field ) {
			
			$post_id = schema_premium_get_post_ID();

			if ( !isset($post_id) )
				return $field;
			
			$permalink 		= get_field( 'schema_seo_permalink',  $post_id );
			$title 			= get_field( 'schema_seo_title',  $post_id );
			$description 	= get_field( 'schema_seo_description',  $post_id );
			$published_date = get_the_date();

			if ( $description == '' ) {
				$description = schema_wp_get_description($post_id);
			}
			
			$url 	= get_permalink($post_id);
			$parts 	= explode("/", $url);
			$slug 	= $parts[count($parts) - 1]; // best-post

			// Trying replace variables, example %title%
			//
			//$title = $this->replace_variables( $title , $post );
			//$description = $this->replace_variables( $description, $post );

			$preview = '<div class="schema-seo-preview">';
				$preview .= '<div class="seo-permalink">' . $slug . get_permalink($post_id) .'</div>';
				$preview .= '<h5 class="seo-title">' . $title .'</h5>';
				$preview .= '<div class="seo-description"><span class="seo-date">'.$published_date.'</span> — ' . $description .'</div>';
			$preview .= '</div>';

			$field['message'] = $preview;

			// For debug
			//
			//echo'<pre>';print_r($field);echo'</pre>';
			//$group_key = 'group_schema_properties';
			//$fields = get_field_objects();
			//echo '<pre>'; print_r($fields); echo '</pre>';
			//exit;

			return $field;
		}

		/**
		* Set SEO Check in ACF message field
		*
		* @since 1.0.0
		* @return $field
		*/
		public function seo_check( $field ) {

			$post_id = schema_premium_get_post_ID();

			//echo'<pre>';print_r($field);echo'</pre>';exit;

			// start
			//
			$check = '<ul class="schema-seo-check">';

			// Schema : Structured Data check
			//
			/*
			if ( function_exists('schema_premium_is_match') && schema_premium_is_match( get_the_ID() ) ) {
				$class 	= ' text-success';  
				$check .= '<li class="schema-seo-check-schema'.$class.'">'.__('Structured Data: Is enabled, perfect!', 'schema-premium').'</li>';
			} else {
				$class 	= ' text-danger';  
				$check .= '<li class="schema-seo-check-schema'.$class.'">'.__('Structured Data: Is not enabled!', 'schema-premium').'</li>';
			}
			*/
			if ( class_exists('Schema_WP_Singular') ) {
				
				$schema 			= new Schema_WP_Singular;
				$structured_data 	= $schema->get_markup( $post_id );

				//echo'<pre>';print_r($structured_data);echo'</pre>';
				//exit;

				if ( ! empty($structured_data) && is_array($structured_data) ) {
					
					if ( count($structured_data) == 1 ) {
						$info 	= ' <span>You have enabled schema.org type, perfect!</span> ';
						$class 	= ' text-success';  
					} elseif ( count($structured_data) > 1 ) {
						$info 	= ' <span>You have ('.count($structured_data).') schema.org types enabled.</span> ';
						$class	= ' text-warning';  
					} else {
						$info 	= ' <span>Something went wrong!</span> ';
						$class 	= ' text-danger';  
					}
					
					$check .= '<li class="schema-seo-check-schema'.$class.'">'.__('Structured Data: ', 'schema-premium').$info.'</li>';
				
				} else {
					
					$class 	= ' text-danger';  
					$check .= '<li class="schema-seo-check-schema'.$class.'">'.__('Structured Data: Is not enabled!', 'schema-premium').'</li>';
				}
			}
			
			//
			// SEO Title length check
			//
			$seo_title = get_field( 'schema_seo_title', $post_id );
			$seo_title = get_post_meta( $post_id, 'schema_seo_title',  true );
			if ( isset($seo_title) && $seo_title != '' ) {
				$class 	= ' text-success';  
				$check .= '<li class="schema-seo-check-title-length'.$class.'">'.__('SEO title length: Good job!', 'schema-premium').'</li>';
			} else {
				$class 	= ' text-danger'; 
				$check .= '<li class="schema-seo-check-title-length'.$class.'">'.__('SEO title length: Please create an SEO title.', 'schema-premium').'</li>';
			}

			//
			// SEO description length check
			//
			$seo_description = get_field( 'schema_seo_description', $post_id );
			if ( isset($seo_description) && $seo_description != '' ) {
				$class 	= ' text-success';  
				$check .= '<li class="schema-seo-check-description-length'.$class.'">'.__('SEO description length: Good job!', 'schema-premium').'</li>';
			} else {
				$class 	= ' text-danger';
				$check .= '<li class="schema-seo-check-description-length'.$class.'">'.__('SEO description length: Please create an SEO title.', 'schema-premium').'</li>';
			}

			//
			// Content length check
			//
			$post_content 	= get_post_field( 'post_content', $post_id );
			$post_content 	= wp_strip_all_tags( strip_shortcodes( trim($post_content) ) );
			$count 			= str_word_count($post_content);

			if ($count >= 600 ) {
				$class = ' text-success';
			} else if ($count >= 300 && $count < 600 ) {
				$class = ' text-warning';
			} else {
				$class = ' text-danger';
			}

			$check .= '<li class="schema-seo-check-content-length'.$class.'">'.__('Content is', 'schema-premium').' <span class="content-length">'.$count.'</span> '.__('words long. Consider using at least 600 words.', 'schema-premium').'</li>';

			//
			// end
			//
			$check .= '</ul>';

			$field['message'] = $check;

			return $field;
		}

		/**
		* Replace Variables
		*
		* @since 1.0.0
		* @return void
		*/
		public function replace_variables( $content, $post = 0 ) {
			
			//if ( ! is_string($content) ) return $content;

			$needle = '%title%';

			// Test if string contains the word 
			if(strpos( $content, $needle ) !== false){
				return str_replace( $needle, get_the_title($post->ID), $content ); 
			} else{
				return $content;
			}

		}

		/**
		* Admin Footer Stypes and Scripts
		*
		* @since 1.0.0
		* @return void
		*/
		public function admin_footer() {
			
			$post_id = schema_premium_get_post_ID();

			$url 	= get_permalink($post_id);
			$slug 	= str_replace( basename($url), '', $url );

			?>
			<style type="text/css">
				.schema-seo-preview {
					max-width: 652px;
					font-family: arial, sans-serif;
					text-align: left;
					padding: 12px;
				}
				.schema-seo-preview .seo-permalink {
					color: #5f6368 !important;
					font-size: 14px;
					line-height: 1.3;
					font-weight: normal;
					margin: 3px 0 5px;
					white-space: nowrap;
				}
				.schema-seo-preview .seo-title {
					color: #1a0dab !important;
					font-size: 20px;
					font-weight: 400;
					line-height: 1.3;
					display: inline-block;
					padding-top: 5px;
					margin: 0;
					margin-bottom: 3px;
				}
				.schema-seo-preview .seo-description {
					color: #4d5156 !important;
					font-size: 14px;
					line-height: 1.58;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					overflow: hidden;
				}
				.schema-seo-preview .seo-date {
					color: #70757a !important;	
				}

				.schema-seo-check .text-success::before,
				.schema-seo-check-focus-keywords .text-success::before {
					color: #28a745 !important;	
				}
				.schema-seo-check .text-danger::before,
				.schema-seo-check-focus-keywords .text-danger::before {
					color: #dc3545 !important;	
				}
				.schema-seo-check .text-warning::before,
				.schema-seo-check-focus-keywords .text-warning::before {
					color: #ffc107 !important;	
				}

				.schema-seo-check li:before,
				.schema-seo-check-focus-keywords li:before {
					content: "\f159";
					display: inline-block;
					vertical-align: middle;
					-webkit-font-smoothing: antialiased;
					font: normal 20px/1 'dashicons';
					color: #dc3545;
					margin-right: 6px;
					word-wrap: break-word;
				}
			</style>

			<script type="text/javascript">
				
				(function($) {
					
					// JS 
					//
					acf.add_action('load', function( $el ){
						
						// Set classes to reset 
						//
						var classes = "text-success text-danger text-warning";

						// Get content length
						//
						var post_content = wp.data.select("core/editor").getEditedPostContent();
						var cleanHTML = jQuery.trim(post_content.replace(/<\/?[^>]+(>|$)/gi, ""));
						var words = cleanHTML.split(" ");
						//
						//
						$(".schema-seo-check-content-length .content-length").text(words.length);
						
						// Get permalink
						//
						var seo_permalink = $("#acf-feild_schema_seo_permalink").val();
						var slug = "<?php echo rtrim($slug, '/'); ?>";
						$(".schema-seo-preview .seo-permalink").text( slug + '/' + seo_permalink + '/');

						// SEO Title
						//
						$('#acf-feild_schema_seo_title').keyup(function() {
							
							// Preview
							//
							var seo_title = $("#acf-feild_schema_seo_title").val();
							$(".schema-seo-preview .seo-title").text(seo_title);

							// Check: SEO Title length
							//
							$(".schema-seo-check-title-length").removeClass(classes);
							
							if (seo_title.length > 60 ) {
								var seo_check = 'text-danger';
							} else if (seo_title.length >= 48 && seo_title.length <= 60 ) {
								var seo_check = 'text-success';
							} else if (seo_title.length >= 29 && seo_title.length < 48 ) {
								var seo_check = 'text-warning';
							} else {
								var seo_check = 'text-danger';
							}
							 
							$(".schema-seo-check-title-length").addClass(seo_check);

						});

						// SEO Permalink
						//
						$('#acf-feild_schema_seo_permalink').keyup(function() {
							
							// Preview
							//
							var seo_permalink = $("#acf-feild_schema_seo_permalink").val();
							var slug = "<?php echo rtrim($slug, '/'); ?>";
							$(".schema-seo-preview .seo-permalink").text( slug + '/' + seo_permalink + "/");
						});

						// SEO Description
						//
						$('#acf-feild_schema_seo_description').keyup(function() {
							
							// Preview
							//
							var seo_description = $("#acf-feild_schema_seo_description").val();
							$(".schema-seo-preview .seo-description").text(seo_description);

							// Check: SEO Description length
							//
							$(".schema-seo-check-description-length").removeClass(classes);
							
							if (seo_description.length > 160 ) {
								var seo_check = 'text-danger';
							} else if (seo_description.length >= 128 && seo_description.length <= 160 ) {
								var seo_check = 'text-success';
							} else if (seo_description.length >= 80 && seo_description.length < 128 ) {
								var seo_check = 'text-warning';
							} else {
								var seo_check = 'text-danger';
							}
							 
							$(".schema-seo-check-description-length").addClass(seo_check);
						});

						// Content length
						//
						$('.is-desktop-preview').keyup(function() {
							
							//var arr = wp.data.select("core/editor");
							//var arr = wp.data.select( 'core/block-editor' ).getSelectedBlock().attributes;
							//var words = arr['content'].split(' ');

							// Check: Post content length
							//
							var post_content = wp.data.select("core/editor").getEditedPostContent();
							var cleanHTML = jQuery.trim(post_content.replace(/<\/?[^>]+(>|$)/gi, ""));
							var words = cleanHTML.split(" ");
							
							$(".schema-seo-check-content-length .content-length").text(words.length);
							
							if (words.length >= 600 ) {
								var seo_check = 'text-success';
							} else if (words.length >= 300 && words.length < 600 ) {
								var seo_check = 'text-warning';
							} else {
								var seo_check = 'text-danger';
							}
							
							$(".schema-seo-check-content-length").removeClass(classes);
							$(".schema-seo-check-content-length").addClass(seo_check);

							// For debug
							//
							/*
							jQuery.each(arr, function(i, val) {
								$(".schema-seo-preview .seo-description").append(i + " : " + val + "<br/>");		  
							});
							*/ 
						});

					});
				
				})(jQuery);

			</script>
			<?php
		}

	}

	$schema_premium_seo = new Schema_Premium_SEO;

endif;
