<?php
/**
 * @package Schema Premium - Extension : Custom Schema Properties
 * @category Core
 * @author Hesham Zebida
 * @version 1.0.0
 * @since 1.2.6
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'acf/init', 'schema_premium_custom_properties_json_acf_field' );
/**
 * ACF - Custom Properties fields
 *
 * @since 1.0.0
 */
function schema_premium_custom_properties_json_acf_field() {

	if( function_exists('acf_add_local_field') ):
		
		//
		//
		// ACF Group: Custom Properties
		//
		// @since 1.2.6
		//
		acf_add_local_field_group(array (
			'key' => 'schema_custom_properties_group',
			'title' => __('Custom Properties', 'schema-premium'),
			'location' => array (
				array (
					array (	 // custom location
						'param' => 'post_type',
						'operator' => '==',
						'value' => 'schema',
					),
				),
			),
			'menu_order' => 40,
			'position' => 'normal',
			'style' => 'default',
			'label_placement' => 'left',
			'instruction_placement' => 'label',
			'hide_on_screen' => '',
			'active' => 1,
			'description' => '',
			'fields' => array(
				array(
					'key' 			=> 'field_schema_custom_properties',
					'label'			=> __('Custom Properties', 'schema-premium'),
					'name' 			=> 'schema_custom_properties',
					'type' 			=> 'repeater',
					'parent' 		=> 'schema_properties_group',
					'layout'		=> 'block',
					'collapsed' 	=> '',
					'min' 			=> 1,
					'max' 			=> 0,
					'button_label' 	=> __('Add New Custom Property', 'schema-premium'),
					'instructions' 	=> __('Build your own custom properties fields.', 'schema-premium'),
					'sub_fields' 	=>  array(
						array(
							'key' 			=> 'field_name',
							'label' 		=> __('Name', 'schema-premium'),
							'name' 			=> 'name',

							'type' 			=> 'text',
							'instructions' 	=> '',
							'placeholder' 	=> __('Name', 'schema-premium'),
							'wrapper' => array(
								'width' => '33',
								'class' => '',
								'id' => '',
							),
						),
						array(
							'key' 			=> 'field_type',
							'label' 		=> __('Type', 'schema-premium'),
							'name' 			=> 'type',
							'type' 			=> 'select',
							'choices' 		=> schema_premium_get_custom_property_types_select_options(),
							'instructions' 	=> '',
							'placeholder' 	=> __('Type', 'schema-premium'),
							'rows' => 2,
							'wrapper' => array(
								'width' => '33',
								'class' => '',
								'id' => '',
							),
							'allow_null' => 0,
							'default_value' => 'text',
							'show_in_rest' => 1
						),
						array(
							'key' 			=> 'field_value',
							'label' 		=> __('Value', 'schema-premium'),
							'name' 			=> 'value',
							'type' 			=> 'select',
							'choices' 		=> schema_wp_get_properties_select_options(),
							'instructions' 	=> '',
							'placeholder' 	=> __('Value', 'schema-premium'),
							'rows' => 2,
							'wrapper' => array(
								'width' => '33',
								'class' => '',
								'id' => '',
							),
						),
					), // end sub fields
				)
			) 
		));
		
	endif;
}

/**
 * Property types select options
 *
 * @since 1.0.0
 */
function schema_premium_get_custom_property_types_select_options() {

	$options = array ( 
		//''	=> __('— Select —', 'schema-premium'), 
		'text' 				=> __('Text', 'schema-premium'),
		'number' 			=> __('Number', 'schema-premium'),
		//'textarea' 			=> __('Textarea', 'schema-premium'), 
		'url' 				=> __('URL', 'schema-premium'),
		'Date' 				=> __('Date', 'schema-premium'),
		'ImageObject ' 		=> __('Image Object', 'schema-premium'),
		'AudioObject' 		=> __('Audio Object', 'schema-premium'),
		
		'author_name' 		=> __('Author Name', 'schema-premium'),
		'post_date' 		=> __('Publish Date', 'schema-premium'), 
		'post_modified' 	=> __('Last Modified Date', 'schema-premium'), 					
	);
					
	return apply_filters( 'schema_wp_get_custom_properties_select_options', $options );
}

add_filter( 'schema_singular_output', 'schema_premium_custom_properties_json_markup_output' );
/**
 * Output Markup
 *
 * @since 1.0.0
 */
function schema_premium_custom_properties_json_markup_output( $schema ) {
	
	global $post;

	if ( empty($schema) ) return;
	
	$custom_json = schema_premium_get_custom_markup( $post->ID );

	if ( ! empty( $custom_json ) && is_array( $custom_json ) ) {

		$json_override = get_post_meta( $post->ID, 'schema_custom_json_override', true);

		if ( isset($json_override) ) {
		
			if ( $json_override == 1 ) {
				
				// True
				return $custom_json;

			} elseif ( $json_override == 0 ) {

				// False
				$schema = array_merge( $schema, $custom_json );

			}
		}
	}
	
	return $schema;
}

/**
 * Get Custom Markup 
 *
 * @since 1.0.0
 *
 * return array
 */
function schema_premium_get_custom_properties_markup( $post_id ) {
	
	if ( ! isset($post_id) )
		return;

	$custom_markup = array();
	
	if( function_exists('have_rows') ) {

		// check if the repeater field has rows of data
		if( have_rows('field_schema_custom_json_repeater', $post_id ) ):
			
			// loop through the rows of data
			while ( have_rows('field_schema_custom_json_repeater', $post_id ) ) : the_row();

				// display a sub field value
				$custom_json 		= get_sub_field('schema_custom_json');
				$custom_markup[] 	= json_decode( $custom_json, true );

			endwhile;

		else :
			// no rows found

		endif;

	} // end if function_exists

	return $custom_markup;
}

