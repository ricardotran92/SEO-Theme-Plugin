<?php
/**
 * @package Schema Premium - Extension : speakable
 * @category Core
 * @author Hesham Zebida
 * @version 1.0.0
 * @since 1.2.3
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'schema_output', 'schema_premium_speakable_markup_output' );
/**
 * Output Markup
 *
 * @since 1.0.0
 */
function schema_premium_speakable_markup_output( $schema ) {
	
	if ( empty($schema) ) return;
	
	// Check if combines markup is set in plugin settings, if so... no speakable!
	// It's added via the combine class
	//
	$combine = schema_wp_get_option('schema_output_type');
	//
	if ( $combine == 'combined' ) 
		return $schema;

	// Apply only on Article, and WebPage schema.org types
	// Speakable is used by the Article or Webpage object
	//
	if ( isset($schema['@type']) ) {
		
		if ( $schema['@type'] == 'Article' || $schema['@type'] == 'WebPage' ) {
		
			$speakable_enabled = schema_wp_get_option( 'speakable_enabled' );
	
			if ( $speakable_enabled != 'enabled' )
				return $schema;
	
			$speakable = schema_premium_get_speakable();
			
			if ( ! empty( $speakable ) )
				$schema['speakable'] = $speakable;
			
		}
	}
	
	return $schema;
}

/**
 * Get speakable 
 *
 * @since 1.0.0
 *
 * return array
 */
function schema_premium_get_speakable() {
	
	global $schema_wp_options;

	$speakable 		= array();
	$speakable_type = isset($schema_wp_options['speakable_type']) ? $schema_wp_options['speakable_type'] : 'xPath';
	
	switch ( $speakable_type ) {
		
		case 'xPath':
			$speakable = array(
				'@type'	=> 'SpeakableSpecification',
				'xpath'	=> array(
					"/html/head/title",
					"/html/head/meta[@name='description']/@content"
				)
			);
		break;

		case 'cssSelector':

			$headline 	= isset($schema_wp_options['speakable_headline'])	? $schema_wp_options['speakable_headline'] 	: '.entry-title';
			$summary 	= isset($schema_wp_options['speakable_summary']) 	? $schema_wp_options['speakable_summary'] 	: '.entry-content';
	
			$speakable = array(
				'@type'	=> 'SpeakableSpecification',
				'cssSelector'	=> array(
					$headline,
					$summary
				)
			);
		break;
	}

	return $speakable;
}
