<?php
/**
 *  Sitemaps extention
 *
 *  Adds control over WP Sitemaps 
 * 
 *  @version 1.0.0
 *  @since 1.2.7
 */
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists('Schema_Premium_Sitemaps') ) :

	class Schema_Premium_Sitemaps {

		public function __construct() {

			//add_action( 'acf/init',	array( $this, 'sitemap_acf_fields' ) );
			
			//add_filter( 'wp_sitemaps_enabled', '__return_false' );

			// Remove 
			//
			add_filter( 'wp_sitemaps_add_provider',				array( $this, 'remove_users' ), 10, 2 );
			add_filter( 'wp_sitemaps_taxonomies',				array( $this, 'remove_post_tag' ) );
			
			// Modify
			//
			add_filter( 'wp_sitemaps_posts_query_args',			array( $this, 'num_links_per_sitemap' ), 10, 2 );
			//add_filter( 'wp_sitemaps_post_types',				array( $this, 'disable_post_type_page' ) );
			add_filter( 'wp_sitemaps_posts_query_args',			array( $this, 'exclude_from_sitemaps' ), 10, 2 );
			
			// Add
			//
			add_filter( 'wp_sitemaps_posts_entry',				array( $this, 'wp_sitemaps_posts_entry_add_modified_gmt' ), 10, 2 );
			
		}
		
		/**
		* Set the max number of pages
		*
		* @since 1.0.0
		* @return $args
		*/
		public function num_links_per_sitemap( $args, $post_type ) {
			
			$args['posts_per_page'] = 200;
			
			return $args;
		}

		/**
		* Removing users sitemaps
		*
		* @since 1.0.0
		* @return $provider
		*/
		public function remove_users( $provider, $name ) {
			
			if ( 'users' === $name ) {
				return false;
			}
			
			return $provider;
		} 

		/**
		* Disabling sitemaps for the page post type
		*
		* @since 1.0.0
		* @return $post_types
		*/
		public function disable_post_type_page( $post_types ) {
			
	
			unset( $post_types['page'] );

        	return $post_types;
		} 

		/**
		* Remove sitemaps for the post_tag taxonomy
		*
		* @since 1.0.0
		* @return $taxonomies
		*/
		public function remove_post_tag( $taxonomies ) {
			
			unset( $taxonomies['post_tag'] );
			
			return $taxonomies;
		} 

		/**
		* Exclude from sitemaps
		*
		* @since 1.0.0
		* @return $args
		*/
		public function exclude_from_sitemaps( $args, $post_type ) {
			
			if ( 'post' !== $post_type ) {
				return $args;
			}
	 
			$args['post__not_in'] = isset( $args['post__not_in'] ) ? $args['post__not_in'] : array();
			$args['post__not_in'][] = 123; // 123 is the ID of the post to exclude.
			
			return $args;
		}

		/**
		* Adding the last modified date for posts
		*
		* @since 1.0.0
		* @return $entry 
		*/
		public function wp_sitemaps_posts_entry_add_modified_gmt( $entry, $post ) {
			
			$entry['lastmod'] 	= $post->post_modified_gmt;
			
        	return $entry;
		}

	}

	$schema_premium_sitemaps = new Schema_Premium_Sitemaps;

endif;
