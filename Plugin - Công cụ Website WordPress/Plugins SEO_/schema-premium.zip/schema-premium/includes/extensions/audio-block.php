<?php
/**
 *  Audio Block extention
 *
 *  Adds schema AudioObject to Audio Block
 *
 *  @since 1.2.6
 */
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

add_filter( 'schema_single_item_output', 'schema_premium_audio_block_structured_data' );
/**
 * Audio Block strcutred data, filter the schema_single_item_output
 *
 * @param array $schema
 * @since 1.2.6
 * @return array modified $schema 
 */
function schema_premium_audio_block_structured_data( $schema ) {
	
	// Debug - start of script
	//$time_start = microtime(true); 
	
	if ( empty($schema) ) return;
	
	$audio_block_enable = schema_wp_get_option( 'audio_block_enable' );
	
	if ( $audio_block_enable != true )
		return $schema;
			
	global $wp_query, $post, $wp_embed;
	
	// Maybe this is not needed!
	// Or maybe it's needed, to make sure audio markup included only on main query (Not Sure!)
	//
	if ( ! $wp_query->is_main_query() ) return $schema;
	
	$locations_match = schema_premium_get_location_target_match( $post->ID );
	
	if ( ! is_array($locations_match) || empty($locations_match) ) return $schema;

	// Get attached audio files data
	//
	$media = get_attached_media( 'audio', $post->ID );

	// If there is audio attachments
	//
	if ( ! empty($media) ) {

		//echo'<pre>'; print_r( $media ); echo'</pre>';

		// Make sure wp_read_audio_metadata function exists 
		//
		if ( ! function_exists('wp_read_audio_metadata') ) {
			require_once( ABSPATH . 'wp-admin/includes/media.php' );
		}

		// Define the upload directory data
		//
		$upload_dir = wp_upload_dir();

		// Loop through locations 
		//
		foreach ( $locations_match as $schema_id => $location ) {
			
			// Check if location match... structured data is enabled on this location
			//
			if ( $location['match'] ) {
	
				// Check and add audio markup only on enabled schema.org types
				//
				if ( $location['schema_type'] == $schema['@type'] ) {
					
					foreach ( $media as $attachmet_id => $attachmet_meta ) {
						
						$audio_markup = array(
							'@type' => 'AudioObject',
						);
						
						// Get audio attachment details
						//
						$audio_markup['name'] 			= $attachmet_meta->post_title;
						$audio_markup['description'] 	= $attachmet_meta->post_content;
						$audio_markup['caption'] 		= $attachmet_meta->post_excerpt;
						$audio_markup['uploadDate'] 	= $attachmet_meta->post_date;
						$audio_markup['contentUrl'] 	= $attachmet_meta->guid;	

						// Get additinal details from audio file metadata
						//
						$audio_file_basename 	= basename( get_attached_file( $attachmet_id ) ); // Just the file name
						$file_path 				= $upload_dir['path'] . '/' . $audio_file_basename;
						$audio_metadata 		= wp_read_audio_metadata( $file_path );
						
						// Check if audio metadata is available
						//
						if ( $audio_metadata != false && ! empty($audio_metadata) ) {

							//echo'<pre>'; print_r( $audio_metadata ); echo'</pre>';

							if ( isset($audio_metadata['artist']) ) {
								$audio_markup['creator'] = array(
									'@type' => 'Person',
									'name'	=> wp_strip_all_tags($audio_metadata['artist'])
								);
							}
							if ( isset($audio_metadata['filesize']) ) {
								$audio_markup['contentSize'] = $audio_metadata['filesize'];
							}
							if ( isset($audio_metadata['length']) ) {
								$audio_markup['duration'] = schema_wp_get_time_second_to_iso8601_duration( $audio_metadata['length'] );
							}
							if ( isset($audio_metadata['genre']) ) {
								$audio_markup['genre'] = $audio_metadata['genre'];
							}
							if ( isset($audio_metadata['mime_type']) ) {
								$audio_markup['encodingFormat'] = $audio_metadata['mime_type'];
							}
							if ( isset($audio_metadata['codec']) ) {
								$audio_markup['encodingFormat'] = $audio_metadata['codec'];
							}
							
							
						}
						
						if ( ! empty($audio_markup)) {
	
							$schema['audio'][] = $audio_markup;
						}
						
					}
	
				}				
				
			}
		}
	}

	// echo'<pre>'; print_r( $schema ); echo'</pre>';

	// Debug
	/*if (current_user_can( 'manage_options' )) {
			echo'<pre>'; print_r( $schema ); echo'</pre>';
			exit;
			echo 'Execution time in seconds: ' . (microtime(true) - $time_start) . '<br>';
	}
	*/
	
	// Finally!
	//
	return $schema;
}
