<?php
/**
 * @package Schema Premium - Class Schema TouristDestination
 * @category Core
 * @author Hesham Zebida
 * @version 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists('Schema_WP_TouristDestination') ) :
	/**
	 * Class
	 *
	 * @since 1.2.6
	 */
	class Schema_WP_TouristDestination extends Schema_WP_Place {
		
		/** @var string Currenct Type */
    	protected $type = 'TouristDestination';
		
		/** @var string Current Parent Type */
		protected $parent_type = 'Place';

		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			// emty __construct
		}
		
		/**
		* Get schema type 
		*
		* @since 1.2
		* @return string
		*/
		public function type() {
			
			return 'TouristDestination';
		}

		/**
		* Get schema type label
		*
		* @since 1.0.0
		* @return array
		*/
		public function label() {
			
			return __('Tourist Destination', 'schema-premium');
		}
		
		/**
		* Get schema type comment
		*
		* @since 1.0.0
		* @return array
		*/
		public function comment() {
			
			return __('A tourist destination.', 'schema-premium');
		}

		/**
		* Get properties
		*
		* @since 1.0.2
		* @return array
		*/
		public function properties() {
			
			// Add specific properties 
			//
			$properties['includesAttraction'] =  array(
				'label' 		=> __('Includes Attraction', 'schema-premium'),
				'rangeIncludes' => array('Text'),
				'field_type' 	=> 'repeater',
				'layout'		=> 'block',
				'markup_value'  => 'new_custom_field',
				'button_label' 	=> __('Add Attraction', 'schema-premium'),
				'instructions' 	=> __('Attraction located at destination.', 'schema-premium'),
				'sub_fields' 	=>  array(
					'attraction_name' => array(
						'label' 		=> __('Name', 'schema-premium'),
						'rangeIncludes' => array('Text'),
						'field_type' 	=> 'text',
						'markup_value' 	=> 'new_custom_field',
						'instructions' 	=> '',
						'placeholder' 	=> __('Attraction name', 'schema-premium'),
						'width' 		=> '50'
					),
					'attraction_type' => array(
						'label' 		=> __('Type', 'schema-premium'),
						'rangeIncludes' => array('Text'),
						'field_type' 	=> 'text',
						'markup_value' 	=> 'new_custom_field',
						'instructions' 	=> '',
						'placeholder' 	=> __('Attraction type', 'schema-premium'),
						'width' 		=> '50'
					),
					'attraction_sameAs' => array(
						'label' 		=> __('sameAs url', 'schema-premium'),
						'rangeIncludes' => array('Text'),
						'field_type' 	=> 'url',
						'markup_value' 	=> 'new_custom_field',
						'instructions' 	=> '',
						'placeholder' 	=> 'https://',
						'width' 		=> '50'
					),
					'attraction_image'  => array(
						'label' 		=> __('Image', 'schema-premium'),
						'rangeIncludes' => array('ImageObject', 'URL'),
						'field_type' 	=> 'image',
						'markup_value' 	=> 'new_custom_field',
						'instructions' 	=> '',
						'placeholder' 	=> __('Attraction image', 'schema-premium'),
						'return_format' => 'url',
						'preview_size'  => 'thumbnail', // medium
						'width' 		=> '50'
					),
				), // end sub fields
			);

			$properties['touristType'] =  array(
				'label' 		=> __('Tourist Type', 'schema-premium'),
				'rangeIncludes' => array('Text'),
				'field_type' 	=> 'repeater',
				'layout'		=> 'block',
				'markup_value' => 'new_custom_field',
				'button_label' 	=> __('Add Tourist Type', 'schema-premium'),
				'instructions' 	=> __('Attraction suitable for type(s) of tourist. eg. Children, visitors from a particular country, etc.', 'schema-premium'),
				'sub_fields' 	=>  array(
					'tourist_type' => array(
						//'label' 		=> __('Type', 'schema-premium'),
						'rangeIncludes' => array('Text'),
						'field_type' 	=> 'text',
						'markup_value' 	=> 'new_custom_field',
						'instructions' 	=> '',
						'placeholder' 	=> __('Tourist type', 'schema-premium'),
						'width' 		=> '50'
					)
				), // end sub fields
			);
			
			// Wrap properties in tabs 
			//
			$properties = schema_properties_wrap_in_tabs( $properties, self::type(), self::label(), self::comment(), 30 );
			
			// Merge parent properties 
			//
			$properties = array_merge( parent::properties(), $properties );

			return apply_filters( 'schema_properties_TouristDestination', $properties );	
		}

		/**
		* Schema output
		*
		* @since 1.0.0
		* @return array
		*/
		public function schema_output( $post_id = null ) {
			
			if ( isset($post_id) ) {
				$post = get_post( $post_id );
			} else {
				global $post;
			}
			
			$schema = array();
			
			// Get properties
			//
			$properties = schema_wp_get_properties_markup_output( $post->ID, $this->properties(), $this->type );
			
			// Get includesAttraction
			//
			$schema['includesAttraction'] = $this->get_includesAttraction();

			// Get touristType
			//
			$schema['touristType'] = $this->get_touristType();

			// Merge parent schema 
			//
			$schema = array_merge( parent::schema_output($post->ID), $schema );

			return $this->schema_output_filter($schema);
		}

		/**
		* Apply filters to markup output
		*
		* @since 1.0.0
		* @return array
		*/
		public function schema_output_filter( $schema ) {
			
			return apply_filters( 'schema_output_TouristDestination', $schema );
		}

		/**
		* Get includesAttraction
		*
		* @since 1.0.0
		* @return array
		*/
		public function get_includesAttraction() {
			
			global $post;
			
			$output = array();
	
			$count = get_post_meta( get_the_ID(), 'schema_properties_Place_includesAttraction', true );
	
			if ( isset( $count ) && $count >= 0 ) {
		 
				for( $i=0; $i < $count; $i++ ) {
					
					$type		= get_post_meta( get_the_ID(), 'schema_properties_Place_includesAttraction_' . $i . '_attraction_type', true );
					$name		= get_post_meta( get_the_ID(), 'schema_properties_Place_includesAttraction_' . $i . '_attraction_name', true );
					$sameAs		= get_post_meta( get_the_ID(), 'schema_properties_Place_includesAttraction_' . $i . '_attraction_sameAs', true );
					$image_id	= get_post_meta( get_the_ID(), 'schema_properties_Place_includesAttraction_' . $i . '_attraction_image', true );
					
					$image_url = '';

					if ( isset($image_id) && $image_id != '' ) {
						$image_url = wp_get_attachment_url( $image_id );
					}
					
					$output[] 	= array
					(
						'@type'		=> array( $type,'TouristAttraction'),
						'name'		=> strip_tags($name),
						'sameAs'	=> $sameAs,
						'image'		=> $image_url
					);
				}
		
			}
	
			return $output;
		}

		/**
		* Get touristType
		*
		* @since 1.0.0
		* @return array
		*/
		public function get_touristType() {
			
			global $post;
			
			$output = array();
	
			$count = get_post_meta( get_the_ID(), 'schema_properties_Place_touristType', true );
	
			if ( isset( $count ) && $count >= 0 ) {
				
				$audienceType = array();

				
				for( $i=0; $i < $count; $i++ ) {
					
					$tourist_type	= get_post_meta( get_the_ID(), 'schema_properties_Place_touristType_' . $i . '_tourist_type', true );
					
					$audienceType[] = strip_tags($tourist_type);
					
				}
				if ( !empty($audienceType) ) {
					
					$output = array
					(
						'@type'			=> 'Audience',
						'audienceType'	=> $audienceType,
					);

				}
			}
	
			return $output;
		}

	}
		
endif;
