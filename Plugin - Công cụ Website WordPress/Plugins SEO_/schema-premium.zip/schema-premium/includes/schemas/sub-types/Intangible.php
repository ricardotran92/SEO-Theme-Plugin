<?php
/**
 * @package Schema Premium - Class Schema Intangible 
 * @category Core
 * @author Hesham Zebida
 * @version 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists('Schema_WP_Intangible') ) :
	/**
	 * Class
	 *
	 * @since 1.0.1
	 */
	class Schema_WP_Intangible extends Schema_WP_Thing {
		
		/** @var string Currenct Type */
    	protected $type = 'Intangible';
		
		/** @var string Current Parent Type */
		protected $parent_type = 'Thing';

		/**
	 	* Constructor
	 	*
	 	* @since 1.0.1
	 	*/
		public function __construct () {
		
			$this->init();
			$this->require_subtypes();
		}
	
		/**
		* Init
		*
		* @since 1.0.1
	 	*/
		public function init() {
		
			add_filter( 'schema_wp_get_default_schemas', array( $this, 'schema_type' ) );
			add_filter( 'schema_wp_types', array( $this, 'schema_type_extend' ) );
		}
		
		/**
		* Get schema type 
		*
		* @since 1.2
		* @return string
		*/
		public function type() {
			
			return 'Intangible';
		}

		/**
		* Get schema type label
		*
		* @since 1.0.1
		* @return array
		*/
		public function label() {
			
			return __('Intangible', 'schema-premium');
		}
		
		/**
		* Get schema type comment
		*
		* @since 1.0.1
		* @return array
		*/
		public function comment() {
			
			return __('A utility class that serves as the umbrella for a number of \'intangible\' things such as quantities, structured values, etc', 'schema-premium');
		}
		
		/**
		* Extend schema types
		*
		* @since 1.0.1
		* @return array
		*/
		public function schema_type_extend( $schema_types ) {
			
			$schema_types[$this->type] = array 
				(
					'label' => $this->label(),
					'value'	=> $this->type
				);
			
			return $schema_types;
		}
		
		/**
		* Get schema type
		*
		* @since 1.0.1
		* @return array
		*/
		public function schema_type( $schema ) {
			
			$schema[$this->type] = array (
    			'id' 			=> $this->type,
    			'lable' 		=> $this->label(),
				'comment' 		=> $this->comment(),
    			'properties'	=> $this->properties(),
    			'subtypes' 		=> $this->subtypes(),
			);
			
			return apply_filters( 'schema_wp_Intangible', $schema );
		}
		
		/**
		* Require sub types classes
		*
		* @since 1.2.7
		* @return array
		*/
		public function require_subtypes() {
			
			// Auto load sub schema types 
			//
			foreach ( glob ( SCHEMAPREMIUM_PLUGIN_DIR . 'includes/schemas/sub-types/'.$this->type.'/*.php' ) as $filename ) {
				require_once $filename;
			}
		}

		/**
		* Get sub types
		*
		* @since 1.0.1
		* @return array
		*/
		public function subtypes() {
			
			$subtypes = array
			(	
				/*
				'ActionAccessSpecification' 			=> __('Action Access Specification', 'schema-premium'),
				'AlignmentObject' 						=> __('Alignment Object', 'schema-premium'),
				'Audience'								=> __('Audience', 'schema-premium'),
				'BedDetails' 							=> __('Bed Details', 'schema-premium'),
				'Brand' 								=> __('Brand', 'schema-premium'),
				'BroadcastChannel' 						=> __('Broadcast Channel', 'schema-premium'),
				'BroadcastFrequencySpecification' 		=> __('Broadcast Frequency Specification', 'schema-premium')
				'Class' 								=> __('Class', 'schema-premium'),
				'ComputerLanguage' 						=> __('Computer Language', 'schema-premium'),
				'DataFeedItem' 							=> __('Data Feed Item', 'schema-premium'),
				'DefinedTerm' 							=> __('Defined Term', 'schema-premium'),
				'Demand' 								=> __('Demand', 'schema-premium'),
				'DigitalDocumentPermission' 			=> __('Digital Document Permission', 'schema-premium'),
				'EducationalOccupationalProgram' 		=> __('Educational Occupational Program', 'schema-premium'),
				'EnergyConsumptionDetails' 				=> __('Energy Consumption Details', 'schema-premium'),
				'EntryPoint' 							=> __('Entry Point', 'schema-premium'),
				'Enumeration' 							=> __('Enumeration', 'schema-premium'),
				'FloorPlan' 							=> __('Floor Plan', 'schema-premium'),
				'GameServer' 							=> __('GameServer', 'schema-premium'),
				'GeospatialGeometry' 					=> __('Geospatial Geometry', 'schema-premium'),
				'Grant' 								=> __('Grant', 'schema-premium'),
				'HealthInsurancePlan' 					=> __('Health Insurance Plan', 'schema-premium'),
				'HealthPlanCostSharingSpecification' 	=> __('Health Plan Cost Sharing Specification', 'schema-premium'),
				'HealthPlanFormulary' 					=> __('Health Plan Formulary', 'schema-premium'),
				'HealthPlanNetwork' 					=> __('Health Plan Network', 'schema-premium'),
				'Invoice' 								=> __('Invoice', 'schema-premium'),
				'ItemList' 								=> __('ItemList', 'schema-premium'),
				'JobPosting' 							=> __('Job Posting', 'schema-premium'),
				'Language' 								=> __('Language', 'schema-premium'),
				'ListItem' 								=> __('ListItem', 'schema-premium'),
				'MediaSubscription' 					=> __('Media Subscription', 'schema-premium'),
				'MenuItem' 								=> __('MenuItem', 'schema-premium'),
				'MerchantReturnPolicy' 					=> __('Merchant Return Policy', 'schema-premium'),
				'MerchantReturnPolicySeasonalOverride' 	=> __('Merchant Return Policy Seasonal Override', 'schema-premium'),
				'Observation' 							=> __('Observation', 'schema-premium'),
				'Occupation' 							=> __('Occupation', 'schema-premium'),
				'ccupationalExperienceRequirements' 	=> __('ccupational Experience Requirements', 'schema-premium'),
				'Offer' 								=> __('Offer', 'schema-premium'),
				'Order' 								=> __('Order', 'schema-premium'),
				'OrderItem' 							=> __('Order Item', 'schema-premium'),
				'ParcelDelivery' 						=> __('Parcel Delivery', 'schema-premium'),
				'Permit' 								=> __('Permit', 'schema-premium'),
				'ProgramMembership' 					=> __('Program Membership', 'schema-premium'),
				'Property' 								=> __('Property', 'schema-premium'),
				'PropertyValueSpecification' 			=> __('Property Value Specification', 'schema-premium'),
				'Quantity' 								=> __('Quantity', 'schema-premium'),
				'Rating' 								=> __('Rating', 'schema-premium'),
				'Reservation' 							=> __('Reservation', 'schema-premium'),
				'Role' 									=> __('Role', 'schema-premium'),
				'Schedule' 								=> __('Schedule', 'schema-premium'),
				'Seat' 									=> __('Seat', 'schema-premium'),
				'Series' 								=> __('Series', 'schema-premium'),
				'Service' 								=> __('Service', 'schema-premium'),
				'ServiceChannel' 						=> __('Service Channel', 'schema-premium'),
				'SpeakableSpecification' 				=> __('Speakable Specification', 'schema-premium'),
				'StatisticalPopulation' 				=> __('Statistical Population', 'schema-premium'),
				'StructuredValue' 						=> __('Structured Value', 'schema-premium'),
				'Ticket' 								=> __('Ticket', 'schema-premium'),
				'Trip' 									=> __('Trip', 'schema-premium'),
				'VirtualLocation' 						=> __('Virtual Location', 'schema-premium'),
				*/
			);
			
			$subtypes = array(

				'JobPosting' 							=> __('Job Posting', 'schema-premium'),
				'Service' 								=> __('Service', 'schema-premium'),
				'ItemList'								=> __('Item List', 'schema-premium'),
			);

			return apply_filters( 'schema_wp_subtypes_Intangible', $subtypes );
		}
		
		/**
		* Get properties
		*
		* @since 1.0.1
		* @return array
		*/
		public function properties() {
			
			// Wrap properties in tabs 
			//
			$properties = schema_properties_wrap_in_tabs( array(), self::type(), self::label(), self::comment(), 20 );

			// Merge parent properties 
			//
			$properties = array_merge( parent::properties(), $properties );

			return apply_filters( 'schema_properties_Intangible', $properties );	
		}
		
		/**
		* Schema output
		*
		* @since 1.0.1
		* @return array
		*/
		public function schema_output( $post_id = null ) {
			
			if ( isset($post_id) ) {
				$post = get_post( $post_id );
			} else {
				global $post;
			}
			
			$schema = array();
			
			// Get properties
			//
			$properties = schema_wp_get_properties_markup_output( $post->ID, $this->properties(), $this->type );
			
			// Merge parent schema 
			//
			$schema = array_merge( parent::schema_output($post->ID), $schema );

			return $this->schema_output_filter($schema);
		}

		/**
		* Apply filters to markup output
		*
		* @since 1.1.2.8
		* @return array
		*/
		public function schema_output_filter( $schema ) {
			
			return apply_filters( 'schema_output_Intangible', $schema );
		}
	}
	
	new Schema_WP_Intangible();
	
endif;
