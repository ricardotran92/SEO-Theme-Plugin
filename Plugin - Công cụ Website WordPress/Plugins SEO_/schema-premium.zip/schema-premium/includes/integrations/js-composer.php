<?php
/**
 * WPBakery Page Builder (VC)
 *
 *
 * Integrate with WPBakery Page Builder plugin
 *
 * plugin url: https://wpbakery.com/
 * @since 1.2.3
 */
 
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'vc_after_init', 'schema_premium_vc_remove_wp_admin_bar_buttons' );
/*
* WPBakery Page Builder admin bar button, and frontend editor
*
* @since 1.2.3
*/
function schema_premium_vc_remove_wp_admin_bar_buttons() {

	if ( class_exists( 'Vc_Manager' ) ) {

		if (function_exists('vc_disable_frontend') ) {
			 
			// Disable frontend editor
			//
			vc_disable_frontend();
		}

		if (function_exists('vc_frontend_editor') ) {

			remove_action( 'admin_bar_menu', array( vc_frontend_editor(), 'adminBarEditLink' ), 1000 );
		}
	}
}
