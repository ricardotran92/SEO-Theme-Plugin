<?php
/**
 * Listing Pro plugin
 *
 *
 * plugin url: https://listingprowp.com/
 * @since 1.2.4
 */
 
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'schema_output', 'schema_premium_listingpro_markup_output', 99 );
/**
 * Extend QAPage markup based on DW Question Answer plugin
 *
 * @since 1.1.2.8
 * @param array $schema markup
 * @return array
 */
function schema_premium_listingpro_markup_output( $schema ){
	
	global $post;

	if ( ! isset($post->ID ) )
		return $schema;

	if ( ! function_exists( 'listing_get_metabox_by_ID' ) ) 
		return $schema;

	$enabled = schema_wp_get_option( 'listingpro_enabled' );
	
	// Run only if enabled, and on single listing 
	//
	if ( $enabled == 'enabled' && is_singular('listing') ) {

		$listing = get_post_meta( $post->ID, 'lp_listingpro_options', true );
		
		// Debug
		//echo'<pre>';print_r($listing);echo'</pre>';exit;

		// url
		// 
		if ( isset($listing['website']) ) {
			$schema['url'] = $listing['website'];
		}

		// logo
		// 
		if ( isset($listing['business_logo']) ) {
			$schema['logo'] = $listing['business_logo'];
		}

		// slogan
		// 
		if ( isset($listing['tagline_text']) ) {
			$schema['slogan'] = $listing['tagline_text'];
		}

		// image
		//
		$gallery_image_ids = get_post_meta( $post->ID, 'gallery_image_ids', true );
		
		if ( isset($gallery_image_ids) && $gallery_image_ids != '' ) {

			$gallery_images = explode(',', $gallery_image_ids);
			$gallery 	 = array();
		
			 if ( ! empty($gallery_images) && is_array($gallery_images) ) {
				
				foreach ( $gallery_images as $attachment_id ) {
					$attachment_url = wp_get_attachment_url( $attachment_id );
					$gallery[] = $attachment_url;
				}
			 }

			 $schema['image'] = $gallery;

		}

		// email
		// 
		if ( isset($listing['email']) ) {
			$schema['email'] = $listing['email'];
		}

		// telephone
		// 
		if ( isset($listing['phone']) ) {
			$schema['telephone'] = $listing['phone'];
		}

		// priceRange
		// 
		if ( isset($listing['price_status']) ) {
			if ( $price_status = schema_premium_listingpro_price_status_to_range( $listing['price_status'] ) ) {
				$schema['priceRange'] = $price_status;
			}
		}
		
		// address
		//
		if ( isset($listing['gAddress']) ) {
			$schema['address'] = $listing['gAddress'];
		}

		// geo
		//
		if ( isset($listing['latitude']) || isset($listing['longitude']) ) {

			$schema['geo'] = array(
				'@type' => 'GeoCoordinates',
			);

			if ( isset($listing['latitude']) ) {
				$schema['geo']['latitude'] = $listing['latitude'];
			}

			if ( isset($listing['longitude']) ) {
				$schema['geo']['longitude'] = $listing['longitude'];
			}
		}
		
		// openingHoursSpecification
		//
		if ( isset($listing['business_hours']) && is_array($listing['business_hours']) ) {
			foreach ( $listing['business_hours'] as $dayOfWeek => $timings ) {	
				$openingHoursSpecification[] = array(
					'@type' => 'OpeningHoursSpecification',
					'dayOfWeek'	=> $dayOfWeek,
					'opens' 		=> $timings['open'],
					'closes' 	=> $timings['close'],
				);
			}

			$schema['openingHoursSpecification'] = $openingHoursSpecification;
		}

		// FAQPage
		//
		if ( isset($listing['faqs']) && is_array($listing['faqs']) ) {
			
			$faqs = array();

			$faq_count = count($listing['faqs']['faq']);
			 
			for ( $k = 0 ; $k <= $faq_count; $k++ ) { 
				
				if ( isset($listing['faqs']['faq'][$k]) ) {
					$faqs[] = array(
						'@type' => 'Question',
						'name'  => $listing['faqs']['faq'][$k],
						'acceptedAnswer' => array(
							'@type' => 'Answer',
							'text'	=> isset($listing['faqs']['faqans'][$k]) ? $listing['faqs']['faqans'][$k] : '',
						)
					);
				}
				
			}

			$schema['mainEntityOfPage']['hasPart'][] = array(
				'@type' => 'FAQPage',
				'mainEntity' => $faqs,
			);
		}

		// video
		//
		//if ( isset($listing['video']) && $listing['video'] != '' ) {
		//	$video = schema_premium_get_video_object_markup_single( $post->ID, $listing['video']);
		//	echo'<pre>';print_r($video);echo'</pre>';exit;
		//}


		// sameAs
		//
		if ( isset($listing['twitter']) && $listing['twitter'] != '' ) {
			$schema['sameAs'][] = $listing['twitter'];
		}
		if ( isset($listing['facebook']) && $listing['facebook'] != '' ) {
			$schema['sameAs'][] = $listing['facebook'];
		}
		if ( isset($listing['linkedin']) && $listing['linkedin'] != '' ) {
			$schema['sameAs'][] = $listing['linkedin'];
		}
		if ( isset($listing['youtube']) && $listing['youtube'] != '' ) {
			$schema['sameAs'][] = $listing['youtube'];
		}
		if ( isset($listing['instagram']) && $listing['instagram'] != '' ) {
			$schema['sameAs'][] = $listing['instagram'];
		}
		
		// reviews
		//
		if ( isset($listing['reviews_ids']) ) {

			$reviews_ids = explode(',', $listing['reviews_ids']);
			$reviews 	 = array();

			if ( ! empty($reviews_ids) && is_array($reviews_ids) ) {
				
				foreach ( $reviews_ids as $review_id ) {

					$lp_review = get_post($review_id);
					
					$author_id 	= $lp_review->post_author;
					$title 		= $lp_review->post_title;
					$reviewBody = $lp_review->post_content;
	
					$review = array(
						'@type' => 'Review',
						'name' 			=> $title,
						'datePublished'	=> get_the_date('c', true),
						'dateModified'  => get_the_modified_date('c', true),
						'reviewBody' => $reviewBody,
						'author'	=> array(
							'@type' => 'Person',
							'name'	=> get_the_author_meta( 'nicename', $author_id ),
							'url'	=> get_the_author_meta( 'user_url', $author_id ),
						)
					);

					// reviewRating
					//
					$rating = get_post_meta( $review_id, 'rating', true );

					if ( isset($rating) && $rating != '' ) {
						$review['reviewRating'] = array(
							'@type' => 'Rating',
							'ratingValue'	=> $rating,
							'bestRating'	=> 5,
							'worstRating'	=> 1,
						);
					}
					
					// Add it to our reviews array
					//
					$reviews[] = $review;

				} // end foreach
				
				// Add reviews to markup output_add_rewrite_var
				//
				$schema['review'] = $reviews;

				// aggregateRating
				//
				$listing_rate = get_post_meta( $post->ID, 'listing_rate', true );
				
				if ( isset($listing_rate) && $listing_rate != '' ) {
					
					$schema['aggregateRating'] = array(
						'@type' => 'AggregateRating',
						'ratingValue'	=> $listing_rate,
						'bestRating'	=> 5,
						'worstRating'	=> 1,
						'ratingCount'	=> count($reviews_ids),
						'reviewCount'	=> count($reviews_ids),
					);
				}
				
			} // end if

		} // if isset reviews_ids
		
	}
	
	return $schema;
}

function schema_premium_listingpro_price_status_to_range( $price_status ) {

	$data = array(
		'inexpensive' 		=> '$',
		'moderate' 			=> '$$',
		'pricey' 			=> '$$$',
		'ultra_high_end'	=> '$$$$',
	);

	if ( isset($data[$price_status]) ) {
		return $data[$price_status];
	}

	return false;
}

add_action( 'admin_init', 'schema_premium_listingpro_register_settings', 1 );
/*
* Register settings 
*
* @since 1.1.2.8
*/
function schema_premium_listingpro_register_settings() {
	
	add_filter( 'schema_wp_settings_integrations', 'schema_premium_listingpro_settings', 30 );
}

/*
* Settings 
*
* @since 1.1.2.8
*/
function schema_premium_listingpro_settings( $settings ) {

	$info = ' <span style="color:#8a8a8a;margin-top:3px;" class="dashicons dashicons-admin-plugins"></span>';

	if ( function_exists( 'listing_get_metabox_by_ID' ) ) {
		$info = ' <span style="color:#48b142;margin-top:3px;" class="dashicons dashicons-admin-plugins"></span>';
	}

	$settings['main']['listingpro_enabled'] = array(
		'id' => 'listingpro_enabled',
		'name' => __( 'Listing Pro', 'schema-premium' ),
		'desc' => $info,
		'type' => 'select',
		'options' => array(
			'enabled'	=> __( 'Enabled', 'schema-premium'),
			'disabled'	=> __( 'Disabled', 'schema-premium')
		),
		'std' => 'enabled',
		'tooltip_title' => __('When enabled', 'schema-premium'),
		'tooltip_desc' => __('Schema plugin will add markup for listings.', 'schema-premium'),
	);
	
	return $settings;
}
