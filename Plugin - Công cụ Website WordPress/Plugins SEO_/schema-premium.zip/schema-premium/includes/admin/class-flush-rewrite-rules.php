<?php
/**
 * @package 	Schema Premium - Class Flush Rewrite Rules
 * @category 	Core
 * @author 		Hesham Zebida
 * @version 	1.0.0
 * @since 		1.2.4
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists('Schema_Premium_Flush_Rewrite_Rules') ) :
	/**
	 * Transient Update
	 *
	 * @since 1.0.0
	 */
	class Schema_Premium_Flush_Rewrite_Rules {
		
		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			$this->init();
		}
	
		/**
		* Init
		*
		* @since 1.0.0
	 	*/
		public function init() {

			// Fires after update settings 
			//
			add_action( 'init', array( $this, 'late_flush_rewrite_rules'), 999999 );
		}
		
		/**
		* Flush rewrite rules on settings update
		*
		* @since 1.0.0
		* @return bool
		*/
		public function late_flush_rewrite_rules() {

			if ( ! $option = get_option( 'schema_flush_rewrite_rules' ) ) {
                return false;
            }
        
            if ( $option == 1 ) {
                
                // Flush rewrite rules
                //
                flush_rewrite_rules();

                update_option( 'schema_flush_rewrite_rules', 0 );
        
            }
        
            return true;
        }

	}
	
	$schema_flush_rewrite_rules = new Schema_Premium_Flush_Rewrite_Rules();
	
endif;
