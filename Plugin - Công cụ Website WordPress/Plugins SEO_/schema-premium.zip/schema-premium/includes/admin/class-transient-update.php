<?php
/**
 * @package 	Schema Premium - Class Schema Transient Update
 * @category 	Core
 * @author 		Hesham Zebida
 * @version 	1.0.0
 * @since 		1.2.3
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists('Schema_Premium_Transient_Update') ) :
	/**
	 * Transient Update
	 *
	 * @since 1.0.0
	 */
	class Schema_Premium_Transient_Update {
		
		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			$this->init();
		}
	
		/**
		* Init
		*
		* @since 1.0.0
	 	*/
		public function init() {

			// Fires after update settings 
			//
			add_action( 'schema_wp_settings_doing_section', array( $this, 'settings_update' ) );
			
			// Fires after saving a schema post type entry
			//
			add_action( 'save_post', array( $this, 'save_post' ), 10, 2 );

			// Fires after changing menu order: for Simple Custom Post Order plugin
			//
			add_action( 'scp_update_menu_order', array( $this, 'update_menu_order' ) );
			
			// Fires after a transient is deleted
			//
			add_action( 'deleted_transient', array( $this, 'set_transient' ) );
		}
		
		/**
		* On delete site transient via some plugin
		*
		* @since 1.0.0
		* @return array
		*/
		public function set_transient( $transient ) {

			// Trigger the location target function, retuls will be saved in transient
			//
			schema_wp_get_enabled_location_targets();

			return $transient;
		}

		/**
		* Update transient on settings update
		*
		* @since 1.0.0
		* @return array
		*/
		public function settings_update( $options ) {
		
			delete_transient( 'schema_supported_types' );
			delete_transient( 'schema_cpt_enabled' );
			delete_transient( 'schema_knowledge_graph' );
			delete_transient( 'schema_sitelinks_search_box' );
			delete_transient( 'schema_site_nav_element' );
			delete_transient( 'schema_publisher' );
			
			delete_transient( 'schema_location_targets_query');
			
			// Debug
			//echo'<pre>';print_r($options);echo'</pre>';exit;

			// Trigger the location target function,
			// retuls will be saved in transient
			//
			schema_wp_get_enabled_location_targets();

			return $options;
		}

		/**
		* Update transient on menu order, for Simple Custom Post Order plugin
		*
		* @since 1.0.0
		* @return array
		*/
		public function update_menu_order() {
			
			delete_transient( 'schema_location_targets_query');
		}

		/**
		* Update transient on save post
		*
		* @since 1.0.0
		* @return array
		*/
		public function save_post( $post_id, $post ) {
			
			if ( ! isset( $GLOBALS['post']->ID ) )
				return NULL;
		
			if ( 'schema' != $post->post_type ) {
				return $post_id;
			}
				
			if( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) 
				return NULL;
		
			delete_transient( 'schema_location_targets_query');
			
			return $post_id;
		}

	}
	
	$schema_transient_update = new Schema_Premium_Transient_Update();
	
endif;
