<?php
/**
 * Cache 
 *
 * @package     Schema
 * @subpackage  Functions
 * @copyright   Copyright (c) 2021, Hesham Zebida
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0.0
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'schema_wp_types', 'schema_premium_get_supported_schemas_cache' );
/**
 * Get supported schema.org types
 *
 * @since 1.2.3
 * @return array
 */
function schema_premium_get_supported_schemas_cache( $supported_schemas ) {

	$schemas = get_transient( 'schema_types' );

	if ( false === $schemas ) {

		$schemas = $supported_schemas;

		set_transient( 'schema_types', $schemas, 60 );
	}

	return $schemas;
}

add_filter( 'schema_wp_cpt_enabled_post_types', 'schema_wp_cpt_enabled_post_types_cache' );
/**
 * Get supported schema.org types
 *
 * @since 1.2.3
 * @return array
 */
function schema_wp_cpt_enabled_post_types_cache( $cpt_enabled ) {

	$enabled = get_transient( 'schema_enabled_types' );

	if ( false === $enabled ) {

		$enabled = $cpt_enabled;

		set_transient( 'schema_enabled_types', $enabled, 60 );
	}

	return $enabled;
}

add_filter( 'schema_wp_knowledge_graph_json', 'schema_premium_get_knowledge_graph_json_cache' );
/**
 * Get supported schema.org types
 *
 * @since 1.2.3
 * @return array
 */
function schema_premium_get_knowledge_graph_json_cache( $knowledge_graph ) {

	$knowledge_graph_cache = get_transient( 'schema_knowledge_graph' );

	if ( false === $knowledge_graph_cache ) {

		$knowledge_graph_cache = $knowledge_graph;

		set_transient( 'schema_knowledge_graph', $knowledge_graph_cache, 60 );
	}

	return $knowledge_graph_cache;
}

add_filter( 'schema_wp_output_sitelinks_search_box', 'schema_premium_get_sitelinks_search_box_markup_cache' );
/**
 * Get supported schema.org types
 *
 * @since 1.2.3
 * @return array
 */
function schema_premium_get_sitelinks_search_box_markup_cache( $sitelinks_search_box ) {

	$sitelinks_search_box_cache = get_transient( 'schema_sitelinks_search_box' );

	if ( false === $sitelinks_search_box_cache ) {

		$sitelinks_search_box_cache = $sitelinks_search_box;

		set_transient( 'schema_sitelinks_search_box', $sitelinks_search_box_cache, 60 );
	}

	return $sitelinks_search_box_cache;
}

add_filter( 'schema_wp_publisher', 'schema_wp_get_publisher_array_cache' );
/**
 * Get supported schema.org types
 *
 * @since 1.2.3
 * @return array
 */
function schema_wp_get_publisher_array_cache( $publisher ) {

	$publisher_cache = get_transient( 'schema_publisher' );

	if ( false === $publisher_cache ) {

		$publisher_cache = $publisher;

		set_transient( 'schema_publisher', $publisher_cache, 60 );
	}

	return $publisher_cache;
}
