<?php

if ( ! class_exists( 'schema_acf_field_seo_focus_keyword' ) ) :

	class schema_acf_field_seo_focus_keyword extends acf_field {

		/*
		*  initialize
		*
		*  This function will setup the field type data
		*
		*  @type    function
		*  @date    5/03/2014
		*  @since   5.0.0
		*
		*  @param   n/a
		*  @return  n/a
		*/

		function initialize() {

			// vars
			$this->name     = 'schema_seo_focus_keyword';
			$this->label    = __( 'SEO Focus Keyword', 'schema-premium' );
			$this->category = 'Schema';
			$this->defaults = array(
				'default_value' => '',
				'maxlength'     => '',
				'placeholder'   => '',
				'prepend'       => '',
				'append'        => '',
			);

			add_action('acf/save_post', array( $this, 'update_score' ), 20); 

		}

		/*
		*  input_admin_enqueue_scripts()
		*
		*  This action is called in the admin_enqueue_scripts action on the edit screen where your field is created.
		*  Use this action to add CSS + JavaScript to assist your render_field() action.
		*
		*  @type	action (admin_enqueue_scripts)
		*  @since	1.0.0
		*  @date	27/11/2018
		*
		*  @param	n/a
		*  @return	n/a
		*/
		
		function input_admin_enqueue_scripts() {
			
			$dir = plugin_dir_url( __FILE__ );
			
			wp_enqueue_style( 'schema-bootstrap', SCHEMAPREMIUM_PLUGIN_URL . 'assets/css/iso_bootstrap4.1.0.min.css' ); 
			wp_enqueue_script( 'schema-acf-input-dragsort', SCHEMAPREMIUM_PLUGIN_URL . 'assets/js/dragsort.js' );
			
		}

		/*
		*  render_field()
		*
		*  Create the HTML interface for your field
		*
		*  @param   $field - an array holding all the field's data
		*
		*  @type    action
		*  @since   3.6
		*  @date    23/01/13
		*/

		function render_field( $field ) {
			$html = '';

			// Prepend text.
			if ( $field['prepend'] !== '' ) {
				$field['class'] .= ' acf-is-prepended';
				$html           .= '<div class="acf-input-prepend">' . acf_esc_html( $field['prepend'] ) . '</div>';
			}

			// Append text.
			if ( $field['append'] !== '' ) {
				$field['class'] .= ' acf-is-appended';
				$html           .= '<div class="acf-input-append">' . acf_esc_html( $field['append'] ) . '</div>';
			}

			// Input.
			$input_attrs = array();
			foreach ( array( 'type', 'id', 'class', 'name', 'value', 'placeholder', 'maxlength', 'pattern', 'readonly', 'disabled', 'required' ) as $k ) {
				if ( isset( $field[ $k ] ) ) {
					$input_attrs[ $k ] = $field[ $k ];
				}
			}

			// Set field type to text
			//
			$input_attrs[ 'type' ] = 'text';
			
			$html .= '<div class="acf-input-wrap">' . acf_get_text_input( acf_filter_attrs( $input_attrs ) ) . '</div>';

			// Score
			//
			/*$score_saved = get_post_meta(get_the_ID(), $field[ 'key' ] . '_score', true); 
			
			if ( isset($score_saved) && $score_saved != '' ) {
				$score = $score_saved;
			} else {
				$score = $this->get_score( get_the_ID(), $field );
			}*/
			$score = $this->get_score( get_the_ID(), $field );

			$keyword_score = '<div class="schema-seo-keyword-score">';
			$keyword_score .= '<div class="bootstrap">';
			//$keyword_score .= '<a href="#" class="badge badge-success">'.$score.' / 100</a>';
			$keyword_score .= '<span class="badge badge-success"><span class="keyword-score">'.$score.'</span> / 100</span>';
			$keyword_score .= '</div>';
			$keyword_score .= '</div>';

			// start
			//
			$check = '<ul class="schema-seo-check-focus-keywords">';

			// Focus Keywords check
			//
			$focus_keywords 	= get_field( 'schema_seo_focus_keywords', get_the_ID() );
			$seo_title 			= get_field( 'schema_seo_title', get_the_ID() );
			$seo_description 	= get_field( 'schema_seo_description', get_the_ID() );
			$seo_permalink 		= get_field( 'schema_seo_permalink', get_the_ID() );
			$keywords_json 		= json_decode($focus_keywords);

			//echo '<pre>'; print_r($keywords_json); echo '</pre>';exit;

			// Focus Keyword : Have been set and used!
			//
			if ( isset($focus_keywords) && $focus_keywords != '' ) {
				$class 	= ' text-success';  
				//$check .= '<li class="schema-seo-check-focus-keywords'.$class.'">'.__('You\'ve never used this focus keyword before, very good.', 'schema-premium').'</li>';
				$check .= '<li class="schema-seo-check-focus-keywords-used'.$class.'">'.__('You\'ve used a focus keyword!', 'schema-premium').'</li>';
			} else {
				$class 	= ' text-danger';
				$check .= '<li class="schema-seo-check-focus-keywords-used'.$class.'">'.__('Set a Focus Keyword for this content.', 'schema-premium').'</li>';
			}

			//
			// Focus Keywords check for SEO Title and SEO Description
			//
			if ( !empty($keywords_json)) {

				// Primary keyword :  SEO Title
				//
				$primary_keyword 	= $keywords_json[0];
				$keyword_is_used 	= strpos(strtolower($seo_title), strtolower($primary_keyword->value));
				$class_keyword 		= ' keyword-title-' . str_replace(' ', '-', strtolower($primary_keyword->value));

				if ( $keyword_is_used !== false ) {
					$class 	= ' text-success';  
					$check .= '<li class="schema-seo-check-focus-keywords-title'. $class_keyword . $class.'">'.__('Focus Keyword: <b>'.$primary_keyword->value.'</b> has been added to the SEO Title, good job!', 'schema-premium').'</li>';
				} else {
					$class 	= ' text-danger';
					$check .= '<li class="schema-seo-check-focus-keywords-title'. $class_keyword . $class.'">'.__('Focus Keyword: <b>'.$primary_keyword->value.'</b> does not appear in the SEO Title.', 'schema-premium').'</li>';
				}
				//
				// Primary keyword : SEO Permalink
				//
				$keyword_is_used 	= strpos(strtolower($seo_permalink), str_replace(' ', '-', strtolower($primary_keyword->value)));
				$class_keyword 		= ' keyword-permalink-' . str_replace(' ', '-', strtolower($primary_keyword->value));

				if ( $keyword_is_used !== false ) {
					$class 	= ' text-success';  
					$check .= '<li class="schema-seo-check-focus-keywords-permalink'. $class_keyword . $class.'">'.__('Focus Keyword: <b>'.$primary_keyword->value.'</b> has been added to the SEO Permalink, good job!', 'schema-premium').'</li>';
				} else {
					$class 	= ' text-danger';
					$check .= '<li class="schema-seo-check-focus-keywords-permalink'. $class_keyword . $class.'">'.__('Focus Keyword: <b>'.$primary_keyword->value.'</b> does not appear in the SEO Permalink.', 'schema-premium').'</li>';
				}

				// Primary & Secondary keywords : SEO Description
				//
				foreach ($keywords_json as $keyword ) {
					
					$class_keyword = ' keyword-description-' . str_replace(' ', '-', strtolower($keyword->value));

					$keyword_is_used = strpos(strtolower($seo_description), strtolower($keyword->value));
					
					if ( $keyword_is_used !== false ) {
						$class 	= ' text-success';  
						$check .= '<li class="schema-seo-check-focus-keywords-description'. $class_keyword . $class.'">'.__('Focus Keyword: <b>'.$keyword->value.'</b> has been added to the SEO Description, good job!', 'schema-premium').'</li>';
					} else {
						$class 	= ' text-danger';
						$check .= '<li class="schema-seo-check-focus-keywords-description'. $class_keyword . $class.'">'.__('Focus Keyword: <b>'.$keyword->value.'</b> does not appear in the SEO Description.', 'schema-premium').'</li>';
					}
				}

			};

			//
			// end
			//
			$check .= '</ul>';

			// Display.
			echo $html .$keyword_score . $check;
		}


		/*
		*  render_field_settings()
		*
		*  Create extra options for your field. This is rendered when editing a field.
		*  The value of $field['name'] can be used (like bellow) to save extra data to the $field
		*
		*  @param   $field  - an array holding all the field's data
		*
		*  @type    action
		*  @since   3.6
		*  @date    23/01/13
		*/

		function render_field_settings( $field ) {

			// default_value
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Default Value', 'acf' ),
					'instructions' => __( 'Appears when creating a new post', 'acf' ),
					'type'         => 'text',
					'name'         => 'default_value',
				)
			);

			// placeholder
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Placeholder Text', 'acf' ),
					'instructions' => __( 'Appears within the input', 'acf' ),
					'type'         => 'text',
					'name'         => 'placeholder',
				)
			);

			// prepend
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Prepend', 'acf' ),
					'instructions' => __( 'Appears before the input', 'acf' ),
					'type'         => 'text',
					'name'         => 'prepend',
				)
			);

			// append
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Append', 'acf' ),
					'instructions' => __( 'Appears after the input', 'acf' ),
					'type'         => 'text',
					'name'         => 'append',
				)
			);

			// maxlength
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Character Limit', 'acf' ),
					'instructions' => __( 'Leave blank for no limit', 'acf' ),
					'type'         => 'number',
					'name'         => 'maxlength',
				)
			);

		}

		/**
		 * Return the field object.
		 *
		 * @param  
		 * @return array $field
		 */
		function get_field_object() {

			$field = get_field_object('feild_schema_seo_focus_keywords');

			return $field;
		}
		
		/**
		 * Return the score.
		 *
		 * @param string $post_id, array $field
		 * @return int $score
		 */
		function get_score( $post_id = 0, $field = array() ) {

			$score 				= 0;
			$focus_keywords 	= get_field( 'schema_seo_focus_keywords', $post_id );
			$seo_title 			= get_field( 'schema_seo_title', $post_id );
			$seo_description 	= get_field( 'schema_seo_description', $post_id );
			$seo_permalink 		= get_field( 'schema_seo_permalink', $post_id );
			$keywords_json 		= json_decode($focus_keywords);
			
			if ( !empty($keywords_json)) {

				//echo '<pre>'; print_r($primary_keyword); echo '</pre>';exit;

				//
				// Primary focus keyword
				//
				// SEO Title
				//
				$keyword_is_used = strpos(strtolower($seo_title), strtolower($keywords_json[0]->value));
				//
				if ( $keyword_is_used !== false ) {
						$score = $score + 70; 
				}
				//
				// SEO Description
				//
				$keyword_is_used = strpos(strtolower($seo_description), strtolower($keywords_json[0]->value));
				//
				if ( $keyword_is_used !== false ) {
						$score = $score + 20; 
				} 
				//
				// SEO Permalink
				//
				$keyword_is_used = strpos(strtolower($seo_permalink), str_replace(' ', '-', strtolower($keywords_json[0]->value)));
				//
				if ( $keyword_is_used !== false ) {
						$score = $score + 10; 
				} 
				
				//
				// Secondary keywords
				//
				foreach ($keywords_json as $keyword ) {
					
					// pass primary keyword check
					//
					if ( $keyword->value === $keywords_json[0]->value ) continue;
						
					// SEO Title
					//
					$keyword_is_used = strpos(strtolower($seo_title), strtolower($keyword->value));
					//
					if ( $keyword_is_used !== false ) {
						 $score = $score + 70;
					}
					
					// SEO Description
					//
					$keyword_is_used = strpos(strtolower($seo_description), strtolower($keyword->value));
					//
					if ( $keyword_is_used !== false ) {
						 $score = $score + 20;
					} 

					// SEO Permalink
					//
					$keyword_is_used = strpos(strtolower($seo_permalink), str_replace(' ', '-', strtolower($keyword->value)));
					//
					if ( $keyword_is_used !== false ) {
						 $score = $score + 10;
					} 
				}
				
				// Get average
				//
				$score = $score / count($keywords_json);
			}
			
			return (int) $score;
		}

		/**
		 * Update the score.
		 *
		 * @param string $post_id
		 * @return null
		 */
		function update_score( $post_id ) {
			
			$field = $this->get_field_object();
			$score = $this->get_score( $post_id, $field);
			
			if ( isset($field['key']) ) {
				update_field( $field['key'].'_score', $score, $post_id );
			}
		}

		/**
		 * validate_value
		 *
		 * Validates a field's value.
		 *
		 * @date    29/1/19
		 * @since   5.7.11
		 *
		 * @param   (bool|string) Whether the value is vaid or not.
		 * @param   mixed                                          $value The field value.
		 * @param   array                                          $field The field array.
		 * @param   string                                         $input The HTML input name.
		 * @return  (bool|string)
		 */
		function validate_value( $valid, $value, $field, $input ) {

			// Check maxlength
			if ( $field['maxlength'] && ( acf_strlen( $value ) > $field['maxlength'] ) ) {
				return sprintf( __( 'Value must not exceed %d characters', 'acf' ), $field['maxlength'] );
			}

			// Return.
			return $valid;
		}

		/**
		 * Return the schema array for the REST API.
		 *
		 * @param array $field
		 * @return array
		 */
		function get_rest_schema( array $field ) {
			$schema = parent::get_rest_schema( $field );

			if ( ! empty( $field['maxlength'] ) ) {
				$schema['maxLength'] = (int) $field['maxlength'];
			}

			return $schema;
		}

		/**
		* Admin Footer 
		*
		* @since 1.0.0
		* @return void
		*/
		public function input_admin_footer() {
			
			global $post;

			?>
			
			<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>
			<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
			<link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />

			<style type="text/css">
				 .acf-input-wrap .tagify {
					width: 100%;
					flex-wrap: nowrap;
				}
				.acf-input-wrap .tagify .tagify__tag-text {
					font-size: 14px;
				}
				.acf-input-wrap .tagify .tagify__tag-text {
					color: #646970;
					font-weight: 300;
				}
				.acf-input-wrap .tagify tag:first-child .tagify__tag-text {
					color: #28a745;
					font-weight: 600;
				}

				.dragsort--noAnim,
				.dragsort--noAnim ~ [draggable]{
					transition: 0s !important;
				}

				.dragsort--dragStart .dragsort--dragElem {
					opacity: 0;
				}

				.dragsort--dragStart .dragsort--hide {
					width: 0 !important;
					height: 0 !important;
					padding: 0 !important;
					margin: 0 !important;
					border-width: 0 !important;
				}

				.dragsort--dragStart > *{
					transition: var(--dragsort-trans-dur, .18s) cubic-bezier(.6, .1, .4, 1.2);
				}

				.dragsort--dragStart > * > *{
					pointer-events: none;
				}

				.schema-seo-keyword-score .bootstrap .badge {
					float: right;
					margin-top: 10px;
					display: block;
					font-size: 14px;
				}
			</style>
		 
			<script type="text/javascript">
				(function($) {

					acf.add_action('load', function( $el ){

						// Set classes to reset 
						//
						var classes = "text-success text-danger text-warning";
						
						// The DOM element you wish to replace with Tagify
						//
						var input = document.querySelector('#acf-feild_schema_seo_focus_keywords');
						
						// initialize Tagify on the above input node reference
						//
						tagify = new Tagify(input, {
							maxTags : 3,
							//originalInputValueFormat: valuesArr => valuesArr.map(item => item.value).join(',')
						});

						//
						// using 3-party script "dragsort"
						// https://github.com/yairEO/dragsort
						//
						var dragsort = new DragSort(tagify.DOM.scope, {
							selector:'.'+tagify.settings.classNames.tag,
							callbacks: {
								dragEnd: onDragEnd
							}
						})

						function onDragEnd(elm){
							tagify.updateValueByDOMTags()
						}
						//
						//DragSort( document.querySelector('.acf-input-wrap .tagify') )

						//
						// Focus Keywords field on change
						//
						tagify.on('change', function(e){
							//console.log(e.detail);
							var focus_keywords 	= e.detail.value;
							var seo_check 		= 'text-danger'; // define default value 
							var keywords 		= JSON.parse( e.detail.value );

							// Focus Keywords are used
							//
							if ( focus_keywords ) {
								//$(".schema-seo-check-focus-keywords").text("You’ve never used this focus keyword before, very good.");
								$(".schema-seo-check-focus-keywords-used").text("You’ve used a focus keyword!");
								var seo_check = 'text-success';  
					
							} else {
								
								$(".schema-seo-check-focus-keywords-used").text("Set a Focus Keyword for this content.");
							}
						
							$(".schema-seo-check-focus-keywords-used").removeClass(classes);
							$(".schema-seo-check-focus-keywords-used").addClass(seo_check);
							
							// First... remove all elements
							//
							const keywords_titles = document.querySelectorAll('.schema-seo-check-focus-keywords-title');
							keywords_titles.forEach(box => {
								box.remove();
							});
							const keywords_permalinks = document.querySelectorAll('.schema-seo-check-focus-keywords-permalink');
							keywords_permalinks.forEach(box => {
								box.remove();
							});
							const keywords_descriptions = document.querySelectorAll('.schema-seo-check-focus-keywords-description');
							keywords_descriptions.forEach(box => {
								box.remove();
							});
							//
							//	Now...
							//
							// Add elements back
							//
							// Get primary focus keyword
							//
							var primaryKeyword = keywords.shift(); 
							//
							//console.log(primaryKeyword);
							//

							// Primary focus keyword in SEO Title
							//
							var seo_title 		= $("#acf-feild_schema_seo_title").val();
							var keywords 		= JSON.parse( e.detail.value );
							var class_keyword 	= "keyword-title-"+primaryKeyword['value'].replace(/\s+/g, '-').toLowerCase();
							
							//
							//
							$(".schema-seo-check-focus-keywords").append('<li class="schema-seo-check-focus-keywords-title '+class_keyword+'">Focus Keyword: <b>'+primaryKeyword['value']+'</b> does not appear in the SEO title.</li>');
							//
							// Check if primary keyword is included in the SEO Title
							//
							var keyword_is_used = seo_title.toLowerCase().indexOf(primaryKeyword['value'].toLowerCase()); 
							//
							//
							if ( keyword_is_used !== -1 ) {
								// 👉️ substring is contained in string
								//
								$("."+class_keyword).text(""); // this to clean the li
								$("."+class_keyword).append("Focus Keyword: <b>" + primaryKeyword['value'] + "</b> has been added to the SEO Title, good job!");
								$("."+class_keyword).removeClass(classes);
								$("."+class_keyword).addClass(seo_check);
							} else {
								$("."+class_keyword).text(""); // this to clean the li
								$("."+class_keyword).append("Focus Keyword: <b>" + primaryKeyword['value'] + "</b> does not appear in the SEO Title.");
							}

							//
							// Primary focus keyword in SEO Permalink
							//
							var seo_permalink 	= $("#acf-feild_schema_seo_permalink").val();
							var keywords 		= JSON.parse( e.detail.value );
							var class_keyword 	= "keyword-permalink-"+primaryKeyword['value'].replace(/\s+/g, '-').toLowerCase();
							//
							//
							$(".schema-seo-check-focus-keywords").append('<li class="schema-seo-check-focus-keywords-permalink '+class_keyword+'">Focus Keyword: <b>'+primaryKeyword['value']+'</b> does not appear in the SEO Permalink.</li>');
							//
							// Check if primary keyword is included in the SEO Permalink
							//
							var keyword_is_used = seo_permalink.toLowerCase().indexOf(primaryKeyword['value'].replace(/\s+/g, '-').toLowerCase()); 
							//
							//
							if ( keyword_is_used !== -1 ) {
								// 👉️ substring is contained in string
								//
								$("."+class_keyword).text(""); // this to clean the li
								$("."+class_keyword).append("Focus Keyword: <b>" + primaryKeyword['value'] + "</b> has been added to the SEO Permalink, good job!");
								$("."+class_keyword).removeClass(classes);
								$("."+class_keyword).addClass(seo_check);
							} else {
								$("."+class_keyword).text(""); // this to clean the li
								$("."+class_keyword).append("Focus Keyword: <b>" + primaryKeyword['value'] + "</b> does not appear in the SEO Permalink.");
							}

							//
							//	Secondary keywords
							//
							//  
						 	//
							var seo_description = $("#acf-feild_schema_seo_description").val();
							//
							// Get fresh data, since we have used shift() eariler
							//
							var keywords = JSON.parse( e.detail.value );

							//
							// For SEO Description
							//
							for (var key in keywords) {
								var class_keyword = "keyword-description-"+keywords[key].value.replace(/\s+/g, '-').toLowerCase();
								 
								$(".schema-seo-check-focus-keywords").append('<li class="schema-seo-check-focus-keywords-description '+class_keyword+'">Focus Keyword: '+keywords[key].value+' does not appear in the SEO Description.</li>');
								
								if (keywords.hasOwnProperty(key)) {
									
									var keyword_is_used = seo_description.toLowerCase().indexOf(keywords[key].value.toLowerCase()); 
									
									if ( keyword_is_used !== -1 ) {
										// 👉️ substring is contained in string
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords[key].value + "</b> has been added to the SEO Description, good job!");
										
									} else {
										//
										// Not found
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords[key].value + "</b> does not appear in the SEO Description.");
										var seo_check = 'text-danger';  
									}
									$("."+class_keyword).removeClass(classes);
									$("."+class_keyword).addClass(seo_check);
								}
								
 							}
						});

						//
						// SEO Title field keyup
						//
						$("#acf-feild_schema_seo_title").keyup(function() {

							// The DOM element you wish to replace with Tagify
							//
							var input = document.querySelector('#acf-feild_schema_seo_focus_keywords');
							
							// initialize Tagify on the above input node reference
							//
							keywords = new Tagify(input, {
								maxTags : 3,
								//originalInputValueFormat: valuesArr => valuesArr.map(item => item.value).join(',')
							});

							var seo_title = $("#acf-feild_schema_seo_title").val();
							var seo_check = 'text-danger'; // define default value 
							 
							// Modify elements 
							//
							for (var key in keywords['value']) {
								 
								var class_keyword = "keyword-title-"+keywords['value'][key].value.replace(/\s+/g, '-').toLowerCase();
								 
								if (keywords['value'].hasOwnProperty(key)) {
									
									var keyword_is_used = seo_title.toLowerCase().indexOf(keywords['value'][key].value.toLowerCase()); 

									if ( keyword_is_used !== -1 ) {
										// 👉️ substring is contained in string
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords['value'][key].value + "</b> has been added to the SEO Title, good job!");
										var seo_check = 'text-success';  
										
									} else {
										//
										// Not found
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords['value'][key].value + "</b> does not appear in the SEO Title.");
										var seo_check = 'text-danger';  

									}
									$("."+class_keyword).removeClass(classes);
									$("."+class_keyword).addClass(seo_check);
								}
 							}

						});
						
						//
						// SEO Permalink field blur, not keyup this time so we can shorten and add slashes to permalink
						//
						$("#acf-feild_schema_seo_permalink").blur(function() {

							// The DOM element you wish to replace with Tagify
							//
							var input = document.querySelector('#acf-feild_schema_seo_focus_keywords');

							// initialize Tagify on the above input node reference
							//
							keywords = new Tagify(input, {
								maxTags : 3,
								//originalInputValueFormat: valuesArr => valuesArr.map(item => item.value).join(',')
							});

							var seo_permalink = $("#acf-feild_schema_seo_permalink").val();
							var seo_check = 'text-danger'; // define default value 
							
							// Modify elements 
							//
							for (var key in keywords['value']) {
								
								var class_keyword = "keyword-permalink-"+keywords['value'][key].value.trim().replace(/\s+/g, '-').toLowerCase();
								
								if (keywords['value'].hasOwnProperty(key)) {
									
									var keyword_is_used = seo_permalink.toLowerCase().indexOf(keywords['value'][key].value.trim().replace(/\s+/g, '-').toLowerCase()); 

									if ( keyword_is_used !== -1 ) {
										// 👉️ substring is contained in string
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords['value'][key].value + "</b> has been added to the SEO Permalink, good job!");
										var seo_check = 'text-success';  
										
									} else {
										//
										// Not found
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords['value'][key].value + "</b> does not appear in the SEO Permalink.");
										var seo_check = 'text-danger';  

									}
									$("."+class_keyword).removeClass(classes);
									$("."+class_keyword).addClass(seo_check);
								}
								
							}

						});

						//
						// SEO Description field keyup
						//
						$("#acf-feild_schema_seo_description").keyup(function() {

							// The DOM element you wish to replace with Tagify
							//
							var input = document.querySelector('#acf-feild_schema_seo_focus_keywords');
							
							// initialize Tagify on the above input node reference
							//
							keywords = new Tagify(input, {
								maxTags : 3,
								//originalInputValueFormat: valuesArr => valuesArr.map(item => item.value).join(',')
							});

							var seo_description = $("#acf-feild_schema_seo_description").val();
							var seo_check = 'text-danger'; // define default value 
							 
							// Modify elements 
							//
							for (var key in keywords['value']) {
								 
								var class_keyword = "keyword-description-"+keywords['value'][key].value.replace(/\s+/g, '-').toLowerCase();
								 
								if (keywords['value'].hasOwnProperty(key)) {
									
									var keyword_is_used = seo_description.toLowerCase().indexOf(keywords['value'][key].value.toLowerCase()); 

									if ( keyword_is_used !== -1 ) {
										// 👉️ substring is contained in string
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords['value'][key].value + "</b> has been added to the SEO description, good job!");
										var seo_check = 'text-success';  
										
									} else {
										//
										// Not found
										//
										$("."+class_keyword).text(""); // this to clean the li
										$("."+class_keyword).append("Focus Keyword: <b>" + keywords['value'][key].value + "</b> does not appear in the SEO description.");
										var seo_check = 'text-danger';  

									}
									$("."+class_keyword).removeClass(classes);
									$("."+class_keyword).addClass(seo_check);
								}
								
 							}

						});

						
					});
				
				})(jQuery);	
			</script>

			<?php	
		}

	}

	// initialize
	acf_register_field_type( 'schema_acf_field_seo_focus_keyword' );

endif; // class_exists check
