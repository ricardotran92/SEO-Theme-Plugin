<?php

if ( ! class_exists( 'schema_acf_field_seo_description' ) ) :

	class schema_acf_field_seo_description extends acf_field {

		/*
		*  initialize
		*
		*  This function will setup the field type data
		*
		*  @type    function
		*  @date    5/03/2014
		*  @since   5.0.0
		*
		*  @param   n/a
		*  @return  n/a
		*/

		function initialize() {

			// vars
			$this->name     = 'schema_seo_description';
			$this->label    = __( 'SEO Description', 'schema-premium' );
			$this->category = 'Schema';
			$this->defaults = array(
				'default_value' => '',
				'maxlength'     => '',
				'placeholder'   => '',
				'prepend'       => '',
				'append'        => '',
			);

			add_action('acf/save_post', array( $this, 'update_score' ), 20); 

		}

		/*
		*  input_admin_enqueue_scripts()
		*
		*  This action is called in the admin_enqueue_scripts action on the edit screen where your field is created.
		*  Use this action to add CSS + JavaScript to assist your render_field() action.
		*
		*  @type	action (admin_enqueue_scripts)
		*  @since	1.0.0
		*  @date	27/11/2018
		*
		*  @param	n/a
		*  @return	n/a
		*/
		
		function input_admin_enqueue_scripts() {
			
			$dir = plugin_dir_url( __FILE__ );
			
			wp_enqueue_style( 'schema-bootstrap', SCHEMAPREMIUM_PLUGIN_URL . 'assets/css/iso_bootstrap4.1.0.min.css' ); 
		}

		/*
		*  render_field()
		*
		*  Create the HTML interface for your field
		*
		*  @param   $field - an array holding all the field's data
		*
		*  @type    action
		*  @since   3.6
		*  @date    23/01/13
		*/

		function render_field( $field ) {
			
			global $post;

			$html = '';

			// Prepend text.
			if ( $field['prepend'] !== '' ) {
				$field['class'] .= ' acf-is-prepended';
				$html           .= '<div class="acf-input-prepend">' . acf_esc_html( $field['prepend'] ) . '</div>';
			}

			// Append text.
			if ( $field['append'] !== '' ) {
				$field['class'] .= ' acf-is-appended';
				$html           .= '<div class="acf-input-append">' . acf_esc_html( $field['append'] ) . '</div>';
			}

			// Input.
			$input_attrs = array();
			foreach ( array( 'type', 'id', 'class', 'name', 'value', 'placeholder', 'maxlength', 'pattern', 'readonly', 'disabled', 'required' ) as $k ) {
				if ( isset( $field[ $k ] ) ) {
					$input_attrs[ $k ] = $field[ $k ];
				}
			}

			// Set field type to text
			//
			$input_attrs[ 'type' ] = 'textarea';
			
			$html .= '<div class="acf-input-wrap">' . acf_get_textarea_input( acf_filter_attrs( $input_attrs ) ) . '</div>';

			$maxLength 			= $field['maxLength_seo'];
			$schema_seo_length 	= get_post_meta( $post->ID, $field[ '_name' ], true );
			$score_saved 		= get_post_meta($post->ID, $field[ 'key' ] . '_score', true); 
			
			if ( isset($score_saved) && $score_saved != '' ) {
				$score = $score_saved;
			} else {
				$score = $this->get_score( $post->ID, $field );
			}
			
			$class = 'bg-danger'; // define default value 

			if ( $score >= 80 && $score <= 100 ) {
				$class = 'bg-success';
			} else if ($score >= 50 && $score < 80 ) {
				$class = 'bg-warning';
			} else {
				$class = 'bg-danger';
			}

			echo '<div class="schema-seo-field"> 
					<div class="bootstrap">
						<div class="' .  $input_attrs[ 'id' ] . '-progress schema-seo-description-field">
							
							<div class="row">
								<div class="col-8">
									<div class="details">
										<span class="schema-seo-length">'.strlen($schema_seo_length).'</span> 
										/ <span class="max-length" >'.$maxLength.'</span> 
										| <span>'.__('Score', 'acf').': </span><span class="schema-seo-score">'.$score.'%</span>
									</div>
								</div>
								<div class="col-4">
									<div class="progress">
									<div class="progress-bar '.$input_attrs['id'].' '.$class.'" role="progressbar" style="width: '.$score.'%" aria-valuenow="'.$score.'" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>';

			//print_r($field);
			//echo'<pre>';print_r($field);echo'</pre>';

			// Display.
			echo $html;
		}


		/*
		*  render_field_settings()
		*
		*  Create extra options for your field. This is rendered when editing a field.
		*  The value of $field['name'] can be used (like bellow) to save extra data to the $field
		*
		*  @param   $field  - an array holding all the field's data
		*
		*  @type    action
		*  @since   3.6
		*  @date    23/01/13
		*/

		function render_field_settings( $field ) {

			// default_value
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Default Value', 'acf' ),
					'instructions' => __( 'Appears when creating a new post', 'acf' ),
					'type'         => 'text',
					'name'         => 'default_value',
				)
			);

			// placeholder
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Placeholder Text', 'acf' ),
					'instructions' => __( 'Appears within the input', 'acf' ),
					'type'         => 'text',
					'name'         => 'placeholder',
				)
			);

			// prepend
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Prepend', 'acf' ),
					'instructions' => __( 'Appears before the input', 'acf' ),
					'type'         => 'text',
					'name'         => 'prepend',
				)
			);

			// append
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Append', 'acf' ),
					'instructions' => __( 'Appears after the input', 'acf' ),
					'type'         => 'text',
					'name'         => 'append',
				)
			);

			// maxlength
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Character Limit', 'acf' ),
					'instructions' => __( 'Leave blank for no limit', 'acf' ),
					'type'         => 'number',
					'name'         => 'maxlength',
				)
			);

			// maxlength_seo
			acf_render_field_setting(
				$field,
				array(
					'label'        => __( 'Character Limit for SEO', 'acf' ),
					'instructions' => __( 'Leave blank for no limit', 'acf' ),
					'type'         => 'number',
					'name'         => 'maxlength_seo',
				)
			);

		}

		/**
		 * Return the field object.
		 *
		 * @param  
		 * @return array $field
		 */
		function get_field_object() {

			$field = get_field_object('feild_schema_seo_description');

			return $field;
		}
		
		/**
		 * Return the score.
		 *
		 * @param string $post_id, array $field
		 * @return int $score
		 */
		function get_score( $post_id = 0, $field = array() ) {

			$score = 0;

			if ( isset($field['maxLength_seo']) && $field['maxLength_seo'] > 0 ) {
				$schema_seo_length = get_field( $field[ '_name' ], $post_id );
				$score = mb_strlen($schema_seo_length) * 100 / $field['maxLength_seo'];
			}
			
			return (int) $score;
		}

		/**
		 * Update the score.
		 *
		 * @param string $post_id
		 * @return null
		 */
		function update_score( $post_id ) {
			
			$field = $this->get_field_object();
			$score = $this->get_score( $post_id, $field);
			
			if ( isset($field['key']) ) {
				update_field( $field['key'].'_score', $score, $post_id );
			}
		}

		/**
		 * validate_value
		 *
		 * Validates a field's value.
		 *
		 * @date    29/1/19
		 * @since   5.7.11
		 *
		 * @param   (bool|string) Whether the value is vaid or not.
		 * @param   mixed                                          $value The field value.
		 * @param   array                                          $field The field array.
		 * @param   string                                         $input The HTML input name.
		 * @return  (bool|string)
		 */
		function validate_value( $valid, $value, $field, $input ) {

			// Check maxlength
			if ( $field['maxlength'] && ( acf_strlen( $value ) > $field['maxlength'] ) ) {
				return sprintf( __( 'Value must not exceed %d characters', 'acf' ), $field['maxlength'] );
			}

			// Return.
			return $valid;
		}

		/*
		*  update_value()
		*
		*  This filter is applied to the $value before it is updated in the db
		*
		*  @type    filter
		*  @since   1.0.0
		*  @date    31/07/2022
		*
		*  @param   $value - the value which will be saved in the database
		*  @param   $post_id - the $post_id of which the value will be saved
		*  @param   $field - the field array holding all the field options
		*
		*  @return  $value - the modified value
		*/
		
		/*
		function update_value( $value, $post_id, $field ) {
			
			return $value;
		}
		*/

		/**
		 * Return the schema array for the REST API.
		 *
		 * @param array $field
		 * @return array
		 */
		function get_rest_schema( array $field ) {
			
			$schema = parent::get_rest_schema( $field );

			if ( ! empty( $field['maxlength'] ) ) {
				$schema['maxLength'] = (int) $field['maxlength'];
			}

			if ( ! empty( $field['maxlength_seo'] ) ) {
				$schema['maxlength_seo'] = (int) $field['maxlength_seo'];
			}

			return $schema;
		}

		/**
		* Admin Footer 
		*
		* @since 1.0.0
		* @return void
		*/
		public function input_admin_footer() {
			
			$post_id = schema_premium_get_post_ID();

			$field = $this->get_field_object();

			if ( ! array($field) || empty($field) )
				return;

			$maxLength_seo 	= $field['maxLength_seo'];
			$score 			= get_post_meta($post_id, $field['key'].'_score', true); 
			
			?>
			
			<style type="text/css">
				.acf-input .schema-seo-field .progress {
					margin: 6px 0;
					height: 6px;
				}
				.schema-seo-field .details {
					color: #646970;
					font-size: 12px;
					text-align: right;
				}
				.schema-seo-field .col-4,
				.schema-seo-field .col-8 {
					margin-bottom: 6px;
				}
			</style>
		 
			<script type="text/javascript">
				(function($) {
					
					acf.add_action('load', function( $el ){
						
						// On load get score from post meta
						//
						var score = <?php echo $score; ?>;
						$(".acf-<?php echo $field['key']; ?>").attr('aria-valuenow', score);
						$(".acf-<?php echo $field['key']; ?>").css({'width': score+'%'});

						// on key up
						//
						$('#acf-<?php echo $field['key']; ?>').keyup(function() {
							
							// Set vars 
							//
							var maxLength = <?php echo $maxLength_seo; ?>;
							var theLength = $("#acf-<?php echo $field['key']; ?>").val().length;
							var percentage = Math.floor( theLength * 100 / maxLength);
							
							$(".acf-<?php echo $field['key']; ?>").attr('aria-valuenow', percentage);
							//$(".acf-<?php echo $field['key']; ?>-progress").css({'width': percentage+'%'});
							$(".acf-<?php echo $field['key']; ?>-progress .schema-seo-length").text(theLength);
							$(".acf-<?php echo $field['key']; ?>-progress .schema-seo-score").text(percentage+'%');

							var bars = $(".acf-<?php echo $field['key']; ?>-progress .progress .progress-bar");
							
							for (i = 0; i < bars.length; i++) {
								//console.log(i);
								var progress = $(bars[i]).attr('aria-valuenow');
								$(bars[i]).width(progress + '%');

								$(bars[i]).removeClass("bg-success");
								$(bars[i]).removeClass("bg-warning");
								$(bars[i]).removeClass("bg-danger");

								if (progress >= "80") {
									$(bars[i]).addClass("bg-success");
								} else if (progress >= "50" && progress < "80") {
									$(bars[i]).addClass("bg-warning");
								} else {
									$(bars[i]).addClass("bg-danger");
								}
							}

						});

					});
				
				})(jQuery);	
			</script>

			<?php
			
		}

	}


	// initialize
	acf_register_field_type( 'schema_acf_field_seo_description' );

endif; // class_exists check
