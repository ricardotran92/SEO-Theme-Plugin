<?php
/**
 * ACF Blocks Functions
 *
 * @package     Schema
 * @subpackage  Schema - ACF
 * @copyright   Copyright (c) 2019, Hesham Zebida
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0.6
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'block_categories_all', 'schema_premium_acf_block_categories', 10, 2 );
/**
 * Adding a new (custom) block category, called Schema
 *
 * @since 1.0.6
 *
 * @param   array $block_categories                         Array of categories for block types.
 * @param   WP_Block_Editor_Context $block_editor_context   The current block editor context.
 *
 * return array
 */
function schema_premium_acf_block_categories( $block_categories, $block_editor_context ) {
    
    return array_merge(
        $block_categories,
        array(
            array(
                'slug' => 'schema-blocks',
                'title' => __('Schema', 'schema-wp'),
                //'icon'  => 'wordpress',
            ),
        )
    );
}
