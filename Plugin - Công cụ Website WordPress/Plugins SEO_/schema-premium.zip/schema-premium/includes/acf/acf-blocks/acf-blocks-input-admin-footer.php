<?php
/**
 * ACF Blocks Fixes
 *
 * @package     Schema
 * @subpackage  Schema - ACF
 * @copyright   Copyright (c) 2021, Hesham Zebida
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.2.4
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('acf/input/admin_footer', 'schema_premium_acf_block_input_admin_footer');
/**
 * Add to ACF input admin footer
 *
 * @since 1.2.4
 *
 * return void
 */
function schema_premium_acf_block_input_admin_footer() {

    // This is a fix for block repeater action button color
    //
    ?>
    <style>
      .acf-block-fields .acf-repeater .acf-actions .acf-button,
      .acf-block-fields .acf-repeater .acf-actions .acf-button:hover {
        color: #ffffff;
      }
    </style>
    <?php
}
