<?php
/**
 * ACF Location Rule for Schema - Opennings 
 *
 * @package     Schema
 * @subpackage  Schema Post Meta ACF
 * @copyright   Copyright (c) 2021, Hesham Zebida
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.2.5
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class ACF_Custom_Location_Is_Opennings extends ACF_Location {
	
	public function initialize() {
		
		$this->name 	= 'is_opennings';
		$this->label 	= __( 'Opening Hours Specification', 'schema-premium' );
		$this->category = 'Extra';
		$this->public 	= true;
	}
	
	public function get_values( $rule ) {
		
		$choices 			= array();
		$choices['true'] 	= 'true';
		$choices['false'] 	= 'false';
		
		return $choices;
	}

    public function match($rule, $screen, $field_group) {
		
		// Check screen args for "post_id" which will exist when editing a post.
    	// Return false for all other edit screens.
		//
		if ( isset($screen['post_id']) ) {
			$post_id = $screen['post_id'];
		} else {
			return false;
		}

		// Load the post object for this edit screen.
		//
		$post = get_post( $post_id );
		if ( !$post ) {
			return false;
		}
		
		$is_opennings_enable = schema_premium_meta_is_opennings();
		if ( empty($is_opennings_enable) ) {
			return false;
		}

		$result 		= false;
		$schema_enabled = schema_wp_get_enabled_location_targets();
					
		if ( ! empty($schema_enabled) ) {     
           
			// Get array value with unknown key name, which is schema post ID
			$schema_enabled = reset($schema_enabled);
			
			if ( $rule['operator'] == '==' ) {
				 // Get match of location target
				 $schema_location_target = schema_premium_get_location_target_match( $post_id );
				 
				 if ( ! empty($schema_location_target) ) :
					 foreach ( $schema_location_target as $locations => $location ) :
						 if ($location['match'] && in_array( $location['schema_type'], $is_opennings_enable ) ) {
							 $result = true;
							 break;
						 }
					 endforeach;
				 endif;
				 
			 } elseif ($rule['operator'] == '!=') {
				 $result = false;
			 }
			 if ($rule['value'] != 'true') {
				 $result = !$result;
			 } 
			 
		} //end of if !empty array
			
		return $result;
	}
}
