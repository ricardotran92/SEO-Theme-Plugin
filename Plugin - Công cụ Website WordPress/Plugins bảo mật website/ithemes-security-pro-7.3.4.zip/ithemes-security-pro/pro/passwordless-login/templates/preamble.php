<p class="itsec-pwls-login__title"><?php esc_html_e( 'Want an easier way to login?', 'it-l10n-ithemes-security-pro' ); ?></p>
<p class="itsec-pwls-login__description"><?php esc_html_e( 'Login quicker without a password.', 'it-l10n-ithemes-security-pro' ); ?></p>
