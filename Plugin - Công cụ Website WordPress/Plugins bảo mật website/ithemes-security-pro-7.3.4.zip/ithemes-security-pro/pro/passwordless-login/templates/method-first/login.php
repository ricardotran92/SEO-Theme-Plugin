<div class="itsec-pwls-login-wrap">
	<?php require( __DIR__ . '/../preamble.php' ); ?>

	<?php require( __DIR__ . '/../prompt-link.php' ); ?>

	<?php require( __DIR__ . '/../fallback.php' ); ?>
</div>
<script type="text/template" id="tmpl-itsec-pwls-login-prompt-form">
	<?php require( __DIR__ . '/../prompt-form-fields.php' ); ?>
</script>
