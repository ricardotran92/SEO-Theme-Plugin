/**
 * Internal dependencies
 */
import { AdminBar } from './components';
import './style.scss';

export default function App() {
	return (
		<>
			<AdminBar />
		</>
	);
}
