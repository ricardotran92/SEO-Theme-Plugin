<?php

return [
	'title' => __( 'Magic Links', 'it-l10n-ithemes-security-pro' ),
];
