<?php

( new ITSEC_Magic_Link_Lockout_Bypass() )->run();
