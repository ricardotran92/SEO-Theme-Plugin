<?php

return [
	'title' => __( 'Trusted Devices', 'it-l10n-ithemes-security-pro' ),
];
