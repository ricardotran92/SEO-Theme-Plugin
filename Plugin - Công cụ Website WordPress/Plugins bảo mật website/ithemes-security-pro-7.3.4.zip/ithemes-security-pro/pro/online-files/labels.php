<?php

return [
	'title' => __( 'Online Files', 'it-l10n-ithemes-security-pro' ),
];
