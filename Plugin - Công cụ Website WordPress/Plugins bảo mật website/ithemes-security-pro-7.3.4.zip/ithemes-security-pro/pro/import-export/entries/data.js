export { STORE_NAME } from './data/index';
