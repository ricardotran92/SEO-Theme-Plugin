<?php

require_once( __DIR__ . '/class-itsec-user-logging.php' );

return 'ITSEC_User_Logging';
