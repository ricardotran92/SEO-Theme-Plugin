<?php

namespace VendorDuplicator\Dropbox\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
