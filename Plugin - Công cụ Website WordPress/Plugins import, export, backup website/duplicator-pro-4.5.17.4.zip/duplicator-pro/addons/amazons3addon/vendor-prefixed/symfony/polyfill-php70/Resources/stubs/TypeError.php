<?php

namespace VendorDuplicator;

class TypeError extends \Error
{
}
\class_alias('VendorDuplicator\\TypeError', 'TypeError', \false);
