<?php

namespace VendorDuplicator;

class AssertionError extends \Error
{
}
\class_alias('VendorDuplicator\\AssertionError', 'AssertionError', \false);
