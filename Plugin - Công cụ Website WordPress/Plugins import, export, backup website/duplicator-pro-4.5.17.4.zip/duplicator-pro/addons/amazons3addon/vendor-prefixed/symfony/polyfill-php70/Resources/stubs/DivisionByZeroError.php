<?php

namespace VendorDuplicator;

class DivisionByZeroError extends \Error
{
}
\class_alias('VendorDuplicator\\DivisionByZeroError', 'DivisionByZeroError', \false);
