<?php

namespace VendorDuplicator;

class Error extends \Exception
{
}
\class_alias('VendorDuplicator\\Error', 'Error', \false);
