<?php

namespace VendorDuplicator\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
