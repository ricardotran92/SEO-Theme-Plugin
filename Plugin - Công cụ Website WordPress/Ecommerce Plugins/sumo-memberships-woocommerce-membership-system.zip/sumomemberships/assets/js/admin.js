/* global sm_admin_params ajaxurl */

jQuery(function ($) {
    'use strict';


    var SM_Admin = {
        init: function () {
            // Delete membership action
            $(document).on('click', '.sumo-memberships-delete', this.delete_mebership_action);
        }, delete_mebership_action: function (event) {
            let $this = $(event.currentTarget),
                    message = '';

            switch ($($this).data('action')) {
                case 'sumo_membership_plan':
                    message = confirm(sm_admin_params.sm_delete_plan_confirm_msg);
                    break;
                default:
                    message = confirm(sm_admin_params.sm_delete_member_confirm_msg);
                    break;

            }

            if (!message) {
                event.preventDefault( );
                return false;
            }
        }
    };
    SM_Admin.init();
});
