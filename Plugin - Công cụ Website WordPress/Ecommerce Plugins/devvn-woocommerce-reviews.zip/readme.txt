﻿/*
* Plugin DevVN Woocommerce Reviews
* Author: https://levantoan.com
*/

== Những thay đổi ==

= V1.0.7 - 10.08.2019 =

* Fix: Đếm lại tổng số review. đã loại trừ các review của admin trả lời trong admin

= V1.0.6  - 05.08.2019 =
* New: Thêm công cụ fake label xác nhận đã mua hàng
* Update: Thêm hiển thị list hình ảnh trong admin để dễ quản lý
* Add: Thêm ô nhập tên action để tùy biến vị trí reviews
* Update: Thêm tính năng bỏ upload ảnh khi đánh giá
* Fix: 1 số lỗi nhỏ

= V1.0.5  - 04.08.2019 =
* New: Thay đổi folder upload hình ảnh thành wp-content/uploads/woocommerce-reviews
* New: Loại bỏ các size ảnh khác chỉ để lại thumbnail và full size khi upload ảnh trong comment. Sẽ tối ưu số ảnh và dụng lượng cho hosting của bạn
* Add: Thêm chức năng chuyển đổi từ review cũ của website để tương thích với plugin
* Add: Thêm label "Quản trị viên" cho phần reviews

= V1.0.4  - 03.08.2019 =
* Update: Thêm phần chú ý sau khi cài đặt. Bỏ bắt buộc email trong setting https://levantoan.com/san-pham/devvn-woocommerce-reviews/#chu-y
* Fix: Sửa một số cảnh báo nhỏ

= V1.0.3  - 02.08.2019 =
* Fix: Sủa lỗi trả lời nhanh trong admin không hiện ra bên ngoài

= V1.0.2  - 02.08.2019 =
* Update: Thêm ô nhập vị trí ưu tiên hiển thị
* Fix: 1 số lỗi css trên flatsome theme

= V1.0.1  - 02.08.2019 =
* Fix: Sửa lỗi thiếu thư viện js wp.template

= V1.0.0 - 01.08.2019 =
* Ra mắt plugin