=== WooCommerce Product Reviews Pro ===
Author: skyverge
Tags: woocommerce
Requires at least: 5.6
Tested up to: 6.1.1
Requires PHP: 7.4

See https://docs.woocommerce.com/document/woocommerce-product-reviews-pro/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-product-reviews-pro' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
