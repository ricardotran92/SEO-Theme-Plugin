(function ($) {
    "use strict";
    /**
     * Add blog functionality
     */
    $(function () {

        /*
         * Top Menu Tab
         */
        $('body').on('click', '.smcw-top-tab-tigger', function () {
            $('.smcw-top-tab-tigger').removeClass('smcw-top-active');
            $(this).addClass('smcw-top-active');
            var active_tab_key = $('.smcw-top-tab-tigger.smcw-top-active').data('menu');
            $('.smcw-top-settings-wrap').removeClass('smcw-top-active-container');
            $('.smcw-top-settings-wrap[data-menu-ref="' + active_tab_key + '"]').addClass('smcw-top-active-container');
        });
        /*
         * Menu Tab
         */
        $('body').on('click', '.smcw-tab-tigger', function () {
            $('.smcw-tab-tigger').removeClass('smcw-active');
            $(this).addClass('smcw-active');
            var active_tab_key = $('.smcw-tab-tigger.smcw-active').data('menu');
            $('.smcw-settings-wrap').removeClass('smcw-active-container');
            $('.smcw-settings-wrap[data-menu-ref="' + active_tab_key + '"]').addClass('smcw-active-container');
        });
        $('body').on('click', '.smcw-enable-loader', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
                $('.smcw-loader-wrapper').removeClass('smcw-none-view').addClass('smcw-block-view');
            } else
            {
                $(this).val('0');
                $('.smcw-loader-wrapper').removeClass('smcw-block-view').addClass('smcw-none-view');
            }
        });
        $('body').on('click', '.smcw-enable-checkout-button', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
                $('.smcw-checkout-wrap').removeClass('smcw-none-view').addClass('smcw-block-view');
            } else
            {
                $(this).val('0');
                $('.smcw-checkout-wrap').removeClass('smcw-block-view').addClass('smcw-none-view');
            }
        });
        $('body').on('click', '.smcw-enable-shopping-button', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
                $('.smcw-shopping-wrap').removeClass('smcw-none-view').addClass('smcw-block-view');
            } else
            {
                $(this).val('0');
                $('.smcw-shopping-wrap').removeClass('smcw-block-view').addClass('smcw-none-view');
            }
        });
        $('body').on('click', '.smcw-enable-quantity', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-remove-product', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-enable-floating', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-enable-floating-price', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-price-tag', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-total-price', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-sub-total-price', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-shipping-price', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-tax-price', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-enable-suggest-product', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
                $('.smcw-suggested-product-details-wrap').removeClass('smcw-none-view').addClass('smcw-block-view');
            } else
            {
                $(this).val('0');
                $('.smcw-suggested-product-details-wrap').removeClass('smcw-block-view').addClass('smcw-none-view');
            }
        });
        $('body').on('click', '.smcw-enable-mobile', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-enable-auto-open', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-empty-cart', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-product-count', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-enable-product-variation', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        $('body').on('click', '.smcw-enable-popup-details', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
            } else
            {
                $(this).val('0');
            }
        });
        /*
         * shortcode generator
         */
        $('body').on('click', '.smcw-shortcode-button', function () {
            var enable_floating_button = ($("input[name='smcw_settings[smcw_enable_floating_cart]']").prop("checked")) ? 1 : 0;
            var floating_cart_position = $('.smcw-select-position-sc').val();
            var icon = $("input[name='smcw_settings[floating_font_icon]']:checked").val();
            var cart_effects = $("input[name='smcw_settings[floating_cart_effects]']:checked").val();
            var template = $('.smcw-sidebar-demo-template').val();
            if (cart_effects === 'loader_effects') {
                var auto_open_cart = $("input[name='smcw_settings[smcw_auto_open_cart]']").prop("checked") ? 1 : 0;
                var cart_loader = $("input[name='smcw_settings[smcw_cart_loader]']").prop("checked") ? 1 : 0;
                var loader = $("input[name='smcw_settings[smcw_loader_preview_type]']:checked").val();
                $("#smcw_generated_shortcode").html("[smcw_mini_cart" + " " + "enable_floating_button='" + enable_floating_button + "'" + " " + "floating_cart_position='" + floating_cart_position + "'" + " " +
                        "floating_cart_effects='" + cart_effects + "'" + " " + "auto_open_cart='" + auto_open_cart + "'" + " " + "cart_loader='" + cart_loader +
                        "'" + " " + "loader='" + loader + "'" + " " + "cart_icon='" + icon
                        + "'" + " " + "template='" + template + "']"
                        );
            } else {
                $("#smcw_generated_shortcode").html("[smcw_mini_cart" + " " + "enable_floating_button='" + enable_floating_button + "'" + " " + "floating_cart_position='" + floating_cart_position + "'" + " " +
                        "floating_cart_effects='" + cart_effects + "'" + " " + "cart_icon='" + icon
                        + "'" + " " + "template='" + template + "']"
                        );
            }

        });
        //radio button show and hide for cart effects
        $('body').on('click', '.smcw-cart-effects', function () {
            var value = $(this).val();
            if (value == 'loader_effects') {
                $('.smcw-loader-effects-wrapper').removeClass('smcw-none-view').addClass('smcw-block-view');
            } else {
                $('.smcw-loader-effects-wrapper').removeClass('smcw-block-view').addClass('smcw-none-view');
            }
        });
        $('body').on('click', '.smcw-show-cart-page', function () {
            var value = $(this).val();
            if (value === 'specific_page') {
                $('.smcw-page-wrapper').removeClass('smcw-none-view').addClass('smcw-block-view');
            } else {
                $('.smcw-page-wrapper').removeClass('smcw-block-view').addClass('smcw-none-view');
            }
        });
        $('body').on('click', '.smcw-show-product', function () {
            var value = $(this).val();
            if (value === 'specific_product') {
                $('.smcw-product-page-wrapper').removeClass('smcw-none-view').addClass('smcw-block-view');
            } else {
                $('.smcw-product-page-wrapper').removeClass('smcw-block-view').addClass('smcw-none-view');
            }
        });
        function smcw_build_pagination_html(current_page, total_page, post_id, next_arrow, prev_arrow) {
            var pagination_html = '';
            if (current_page > 1) {
                pagination_html += '<li class="smcw-previous-page-wrap"><a href="javascript:void(0);" class="smcw-previous-page" data-total-page="' + total_page + '" data-post-id="' + post_id + '"  data-prev-arrow="' + prev_arrow + '" data-next-arrow="' + next_arrow + '">' + prev_arrow + '</a></li>';
            }
            var upper_limit = current_page + 2;
            var lower_limit = current_page - 2;
            if (upper_limit > total_page) {
                upper_limit = total_page;
            }

            if (lower_limit < 1) {
                lower_limit = 1;
            }
            if (upper_limit - lower_limit < 5 && upper_limit - 4 >= 1) {
                lower_limit = upper_limit - 4;
            }
            if (upper_limit < 5 && total_page >= 5) {
                upper_limit = 5;
            }

            for (var page_count = lower_limit; page_count <= upper_limit; page_count++) {
                var page_class = (current_page === page_count) ? 'smcw-current-page smcw-page-link' : 'smcw-page-link';
                pagination_html += '<li><a href="javascript:void(0);" data-total-page="' + total_page + '" data-page-number="' + page_count + '" class="' + page_class + '"  data-post-id="' + post_id + '" data-prev-arrow="' + prev_arrow + '" data-next-arrow="' + next_arrow + '">' + page_count + '</a></li>';
            }
            if (current_page < total_page) {
                pagination_html += '<li class="smcw-next-page-wrap"><a href="javascript:void(0);" data-total-page="' + total_page + '" class="smcw-next-page" data-post-id="' + post_id + '" data-prev-arrow="' + prev_arrow + '" data-next-arrow="' + next_arrow + '">' + next_arrow + '</a></li>';
            }
            return pagination_html;
        }

        $('body').on('click', '.smcw-page-link', function () {
            var selector = $(this);
            selector.closest('.smcw-pagination-block').find('.smcw-page-link').removeClass('smcw-current-page');
            $(this).addClass('smcw-current-page');
            var page_num = $(this).data('page-number');
            var post_id = $(this).data('post-id');
            var post_name = $(this).closest('.smcw-field-wrap').find('#smcw_page_content').data('smcw-post');
            var total_page = $(this).data('total-page');
            var next_arrow = $(this).data('next-arrow');
            var prev_arrow = $(this).data('prev-arrow');
            var item_type = $(this).data('type');
            if (item_type === 'page') {
                var selected_pages = $('#smcw-selected-pages').val();
            } else {
                var selected_pages = $('#smcw-selected-product-pages').val();
            }

            $.ajax({
                type: 'post',
                url: smcw_backend_js_params.ajax_url,
                data: {
                    action: 'smcw_pagination_action',
                    _wpnonce: smcw_backend_js_params.ajax_nonce,
                    page_num: page_num,
                    total_page: total_page,
                    post_id: post_id,
                    next_arrow: next_arrow,
                    prev_arrow: prev_arrow,
                    post_name: post_name,
                    selected_pages: selected_pages

                },
                beforeSend: function (xhr) {
                    selector.closest('.smcw-pagination-block').find('.smcw-ajax-loader').show();
                },
                success: function (response) {
                    selector.closest('.smcw-pagination-block').find('.smcw-ajax-loader').hide();
                    selector.closest('.smcw-field-wrap').find('#smcw_page_content').html(response);
                }
            });
        });
        /**
         * Next Page Pagination
         *
         * @since 1.0.0
         */
        $('body').on('click', '.smcw-next-page,.smcw-previous-page', function () {
            var selector = $(this);
            var post_id = $(this).data('post-id');
            var post_name = $(this).closest('.smcw-field-wrap').find('#smcw_page_content').data('smcw-post');
            var total_page = $(this).data('total-page');
            var current_page = $(this).closest('.smcw-pagination-block').find('.smcw-current-page').data('page-number');
            var next_page = parseInt(current_page) + 1;
            var previous_page = parseInt(current_page) - 1;
            var next_arrow = $(this).data('next-arrow');
            var prev_arrow = $(this).data('prev-arrow');
            if (selector.hasClass('smcw-previous-page')) {
                current_page = previous_page;
            } else {
                current_page = next_page;
            }
            $.ajax({
                type: 'post',
                url: smcw_backend_js_params.ajax_url,
                data: {
                    action: 'smcw_pagination_action',
                    _wpnonce: smcw_backend_js_params.ajax_nonce,
                    page_num: current_page,
                    post_id: post_id,
                    post_name: post_name
                },
                beforeSend: function (xhr) {
                    selector.closest('.smcw-pagination-block').find('.smcw-ajax-loader').show();
                },
                success: function (response) {
                    selector.closest('.smcw-pagination-block').find('.smcw-ajax-loader').hide();
                    selector.closest('.smcw-field-wrap').find('#smcw_page_content').html(response);
                }
            });
        });
        $('body').on('click', '.smcw-add-page-check', function () {
            var page_id = $(this).val();
            var selected_pages = $('#smcw-selected-pages').val();
            if (selected_pages === '') {
                selected_pages_array = [];
            } else {
                var selected_pages_array = selected_pages.split(',');
            }
            if ($(this).is(':checked')) {
                if ($.inArray(page_id, selected_pages_array) == -1) {
                    selected_pages_array.push(page_id);
                }
            } else {
                if ($.inArray(page_id, selected_pages_array) != -1) {
                    var index = $.inArray(page_id, selected_pages_array);
                    selected_pages_array.splice(index, 1);
                }
            }
            if (selected_pages_array.length > 0) {
                $('#smcw-selected-pages').val(selected_pages_array.join());
            }
        });
        $('body').on('click', '.smcw-add-product-page-check', function () {
            var page_id = $(this).val();
            var selected_pages = $('#smcw-selected-product-pages').val();
            if (selected_pages === '') {
                selected_pages_array = [];
            } else {
                var selected_pages_array = selected_pages.split(',');
            }
            if ($(this).is(':checked')) {
                if ($.inArray(page_id, selected_pages_array) == -1) {
                    selected_pages_array.push(page_id);
                }
            } else {
                if ($.inArray(page_id, selected_pages_array) != -1) {
                    var index = $.inArray(page_id, selected_pages_array);
                    selected_pages_array.splice(index, 1);
                }
            }
            if (selected_pages_array.length > 0) {
                $('#smcw-selected-product-pages').val(selected_pages_array.join());
            }
        });
        $('body').on('change', '.smcw-floating-template', function () {
            var template_value = $(this).val();
            var array_break = template_value.split('-');
            var current_id = array_break[1];
            $('.smcw-floating-common').hide();
            $('#smcw-floating-demo-' + current_id).show();
        });
        if ($(".smcw-floating-template option:selected").length > 0) {
            var grid_view = $(".smcw-floating-template option:selected").val();
            var array_break = grid_view.split('-');
            var current_id1 = array_break[1];
            $('.smcw-floating-common').hide();
            $('#smcw-floating-demo-' + current_id1).show();
        }
        $('body').on('change', '.smcw-sidebar-demo-template', function () {
            var template_value = $(this).val();
            var array_break = template_value.split('-');
            var current_id = array_break[1];
            $('.smcw-sidebar-common').hide();
            $('#smcw-sidebar-demo-' + current_id).show();
        });
        $('.smcw-bg-color').wpColorPicker();
        $('.smcw-cart-color').wpColorPicker();
        $('.smcw-count-color').wpColorPicker();
        $('.smcw-border-color').wpColorPicker();
          $('body').on('click', '.smcw-enable-custom', function () {
            if ($(this).is(':checked'))
            {
                $(this).val('1');
                 $('.smcw-enable-color-wrapper').removeClass('smcw-hide-block').addClass('smcw-show-block');
            } else
            {
                $(this).val('0');
                 $('.smcw-enable-color-wrapper').removeClass('smcw-show-block').addClass('smcw-hide-block');
            }
        });
    });
}(jQuery));
