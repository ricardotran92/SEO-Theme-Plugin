<?php

defined('ABSPATH') or die('No script kiddies please!!');
/*
  Plugin Name: Sticky Mini Cart For WooCommerce
  Plugin URI: https://demo.codeflist.com/wordpress-plugins/sticky-mini-cart/
  Description: A plugin to show the cart in the sticky sidebar to list the add to cart product
  Version: 	1.1.1
  Author:     CodeFlist
  Author URI:  codeflist.com
  License: 	GPL2
  Domain Path: /languages
  Text Domain: sticky-mini-cart-woocommerce
 * 
 */
if (!class_exists('SMCW_Mini_Cart')) {

    class SMCW_Mini_Cart {

        /**
         * Plugin Main initialization
         */
        function __construct() {
            $this->smcw_constants();
            $this->smcw_includes();
            add_action('init', array($this, 'smcw_plugin_text_domain')); //loads text domain for translation ready
        }

        /**
         * Necessary Constants Define
         *
         */
        function smcw_constants() {

            global $wpdb;
            defined('SMCW_VERSION') or define('SMCW_VERSION', '1.1.1');
            defined('SMCW_PATH') or define('SMCW_PATH', plugin_dir_path(__FILE__));
            defined('SMCW_TD') or define('SMCW_TD', 'sticky-mini-cart-woocommerce'); //plugin's text domain
            defined('SMCW_URL') or define('SMCW_URL', plugin_dir_url(__FILE__));
            defined('SMCW_IMG_DIR') or define('SMCW_IMG_DIR', plugin_dir_url(__FILE__) . 'images/');
            defined('SMCW_CSS_DIR') or define('SMCW_CSS_DIR', plugin_dir_url(__FILE__) . 'css/');
            defined('SMCW_JS_DIR') or define('SMCW_JS_DIR', plugin_dir_url(__FILE__) . 'js/');
        }

        /**
         * Includes all the necessary files
         *
         * @since 1.0.0
         */
        function smcw_includes() {

            include(SMCW_PATH . 'inc/classes/smcw-library.php');
            include(SMCW_PATH . 'inc/classes/smcw-enqueue.php');
            include(SMCW_PATH . 'inc/classes/smcw-admin.php');
            include(SMCW_PATH . 'inc/classes/smcw-shortcode.php');
            include(SMCW_PATH . 'inc/classes/smcw-hooks.php');
        }

        //load the text domain for language translation
        function smcw_plugin_text_domain() {
            load_plugin_textdomain('sticky-mini-cart-woocommerce', false, basename(dirname(__FILE__)) . '/languages/');
        }

    }

    $GLOBALS['SMCW_Mini_Cart'] = new SMCW_Mini_Cart();
}


