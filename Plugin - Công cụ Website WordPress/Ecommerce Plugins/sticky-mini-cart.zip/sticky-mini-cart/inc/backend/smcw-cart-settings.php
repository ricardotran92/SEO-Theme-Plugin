<?php
defined('ABSPATH') or die("No script kiddies please!");
$smcw_settings = get_option('smcw_settings');
?>  
<div class='smcw-save-message-warp'>
    <?php if (isset($_GET['message']) && $_GET['message'] == '1') { ?>
        <div class="notice notice-success is-dismissible">
            <p><strong><?php esc_html_e('Settings saved successfully.', SMCW_TD); ?></strong></p>
            <button type="button" class="notice-dismiss">
                <span class="screen-reader-text"><?php esc_html_e('Dismiss this notice.', SMCW_TD); ?></span>
            </button>
        </div>
    <?php } ?>
</div>
<div class="smcw-header-wrapper">
    <div class="smcw-header-title">
        <?php esc_html_e('Sticky Mini Cart For WooCommerce', SMCW_TD); ?>
    </div>
    <div class="smcw-version-wrap">
        <?php
        esc_html_e('Version ', SMCW_TD);
        echo SMCW_VERSION;
        ?>
    </div>
</div>
<form method="post" id="smcw-save-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"  >
    <input type="hidden" name="action" value="smcw_settings_save"/>
    <div class = "smcw-backend-outer-wrap">
        <div class="smcw-top-setting-wrapper">
            <ul class="smcw-top-tab">
                <li data-menu="top-cart-settings" class="smcw-top-tab-tigger smcw-top-active">
                    <span class="eleganticons icon_pencil-edit"></span>
                    <?php esc_html_e('Sticky Cart Settings', SMCW_TD) ?>
                </li>
                <li data-menu="top-layout-settings" class="smcw-top-tab-tigger">
                    <span class="eleganticons icon_image"></span>
                    <?php esc_html_e('Layout Settings', SMCW_TD) ?>
                </li>
                <li data-menu="top-product-settings" class="smcw-top-tab-tigger">
                    <span class="eleganticons icon_bag_alt"></span>
                    <?php esc_html_e('Product Settings', SMCW_TD) ?>
                </li>
                <li data-menu="top-general-settings" class="smcw-top-tab-tigger">
                    <span class="eleganticons icon_cog"></span>
                    <?php esc_html_e('General Settings', SMCW_TD) ?>
                </li>
                <li data-menu="top-custom-settings" class="smcw-top-tab-tigger">
                    <span class="eleganticons icon_cog"></span>
                    <?php esc_html_e('Custom Color Settings', SMCW_TD) ?>
                </li>
                <li data-menu="shortcode-generator" class="smcw-top-tab-tigger">
                    <span class="eleganticons icon_tool"></span>
                    <?php esc_html_e('Shortcode Generator', SMCW_TD) ?>
                </li>
            </ul>
        </div>
        <div class ="smcw-top-settings-wrap smcw-top-active-container" data-menu-ref="top-cart-settings">
            <?php include(SMCW_PATH . 'inc/backend/settings/main/smcw-floating-cart.php'); ?>
        </div>
        <div class ="smcw-top-settings-wrap" data-menu-ref="top-layout-settings">
            <?php include(SMCW_PATH . 'inc/backend/settings/floating/smcw-layout.php'); ?>
        </div>
        <div class ="smcw-top-settings-wrap" data-menu-ref="top-product-settings">
            <?php include(SMCW_PATH . 'inc/backend/settings/main/smcw-product.php'); ?>
        </div>
        <div class ="smcw-top-settings-wrap" data-menu-ref="top-general-settings">
            <?php include(SMCW_PATH . 'inc/backend/settings/main/smcw-general.php'); ?>
        </div>
        <div class ="smcw-top-settings-wrap" data-menu-ref="top-custom-settings">
            <?php include(SMCW_PATH . 'inc/backend/settings/main/smcw-custom.php'); ?>
        </div>
        <div class ="smcw-top-settings-wrap" data-menu-ref="shortcode-generator">
            <?php include(SMCW_PATH . 'inc/backend/settings/main/smcw-generator.php'); ?>
        </div>
    </div>
</form>