<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-save-buton">
    <?php wp_nonce_field('smcw_form_nonce', 'smcw_form_nonce_field'); ?>
    <a class="button button-primary button-large" href="javascript:;" onclick="document.getElementById('smcw-save-form').submit();"><span><?php esc_html_e('Save', SMCW_TD); ?></span></a>
</div>