<?php
defined( 'ABSPATH' ) or die( "No script kiddies please!" );
?>
<div class="smcw-layout-container">
    <div class="smcw-label-wrap">
        <label for="smcw-template" class="smcw-label">
            <?php esc_html_e( 'Template', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <select name="smcw_settings[template]" class="smcw-floating-template">
                <?php
                $smcw_template_names = array('Classic Template','Light Template','Cantaloupe Template','Blonde Template','Blush Template','Intense Template','Popup Template','Mordern Template','Dark Template','Table Template');
                $k = 1;
                foreach ( $smcw_template_names as $smcw_template_name ) { ?>
                <option value="template-<?php echo esc_attr($k); ?>" <?php if ( ! empty( $smcw_settings[ 'template' ] ) ) selected( $smcw_settings[ 'template' ], 'template-' . $k ); ?>><?php echo esc_attr($smcw_template_name); ?></option>
                <?php 
                 $k ++;
                } ?>    </select>
            <div class="smcw-floating-demo smcw-preview-image">
                <?php
                for ( $cnt = 1; $cnt <= 10; $cnt ++ ) {
                    if ( isset( $smcw_settings[ 'template' ] ) ) {
                        $option_value = $smcw_settings[ 'template' ];
                        $exploed_array = explode( '-', $option_value );
                        $cnt_num = $exploed_array[ 1 ];
                        if ( $cnt != $cnt_num ) {
                            $style = "style='display:none;'";
                        } else {
                            $style = '';
                        }
                    }
                    ?>
                <div class="smcw-floating-common" id="smcw-floating-demo-<?php echo esc_attr($cnt); ?>" <?php if ( isset( $style ) ) echo esc_attr ($style); ?>>
                    <h4><?php esc_html_e( 'Template', SMCW_TD ); ?> <?php echo esc_attr($cnt); ?> <?php esc_html_e( 'Preview', SMCW_TD ); ?></h4>
                        <img src="<?php echo SMCW_IMG_DIR . 'demo/sidebar/template-' . $cnt . '.png' ?>"/>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php
include(SMCW_PATH . 'inc/backend/settings/save-form.php');