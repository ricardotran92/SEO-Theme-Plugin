<?php
defined( 'ABSPATH' ) or die( "No script kiddies please!" );
?>
<div class="smcw-page-container">
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Page', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label><input type="radio" value="all_page" name="smcw_settings[show_cart_page]" <?php
                if ( isset( $smcw_settings[ 'show_cart_page' ] ) ) {
                    checked( $smcw_settings[ 'show_cart_page' ], 'all_page' );
                }
                ?> class="smcw-show-cart-page" ><?php esc_html_e( "All page", SMCW_TD ); ?></label>
            <label><input type="radio" value="specific_page" name="smcw_settings[show_cart_page]" <?php
                if ( isset( $smcw_settings[ 'show_cart_page' ] ) ) {
                    checked( $smcw_settings[ 'show_cart_page' ], 'specific_page' );
                }
                ?>  class="smcw-show-cart-page"><?php esc_html_e( 'Specific page', SMCW_TD ); ?></label>
        </div>
        <div class="smcw-page-wrapper  <?php
        if ( isset( $smcw_settings[ 'show_cart_page' ] ) && $smcw_settings[ 'show_cart_page' ] == 'specific_page' ) {
            echo esc_attr('smcw-show-block');
        } else {
            echo esc_attr('smcw-hide-block');
        }
        ?>">
                 <?php
                 $smcw_post_type = 'page';
                 $selected_pages = ( ! empty( $smcw_settings[ 'specific_pages_list' ] )) ? explode( ',', $smcw_settings[ 'specific_pages_list' ] ) : array();
                 include(SMCW_PATH . 'inc/backend/page-action.php');
                 ?>
        </div>
    </div>
    <div id="smcw-display-selection" >
        <div class="smcw-tab-contents" >
            <?php
            $selected_pages = ( isset( $smcw_settings[ 'specific_pages_list' ] )) ? $smcw_settings[ 'specific_pages_list' ] : '';
            ?>
            <input type="hidden" id="smcw-selected-pages" name="smcw_settings[specific_pages_list]" value="<?php echo esc_attr($selected_pages); ?>"/>
        </div>
    </div>

    <div class ="smcw-label-wrap">
        <label  class="smcw-label">
            <?php esc_html_e( 'Woocommerce product page', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label><input type="radio" value="all_product" name="smcw_settings[show_cart_product]" <?php
                if ( isset( $smcw_settings[ 'show_cart_product' ] ) ) {
                    checked( $smcw_settings[ 'show_cart_product' ], 'all_product' );
                }
                ?> class="smcw-show-product"/><?php esc_html_e( "All product", SMCW_TD ); ?></label>
            <label><input type="radio" value="specific_product" name="smcw_settings[show_cart_product]" <?php
                if ( isset( $smcw_settings[ 'show_cart_product' ] ) ) {
                    checked( $smcw_settings[ 'show_cart_product' ], 'specific_product' );
                }
                ?>  class="smcw-show-product"/><?php esc_html_e( 'Specific product', SMCW_TD ); ?></label>
        </div>
        <div class="smcw-product-page-wrapper <?php
        if ( isset( $smcw_settings[ 'show_cart_product' ] ) && $smcw_settings[ 'show_cart_product' ] == 'specific_product' ) {
            echo esc_attr('smcw-show-block');
        } else {
            echo esc_attr('smcw-hide-block');
        }
        ?>">
                 <?php
                 $smcw_post_type = 'product';
                 $selected_pages = ( ! empty( $smcw_settings[ 'specific_product_pages_list' ] )) ? explode( ',', $smcw_settings[ 'specific_product_pages_list' ] ) : array();
                 include(SMCW_PATH . 'inc/backend/page-action.php');
                 ?>
        </div>
    </div>
    <div id="smcw-display-selection" >
        <div class="smcw-tab-contents" >
            <?php
            $selected_pages = ( isset( $smcw_settings[ 'specific_product_pages_list' ] )) ? $smcw_settings[ 'specific_product_pages_list' ] : '';
            ?>
            <input type="hidden" id="smcw-selected-product-pages" name="smcw_settings[specific_product_pages_list]" value="<?php echo esc_attr($selected_pages); ?>"/>
        </div>
    </div>
</div>