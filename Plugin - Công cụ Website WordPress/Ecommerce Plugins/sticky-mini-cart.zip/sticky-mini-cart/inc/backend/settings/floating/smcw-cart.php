<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-outer-container">
    <div class="smcw-label-wrap">
        <label for="smcw-floating-cart-check" class="smcw-label">
            <?php esc_html_e('Enable sticky cart', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-floating smcw-checkbox" value="<?php
                if (isset($smcw_settings['enable_floating_button'])) {
                    echo esc_attr($smcw_settings['enable_floating_button']);
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[enable_floating_button]" <?php if (isset($smcw_settings['enable_floating_button']) && $smcw_settings['enable_floating_button'] == '1') { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e('Enable to show sticky cart', SMCW_TD) ?></p>
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e('Sticky cart position', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <select name="smcw_settings[floating_cart_position]" class="smcw-select-position">
                <option value="left_top" <?php if (isset($smcw_settings['floating_cart_position']) && $smcw_settings['floating_cart_position'] == 'left_top') echo 'selected == "selected"'; ?>><?php esc_html_e('Left top', SMCW_TD) ?></option>
                <option value="left_bottom" <?php if (isset($smcw_settings['floating_cart_position']) && $smcw_settings['floating_cart_position'] == 'left_bottom') echo 'selected == "selected"'; ?>><?php esc_html_e('Left bottom', SMCW_TD) ?></option>
                <option value="left_center" <?php if (isset($smcw_settings['floating_cart_position']) && $smcw_settings['floating_cart_position'] == 'left_center') echo 'selected == "selected"'; ?>><?php esc_html_e('Left center', SMCW_TD) ?></option>
                <option value="right_top" <?php if (isset($smcw_settings['floating_cart_position']) && $smcw_settings['floating_cart_position'] == 'right_top') echo 'selected == "selected"'; ?>><?php esc_html_e('Right top', SMCW_TD) ?></option>
                <option value="right_bottom" <?php if (isset($smcw_settings['floating_cart_position']) && $smcw_settings['floating_cart_position'] == 'right_bottom') echo 'selected == "selected"'; ?>><?php esc_html_e('Right bottom', SMCW_TD) ?></option>
                <option value="right_center" <?php if (isset($smcw_settings['floating_cart_position']) && $smcw_settings['floating_cart_position'] == 'right_center') echo 'selected == "selected"'; ?>><?php esc_html_e('Right center', SMCW_TD) ?></option>
            </select>
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-floating-price-check" class="smcw-label">
            <?php esc_html_e('Enable cart price', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-floating-price smcw-checkbox" value="<?php
                if (isset($smcw_settings['enable_floating_price'])) {
                    echo esc_attr($smcw_settings['enable_floating_price']);
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[enable_floating_price]" <?php if (isset($smcw_settings['enable_floating_price']) && $smcw_settings['enable_floating_price'] == '1') { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e('Enable to show price with sticky cart', SMCW_TD) ?></p>
        </div>
    </div>
    <div class="smcw-cart-icon-wrapper">
        <div class="smcw-label-wrap">
            <label><?php esc_html_e('Choose cart icons', SMCW_TD); ?></label>
            <div class="smcw-field-wrap">
                <?php
                $smcw_font_icons = array('dashicons|dashicons-cart','dashicons|dashicons-portfolio', 'dashicons|dashicons-post-trash', 'dashicons|dashicons-products', 'eleganticons|icon_cart_alt', 'eleganticons|icon_cart', 'eleganticons|icon_bag_alt', 'eleganticons|icon_bag', 'eleganticons|icon_briefcase_alt','eleganticons|icon_briefcase', 'eleganticons|icon_toolbox_alt', 'eleganticons|icon_toolbox', 'eleganticons|icon_trash_alt', 'eleganticons|icon_trash', 'eleganticons|icon_lock_alt', 'eleganticons|icon_lock', 'fab|fa-opencart', 'far|fa-trash-alt',
                    'fas|fa-cart-arrow-down', 'fas|fa-cart-plus', 'fas|fa-shopping-cart', 'fas|fa-shopping-bag', 'fas|fa-briefcase', 'fas|fa-lock', 'fas|fa-shopping-basket', 'lnr|lnr-trash', 'lnr|lnr-cart', 'lnr|lnr-lock', 'lnr|lnr-briefcase'
                );
                foreach ($smcw_font_icons as $smcw_font_icon) :
                    ?>
                    <div class="smcw-hide-radio">
                        <input type="radio" id="<?php echo esc_attr($smcw_font_icon); ?>" name="smcw_settings[cart_icon]" class="smcw-font-icon" value="<?php echo esc_attr($smcw_font_icon); ?>" <?php if (isset($smcw_settings['cart_icon']) && $smcw_settings['cart_icon'] == $smcw_font_icon) { ?>checked="checked"<?php } ?> <?php if (!isset($smcw_settings['cart_icon'])) { ?>checked="checked"<?php } ?> />
                        <label class="smcw-font-icon-demo">
                            <?php
                            $v = explode('|', $smcw_font_icon);
                            if (isset($v[1])) {
                                ?>
                            <span class="<?php echo esc_attr($v[0] . ' ' . $v[1]); ?>"></span>
                                <?php
                            }
                            ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-cart-icon-check" class="smcw-label">
            <?php esc_html_e('Cart effects', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label><input type="radio" value="loader_effects" name="smcw_settings[floating_cart_effects]" <?php
                if (isset($smcw_settings['floating_cart_effects'])) {
                    checked($smcw_settings['floating_cart_effects'], 'loader_effects');
                }
                ?> class="smcw-cart-effects"/><?php esc_html_e("Loader effect", SMCW_TD); ?></label>
            <label><input type="radio" value="fly_image_effects" name="smcw_settings[floating_cart_effects]" <?php
                if (isset($smcw_settings['floating_cart_effects'])) {
                    checked($smcw_settings['floating_cart_effects'], 'fly_image_effects');
                }
                ?>  class="smcw-cart-effects"/><?php esc_html_e('Fly image effect', SMCW_TD); ?></label>
        </div>
    </div>
    <div class="smcw-loader-effects-wrapper <?php if (isset($smcw_settings['floating_cart_effects']) && $smcw_settings['floating_cart_effects'] == 'loader_effects') { echo esc_attr('smcw-block-view'); } else { echo esc_attr('smcw-none-view'); } ?>">
        <div class="smcw-label-wrap">
            <label for="smcw-open-cart-check" class="smcw-label">
                <?php esc_html_e('Auto open cart', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <label class="smcw-switch">
                    <input type="checkbox" class="smcw-enable-auto-open smcw-checkbox" value="<?php
                    if (isset($smcw_settings['auto_open_cart'])) {
                        echo esc_attr($smcw_settings['auto_open_cart']);
                    } else {
                        echo '0';
                    }
                    ?>" name="smcw_settings[auto_open_cart]" <?php if (isset($smcw_settings['auto_open_cart']) && $smcw_settings['auto_open_cart'] == '1') { ?>checked="checked"<?php } ?> />
                    <div class="smcw-slider round"></div>
                </label>
                <p class="description"><?php esc_html_e('Enable to open the cart when item is added to the cart', SMCW_TD) ?></p>
            </div>
        </div>
        <div class="smcw-label-wrap">
            <label for="smcw-open-cart-check" class="smcw-label">
                <?php esc_html_e('Cart loader', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <label class="smcw-switch">
                    <input type="checkbox" class="smcw-enable-loader smcw-checkbox" value="<?php
                    if (isset($smcw_settings['cart_loader'])) {
                        echo esc_attr($smcw_settings['cart_loader']);
                    } else {
                        echo '0';
                    }
                    ?>" name="smcw_settings[cart_loader]" <?php if (isset($smcw_settings['cart_loader']) && $smcw_settings['cart_loader'] == '1') { ?>checked="checked"<?php } ?> />
                    <div class="smcw-slider round"></div>
                </label>
                <p class="description"><?php esc_html_e('Enable to show loader while adding item to the cart', SMCW_TD) ?></p>
            </div>
        </div>
        <div class="smcw-loader-wrapper <?php if (isset($smcw_settings['cart_loader']) && $smcw_settings['cart_loader'] == '1') { echo esc_attr('smcw-block-view'); } else { echo esc_attr('smcw-none-view');  } ?>">
            <div class="smcw-label-wrap">
                <label for="smcw-open-cart-check" class="smcw-label">
                    <?php esc_html_e('Choose loader', SMCW_TD); ?>
                </label>
                <div class="smcw-field-wrap">
                    <?php
                    $smcw_loader_previews = array('loader-1', 'loader-2', 'loader-3', 'loader-4', 'loader-5', 'loader-6', 'loader-7', 'loader-8', 'loader-9', 'loader-10', 'loader-11', 'loader-12', 'loader-13', 'loader-14', 'loader-15', 'loader-16', 'loader-17', 'loader-18', 'loader-19', 'loader-20', 'loader-21', 'loader-22', 'loader-23', 'loader-24', 'loader-25');
                    foreach ($smcw_loader_previews as $smcw_loader_preview) :
                        ?>
                        <div class="smcw-hide-radio">
                            <input type="radio" id="<?php echo esc_attr($smcw_loader_preview); ?>" name="smcw_settings[loader]" class="smcw-loader-type" value="<?php echo esc_attr($smcw_loader_preview); ?>" <?php if (isset($smcw_settings['loader']) && $smcw_settings['loader'] == $smcw_loader_preview) { ?>checked="checked"<?php } ?> <?php if (!isset($smcw_settings['loader'])) { ?>checked="checked"<?php } ?> />
                            <label class="smcw-loader-demo" for="<?php echo esc_attr($smcw_loader_preview); ?>">
                                <img src="<?php echo SMCW_IMG_DIR . 'loader/' . $smcw_loader_preview . '.gif' ?>">
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>