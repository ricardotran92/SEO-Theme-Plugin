<?php
defined( 'ABSPATH' ) or die( "No script kiddies please!" );
?>
<div class="smcw-menu-wrapper">
    <ul class="smcw-menu-tab">
        <li data-menu="cart-settings" class="smcw-tab-tigger smcw-active">
            <span class="eleganticons icon_cart_alt"></span>
            <?php esc_html_e( 'Cart Settings', SMCW_TD ) ?>
        </li>
        <li data-menu="layout-settings" class="smcw-tab-tigger">
            <span class="eleganticons icon_image"></span>
            <?php esc_html_e( 'Layout Settings', SMCW_TD ) ?>
        </li>
    </ul>
</div>
<div class="smcw-generated-shortcode-wapper">
    <textarea class="smcw_short_display" name="smcw_settings[generate_shortcode]" id="smcw_generated_shortcode" readonly="readonly"></textarea>
</div>
<div class="smcw-generate-shortcode-button">
    <input type="button" class="smcw-shortcode-button" value="<?php esc_html_e( 'Click Me To Generate Shortcode', SMCW_TD ); ?>">
</div>
<div class ="smcw-settings-wrap smcw-active-container" data-menu-ref="cart-settings">
    <?php include(SMCW_PATH . 'inc/backend/settings/shortcode-generator/smcw-cart.php'); ?>
</div>
<div class ="smcw-settings-wrap" data-menu-ref="layout-settings">
    <?php include(SMCW_PATH . 'inc/backend/settings/shortcode-generator/smcw-layout.php'); ?>
</div>


