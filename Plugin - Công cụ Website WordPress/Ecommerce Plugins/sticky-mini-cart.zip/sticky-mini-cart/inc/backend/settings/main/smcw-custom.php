<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-custom-container">
      <div class="smcw-label-wrap">
        <label for="smcw-floating-cart-check" class="smcw-label">
            <?php esc_html_e('Enable custom color', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-custom smcw-checkbox" value="<?php
                if (isset($smcw_settings['enable_custom_color'])) {
                    echo esc_attr($smcw_settings['enable_custom_color']);
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[enable_custom_color]" <?php if (isset($smcw_settings['enable_custom_color']) && $smcw_settings['enable_custom_color'] == '1') { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e('Enable to update custom color on cart', SMCW_TD) ?></p>
        </div>
    </div>
    <div class="smcw-enable-color-wrapper <?php if (isset($smcw_settings['enable_custom_color']) && $smcw_settings['enable_custom_color'] == '1') { echo 'smcw-show-block'; } else { echo 'smcw-hide-block'; }?>">
    <div class="smcw-label-wrap">
        <label for="smcw-layout" class="smcw-label">
            <?php esc_html_e('Cart background color', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            
            <input type="text" value="<?php
            if (isset($smcw_settings['smcw_bg_color'])) {
                echo esc_attr($smcw_settings['smcw_bg_color']);
            }
            ?>" name="smcw_settings[smcw_bg_color]" class="smcw-bg-color" data-default-color="#000">
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-layout" class="smcw-label">
            <?php esc_html_e('Cart Color', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            
            <input type="text" value="<?php
            if (isset($smcw_settings['smcw_cart_color'])) {
                echo esc_attr($smcw_settings['smcw_cart_color']);
            }
            ?>" name="smcw_settings[smcw_cart_color]" class="smcw-cart-color" data-default-color="#000">
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-layout" class="smcw-label">
            <?php esc_html_e('Count color', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            
            <input type="text" value="<?php
            if (isset($smcw_settings['smcw_count_color'])) {
                echo esc_attr($smcw_settings['smcw_count_color']);
            }
            ?>" name="smcw_settings[smcw_count_color]" class="smcw-count-color" data-default-color="#000">
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-layout" class="smcw-label">
            <?php esc_html_e('Background border color', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            
            <input type="text" value="<?php
            if (isset($smcw_settings['smcw_border_color'])) {
                echo esc_attr($smcw_settings['smcw_border_color']);
            }
            ?>" name="smcw_settings[smcw_border_color]" class="smcw-border-color" data-default-color="#000">
        </div>
    </div>
    </div>
</div>
<?php
include(SMCW_PATH . 'inc/backend/settings/save-form.php');
