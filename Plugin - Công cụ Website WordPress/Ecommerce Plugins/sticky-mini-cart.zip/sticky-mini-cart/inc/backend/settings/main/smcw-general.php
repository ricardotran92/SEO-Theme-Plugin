<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-general-container">
    <div class="smcw-label-wrap">
        <label for="smcw-layout" class="smcw-label">
            <?php esc_html_e('Title text in cart', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <input type="text" value="<?php
            if (isset($smcw_settings['smcw_title_text_cart'])) {
                echo esc_attr($smcw_settings['smcw_title_text_cart']);
            }
            ?>" name="smcw_settings[smcw_title_text_cart]">
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label for="smcw-checkout-button-check" class="smcw-label">
            <?php esc_html_e('Enable checkout button', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-checkout-button smcw-checkbox" value="<?php
                if (isset($smcw_settings['smcw_checkout_button'])) {
                    echo esc_attr($smcw_settings['smcw_checkout_button']);
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_checkout_button]" <?php if (isset($smcw_settings['smcw_checkout_button']) && $smcw_settings['smcw_checkout_button'] == '1') { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e('Enable to show checkout button on cart', SMCW_TD) ?></p>
        </div>
    </div>
    <div class="smcw-checkout-wrap <?php if ( isset( $smcw_settings[ 'smcw_checkout_button' ] ) && $smcw_settings[ 'smcw_checkout_button' ] == '1' ) { echo esc_attr('smcw-block-view'); } else { echo esc_attr('smcw-none-view'); } ?>">
        <div class ="smcw-label-wrap">
            <label for="smcw-layout" class="smcw-label">
                <?php esc_html_e('Checkout text', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <input type="text" value="<?php
                if (isset($smcw_settings['smcw_checkout_text'])) {
                    echo esc_attr($smcw_settings['smcw_checkout_text']);
                }
                ?>" name="smcw_settings[smcw_checkout_text]">
            </div>
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-shopping-button-check" class="smcw-label">
            <?php esc_html_e('Enable shopping button', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-shopping-button smcw-checkbox" value="<?php
                if (isset($smcw_settings['smcw_shopping_button'])) {
                    echo esc_attr($smcw_settings['smcw_shopping_button']);
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_shopping_button]" <?php if (isset($smcw_settings['smcw_shopping_button']) && $smcw_settings['smcw_shopping_button'] == '1') { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e('Enable to show continue shopping button if cart is empty', SMCW_TD) ?></p>
        </div>
    </div>
    <div class="smcw-shopping-wrap <?php if ( isset( $smcw_settings[ 'smcw_shopping_button' ] ) && $smcw_settings[ 'smcw_shopping_button' ] == '1' ) { echo esc_attr('smcw-block-view'); } else { echo esc_attr('smcw-none-view'); } ?>">
        <div class="smcw-label-wrap">
            <label for="smcw-layout" class="smcw-label">
                <?php esc_html_e('Continue button text', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <input type="text" value="<?php
                if (isset($smcw_settings['smcw_continue_button_text'])) {
                    echo esc_attr($smcw_settings['smcw_continue_button_text']);
                }
                ?>" name="smcw_settings[smcw_continue_button_text]">
            </div>
        </div>
        <div class="smcw-label-wrap">
            <label for="smcw-layout" class="smcw-label">
                <?php esc_html_e('Continue button URL', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <input type="text" value="<?php
                if (isset($smcw_settings['smcw_continue_button_url'])) {
                    echo esc_attr($smcw_settings['smcw_continue_button_url']);
                }
                ?>" name="smcw_settings[smcw_continue_button_url]">
            </div>
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-popup-details-check" class="smcw-label">
            <?php esc_html_e('Enable popup on cart', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-popup-details smcw-checkbox" value="<?php
                if (isset($smcw_settings['smcw_display_popup_details'])) {
                    echo esc_attr($smcw_settings['smcw_display_popup_details']);
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_display_popup_details]" <?php if (isset($smcw_settings['smcw_display_popup_details']) && $smcw_settings['smcw_display_popup_details'] == '1') { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e('Enable to show popup on product image to show product details', SMCW_TD) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label for="smcw-inner-cart-check" class="smcw-label">
            <?php esc_html_e('Choose loader', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <?php
            $smcw_inner_loaders = array('loader-1', 'loader-2', 'loader-3', 'loader-4', 'loader-5', 'loader-6', 'loader-7', 'loader-8', 'loader-9', 'loader-10', 'loader-11', 'loader-12', 'loader-13', 'loader-14', 'loader-15', 'loader-16', 'loader-17', 'loader-18', 'loader-19', 'loader-20', 'loader-21', 'loader-22', 'loader-23', 'loader-24', 'loader-25');
            foreach ($smcw_inner_loaders as $smcw_inner_loader) :
                ?>
                <div class="smcw-hide-radio">
                    <input type="radio" id="<?php echo esc_attr($smcw_inner_loader); ?>" name="smcw_settings[inner_loader]" class="smcw-loader-type" value="<?php echo esc_attr($smcw_inner_loader); ?>" <?php if (isset($smcw_settings['inner_loader']) && $smcw_settings['inner_loader'] == $smcw_inner_loader) { ?>checked="checked"<?php } ?> <?php if (!isset($smcw_settings['inner_loader'])) { ?>checked="checked"<?php } ?> />
                    <label class="smcw-loader-demo" for="<?php echo esc_attr($smcw_inner_loader); ?>">
                        <img src="<?php echo SMCW_IMG_DIR . 'loader/' . $smcw_inner_loader . '.gif' ?>">
                    </label>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php
include(SMCW_PATH . 'inc/backend/settings/save-form.php');
