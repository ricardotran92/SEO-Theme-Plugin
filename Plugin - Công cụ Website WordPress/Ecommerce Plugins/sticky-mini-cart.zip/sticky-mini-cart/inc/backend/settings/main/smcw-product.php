<?php
defined( 'ABSPATH' ) or die( "No script kiddies please!" );
?>
<div class="smcw-product-settings-wrap">
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Change product quantity', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-quantity smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_product_quantity' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_product_quantity' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_product_quantity]" <?php if ( isset( $smcw_settings[ 'smcw_product_quantity' ] ) && $smcw_settings[ 'smcw_product_quantity' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to change quantity of the product in cart', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Remove product', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-remove-product smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_remove_product' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_remove_product' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_remove_product]" <?php if ( isset( $smcw_settings[ 'smcw_remove_product' ] ) && $smcw_settings[ 'smcw_remove_product' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to remove product from the cart', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Enable price tag', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-price-tag smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_enable_price_tag' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_enable_price_tag' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_enable_price_tag]" <?php if ( isset( $smcw_settings[ 'smcw_enable_price_tag' ] ) && $smcw_settings[ 'smcw_enable_price_tag' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to remove product from the cart', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Enable total price', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-total-price smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_enable_total_price' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_enable_total_price' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_enable_total_price]" <?php if ( isset( $smcw_settings[ 'smcw_enable_total_price' ] ) && $smcw_settings[ 'smcw_enable_total_price' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to show total price in cart', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Enable subtotal price', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-sub-total-price smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_enable_subtotal_price' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_enable_subtotal_price' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_enable_subtotal_price]" <?php if ( isset( $smcw_settings[ 'smcw_enable_subtotal_price' ] ) && $smcw_settings[ 'smcw_enable_subtotal_price' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to show Subtotal price', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Enable shipping price', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-shipping-price smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_enable_shipping_price' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_enable_shipping_price' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_enable_shipping_price]" <?php if ( isset( $smcw_settings[ 'smcw_enable_shipping_price' ] ) && $smcw_settings[ 'smcw_enable_shipping_price' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to show shipping price', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Enable tax price', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-tax-price smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_enable_tax_price' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_enable_tax_price' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_enable_tax_price]" <?php if ( isset( $smcw_settings[ 'smcw_enable_tax_price' ] ) && $smcw_settings[ 'smcw_enable_tax_price' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to show tax price', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label class="smcw-label">
            <?php esc_html_e( 'Show suggest product', SMCW_TD ); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-suggest-product smcw-checkbox" value="<?php
                if ( isset( $smcw_settings[ 'smcw_suggest_product' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_suggest_product' ] );
                } else {
                    echo '0';
                }
                ?>" name="smcw_settings[smcw_suggest_product]" <?php if ( isset( $smcw_settings[ 'smcw_suggest_product' ] ) && $smcw_settings[ 'smcw_suggest_product' ] == '1' ) { ?>checked="checked"<?php } ?> />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e( 'Enable to show suggested product in cart', SMCW_TD ) ?></p>
        </div>
    </div>
    <div class="smcw-suggested-product-details-wrap <?php if ( isset( $smcw_settings[ 'smcw_suggest_product' ] ) && $smcw_settings[ 'smcw_suggest_product' ] == '1' ) { echo esc_attr('smcw-block-view'); } else { echo esc_attr('smcw-none-view'); } ?>">
        <div class ="smcw-label-wrap">
            <label for="smcw-layout" class="smcw-label">
                <?php esc_html_e( 'Suggested title', SMCW_TD ); ?>
            </label>
            <div class="smcw-field-wrap">
                <input type="text" value="<?php
                if ( isset( $smcw_settings[ 'smcw_suggested_title_cart' ] ) ) {
                    echo esc_attr( $smcw_settings[ 'smcw_suggested_title_cart' ] );
                }
                ?>" name="smcw_settings[smcw_suggested_title_cart]">
            </div>
        </div>
    </div>
</div>
<?php
include(SMCW_PATH . 'inc/backend/settings/save-form.php');
