<?php
defined( 'ABSPATH' ) or die( "No script kiddies please!" );
?>
<div class="smcw-menu-wrapper">
    <ul class="smcw-menu-tab">
        <li data-menu="cart-settings" class="smcw-tab-tigger smcw-active">
            <span class="eleganticons icon_cart_alt"></span>
            <?php esc_html_e( 'Cart Settings', SMCW_TD ) ?>
        </li>
        <li data-menu="page-settings" class="smcw-tab-tigger">
            <span class="eleganticons icon_box-checked"></span>
            <?php esc_html_e( 'Page Configure Settings', SMCW_TD ) ?>
        </li>
    </ul>
</div>
<div class="smcw-settings-wrap smcw-active-container" data-menu-ref="cart-settings">
    <?php include(SMCW_PATH . 'inc/backend/settings/floating/smcw-cart.php'); ?>
</div>
<div class="smcw-settings-wrap" data-menu-ref="page-settings">
    <?php include(SMCW_PATH . 'inc/backend/settings/floating/smcw-page.php'); ?>
</div>
<?php
include(SMCW_PATH . 'inc/backend/settings/save-form.php');
