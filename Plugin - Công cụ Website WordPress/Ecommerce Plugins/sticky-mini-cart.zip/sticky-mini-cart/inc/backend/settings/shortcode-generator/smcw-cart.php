<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-outer-container">
    <div class="smcw-label-wrap">
        <label for="smcw-floating-cart-check" class="smcw-label">
            <?php esc_html_e('Enable sticky cart', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label class="smcw-switch">
                <input type="checkbox" class="smcw-enable-floating smcw-checkbox" value="" name="smcw_settings[smcw_enable_floating_cart]" />
                <div class="smcw-slider round"></div>
            </label>
            <p class="description"><?php esc_html_e('Enable to show sticky cart', SMCW_TD) ?></p>
        </div>
    </div>
    <div class="smcw-cart-icon-wrapper">
        <div class ="smcw-label-wrap">
            <label><?php esc_html_e('Font icons', SMCW_TD); ?></label>
            <div class="smcw-field-wrap">
                <?php
                $smcw_font_icons = array('dashicons|dashicons-cart', 'dashicons|dashicons-post-trash', 'dashicons|dashicons-trash', 'dashicons|dashicons-products', 'eleganticons|icon_cart_alt', 'eleganticons|icon_cart', 'eleganticons|icon_bag_alt', 'eleganticons|icon_bag', 'eleganticons|icon_briefcase_alt', 'eleganticons|icon_toolbox_alt', 'eleganticons|icon_toolbox', 'eleganticons|icon_trash_alt', 'eleganticons|icon_trash', 'eleganticons|icon_lock_alt', 'eleganticons|icon_lock', 'fab|fa-opencart', 'far|fa-trash-alt',
                    'fas|fa-cart-arrow-down', 'fas|fa-cart-plus', 'fas|fa-shopping-cart', 'fas|fa-shopping-bag', 'fas|fa-briefcase', 'fas|fa-lock', 'fas|fa-shopping-basket', 'lnr|lnr-trash', 'lnr|lnr-cart', 'lnr|lnr-lock', 'lnr|lnr-briefcase'
                );
                foreach ($smcw_font_icons as $smcw_font_icon) :
                    ?>
                    <div class="smcw-hide-radio">
                        <input type="radio" id="<?php echo esc_attr($smcw_font_icon); ?>" name="smcw_settings[floating_font_icon]" class="smcw-font-icon" value="<?php echo esc_attr($smcw_font_icon); ?>" />
                        <label class="smcw-font-icon-demo">
                            <?php
                            $v = explode('|', $smcw_font_icon);
                            if (isset($v[1])) {
                                ?>
                            <span class="<?php echo esc_attr($v[0] . ' ' . $v[1]); ?>"></span>
                                <?php
                            }
                            ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="smcw-label-wrap">
        <label for="smcw-cart-icon-check" class="smcw-label">
            <?php esc_html_e('Cart effects', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <label><input type="radio" value="loader_effects" name="smcw_settings[floating_cart_effects]" class="smcw-cart-effects"/><?php esc_html_e("Loader effect", SMCW_TD); ?></label>
            <label><input type="radio" value="fly_image_effects" name="smcw_settings[floating_cart_effects]"  class="smcw-cart-effects"/><?php esc_html_e('Fly image effect', SMCW_TD); ?></label>
        </div>
    </div>
    <div class="smcw-loader-effects-wrapper smcw-none-view">
        <div class="smcw-label-wrap">
            <label for="smcw-open-cart-check" class="smcw-label">
                <?php esc_html_e('Auto open cart', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <label class="smcw-switch">
                    <input type="checkbox" class="smcw-enable-auto-open smcw-checkbox" value="0" name="smcw_settings[smcw_auto_open_cart]"/>
                    <div class="smcw-slider round"></div>
                </label>
                <p class="description"><?php esc_html_e('Enable to open the cart when item is added to the cart', SMCW_TD) ?></p>
            </div>
        </div>
        <div class="smcw-label-wrap">
            <label for="smcw-open-cart-check" class="smcw-label">
                <?php esc_html_e('Cart loader', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <label class="smcw-switch">
                    <input type="checkbox" class="smcw-enable-loader smcw-checkbox" value="0" name="smcw_settings[smcw_cart_loader]" />
                    <div class="smcw-slider round"></div>
                </label>
                <p class="description"><?php esc_html_e('Enable to show loader while adding item to the cart', SMCW_TD) ?></p>
            </div>
        </div>
        <div class="smcw-loader-wrapper" >
            <div class="smcw-label-wrap">
                <label for="smcw-open-cart-check" class="smcw-label">
                    <?php esc_html_e('Choose loader', SMCW_TD); ?>
                </label>
                <div class="smcw-field-wrap">
                    <?php
                    $smcw_loader_previews = array('loader-1', 'loader-2', 'loader-3', 'loader-4', 'loader-5', 'loader-6', 'loader-7', 'loader-8', 'loader-9', 'loader-10', 'loader-11', 'loader-12', 'loader-13', 'loader-14', 'loader-15', 'loader-16');
                    foreach ($smcw_loader_previews as $smcw_loader_preview) :
                        ?>
                        <div class="smcw-hide-radio">
                            <input type="radio" id="<?php echo esc_attr($smcw_loader_preview); ?>" name="smcw_settings[smcw_loader_preview_type]" class="smcw-loader-type" value="<?php echo esc_attr($smcw_loader_preview); ?>">
                            <label class="smcw-loader-demo" for="<?php echo esc_attr($smcw_loader_preview); ?>">
                                <img src="<?php echo SMCW_IMG_DIR . '/loader/' . $smcw_loader_preview . '.gif' ?>">
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>