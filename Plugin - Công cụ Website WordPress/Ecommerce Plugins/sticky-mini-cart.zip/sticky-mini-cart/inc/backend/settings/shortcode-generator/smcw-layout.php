<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-layout-container">
    <div class="smcw-slide-wrapper">
        <div class="smcw-label-wrap">
            <label for="smcw-template" class="smcw-label">
                <?php esc_html_e('Template', SMCW_TD); ?>
            </label>
            <div class="smcw-field-wrap">
                <select name="" class="smcw-sidebar-demo-template">
                    <?php 
                     $smcw_template_names = array('Classic Template','Light Template','Cantaloupe Template','Blonde Template','Blush Template','Intense Template','Popup Template','Mordern Template','Dark Template','Table Template');
                $k = 1;
                foreach ( $smcw_template_names as $smcw_template_name ) { ?>
                    <option value="template-<?php echo esc_attr($k); ?>" ><?php echo esc_attr($smcw_template_name); ?></option>
                    <?php 
                   $k++; 
                } ?>    </select>
                <div class="smcw-sidebar-demo smcw-preview-image">
                    <?php
                    for ($cnt = 1; $cnt <= 10; $cnt ++) {
                        ?>
                    <div class="smcw-sidebar-common <?php if ($cnt == 1) { echo esc_attr('smcw-block-view'); } else {  echo esc_attr('smcw-none-view'); } ?>" id="smcw-sidebar-demo-<?php echo esc_attr($cnt); ?>">
                        <h4><?php esc_html_e('Template', SMCW_TD); ?> <?php echo esc_attr($cnt); ?> <?php esc_html_e('Preview', SMCW_TD); ?></h4>
                            <img src="<?php echo SMCW_IMG_DIR . 'demo/sidebar/template-' . $cnt . '.png'; ?>"/>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <div class ="smcw-label-wrap">
        <label  class="smcw-label">
            <?php esc_html_e('Sticky cart position', SMCW_TD); ?>
        </label>
        <div class="smcw-field-wrap">
            <select name="smcw_settings[smcw_floating_cart_position]" class="smcw-select-position-sc">
                <option value="left_top"><?php esc_html_e('Left top', SMCW_TD) ?></option>
                <option value="left_center" ><?php esc_html_e('Left center', SMCW_TD) ?></option>
                <option value="left_bottom"><?php esc_html_e('Left bottom', SMCW_TD) ?></option>
                <option value="right_top" ><?php esc_html_e('Right top', SMCW_TD) ?></option>
                <option value="right_center" ><?php esc_html_e('Right center', SMCW_TD) ?></option>
                <option value="right_bottom" ><?php esc_html_e('Right bottom', SMCW_TD) ?></option>
            </select>
        </div>
    </div>
</div>