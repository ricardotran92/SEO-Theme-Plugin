<?php
defined('ABSPATH') or die('No script kiddies please!');
$smcw_settings = get_option('smcw_settings');
?>
<div class="smcw-label-wrap" >
    <label><?php esc_html_e('Select Page', SMCW_TD); ?></label>
    <div class="smcw-field-wrap">
        <div id="smcw_page_content" data-smcw-post="<?php echo esc_attr($smcw_post_type); ?>">
            <?php
            $args = array(
                'post_type' => esc_attr($smcw_post_type),
                'order' => 'DESC',
                'orderby' => 'ID',
                'posts_per_page' => 5,
                'post_status' => 'publish'
            );
            $query = new WP_Query($args);
            $rowCount = $query->found_posts;
            $smcw_settings['page_check'] = array();
            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $post_id = get_the_ID();
                    ?>
                    <div class="smcw-page-list-item">
                        <label>
                            <?php
                            if ($smcw_post_type == 'page') {
                                ?>
                                <input type="checkbox" name="smcw_settings[check][]" class="smcw-add-page-check"
                                       value="<?php echo esc_attr($post_id); ?>"
                                       <?php
                                       if (in_array($post_id, $selected_pages)) {
                                           echo 'checked="checked"';
                                       }
                                       ?>
                                       data-pagename="<?php the_title(); ?>"/>
                                       <?php the_title(); ?>
                                       <?php
                                   } else {
                                       ?>
                                <input type="checkbox" name="smcw_settings[woo_page_check][]" class="smcw-add-product-page-check"
                                       value="<?php echo esc_attr($post_id); ?>"
                                       <?php
                                       if (in_array($post_id, $selected_pages)) {
                                           echo 'checked="checked"';
                                       }
                                       ?>
                                       data-pagename="<?php the_title(); ?>"/>
                                       <?php
                                       the_title();
                                   }
                                   ?>
                        </label>
                    </div><?php
                }
            }
            ?>
        </div>
        <?php
        $per_page = 5;
        $total_items = $rowCount;
        $total_page = $total_items / $per_page;
        if ($total_items % $per_page != 0) {
            $total_page = intval($total_page) + 1;
        }
        $upper_limit = ($total_page <= 5) ? $total_page : 5;
        $next_arrow = 'Next';
        $prev_arrow = 'Prev';
        ?>
        <div class="smcw-pagination-block">
            <ul class="smcw-inner-paginate">
                <?php
                for ($l = 1; $l <= $upper_limit; $l ++) {
                    ?>
                <li><a href="javascript:void(0);" data-total-page="<?php echo esc_attr($total_page); ?>" data-post-id="<?php the_ID(); ?>" data-page-number="<?php echo esc_attr($l); ?>" data-type="<?php echo esc_attr($smcw_post_type); ?>" data-next-arrow="<?php echo esc_attr($next_arrow); ?>" data-prev-arrow="<?php echo esc_attr($prev_arrow); ?>" class= "<?php echo ($l == 1) ? 'smcw-current-page' : ''; ?> smcw-page-link"><?php echo esc_attr($l); ?></a></li>
                    <?php
                }
                ?>
                <li class="smcw-next-page-wrap"><a href="javascript:void(0);" data-total-page="<?php echo esc_attr($total_page); ?>"  data-post-id="<?php the_ID(); ?>" data-page-number="2" data-next-arrow="<?php echo esc_attr($next_arrow); ?>" data-prev-arrow="<?php echo esc_attr($prev_arrow); ?>" data-type="<?php echo esc_attr($smcw_post_type); ?>" class="smcw-next-page"><?php echo esc_attr($next_arrow); ?></a></li>
            </ul>
            <img src="<?php echo SMCW_IMG_DIR . '/ajax-loader.gif'; ?>" class="smcw-ajax-loader smcw-none-view"/>
        </div>
    </div>
</div>

