<?php
defined('ABSPATH') or die("No script kiddies please!");
$smcw_settings = get_option('smcw_settings');
$post_number = 5;
$smcw_post_type = sanitize_text_field($_POST['post_name']);
$post_id = sanitize_text_field($_POST['post_id']);
$page_num = sanitize_text_field($_POST['page_num']);
$pages_list = sanitize_text_field($_POST['selected_pages']);
$offset = ($page_num - 1) * $post_number;
$args = array(
    'post_type' => $smcw_post_type,
    'order' => 'DESC',
    'orderby' => 'ID',
    'posts_per_page' => $post_number,
    'post_status' => 'publish',
    'offset' => $offset
);
$query = new WP_Query($args);
$selected_pages = (!empty($pages_list)) ? explode(',', $pages_list) : array();
$rowCount = $query->found_posts;
if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();
        ?>
        <div class="smcw-page-list-item">
            <label>
                <?php
                if ($smcw_post_type == 'page') {
                    ?>
                    <input type="checkbox" name="smcw_settings[check][]" class="smcw-add-page-check"
                           value="<?php echo esc_attr($post_id); ?>"
                           <?php
                           if (in_array($post_id, $selected_pages)) {
                               echo 'checked="checked"';
                           }
                           ?>
                           data-pagename="<?php the_title(); ?>"/>
                           <?php the_title(); ?>
                           <?php
                       } else {
                           ?>
                    <input type="checkbox" name="smcw_settings[woo_page_check][]" class="smcw-add-product-page-check"
                           value="<?php echo esc_attr($post_id); ?>"
                           <?php
                           if (in_array($post_id, $selected_pages)) {
                               echo 'checked="checked"';
                           }
                           ?>
                           data-pagename="<?php the_title(); ?>"/>
                           <?php
                           the_title();
                       }
                       ?>
            </label>
        </div><?php
    }
}
