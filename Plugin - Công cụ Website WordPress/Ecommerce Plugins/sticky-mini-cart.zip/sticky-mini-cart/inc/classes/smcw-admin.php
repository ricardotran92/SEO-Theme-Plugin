<?php
defined('ABSPATH') or die('No script kiddies please!!');
if (!class_exists('SMCW_Admin')) {

    class SMCW_Admin extends SMCW_Library {

        /**
         * Includes all the backend functionality
         *
         * @since 1.0.0
         */
        function __construct() {
            add_action('admin_menu', array($this, 'smcw_register_menu'));
        }

        /**
         * Mini Cart menu in backend
         *
         * @since 1.0.0
         */
        function smcw_register_menu() {

            add_menu_page(__('Sticky Mini Cart', SMCW_TD), __('Sticky Mini Cart', SMCW_TD), 'manage_options', 'smcw-mini-cart', array($this, 'smcw_cart_lists'), 'dashicons-cart');
        }

        /**
         * Cart page
         *
         * @since 1.0.0
         */
        function smcw_cart_lists() {

            include(SMCW_PATH . 'inc/backend/smcw-cart-settings.php');
        }

    }

    new SMCW_Admin();
}