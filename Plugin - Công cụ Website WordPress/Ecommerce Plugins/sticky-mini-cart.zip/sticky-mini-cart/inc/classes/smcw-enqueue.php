<?php

defined('ABSPATH') or die('No script kiddies please!!');
if (!class_exists('SMCW_Enqueue')) {

    class SMCW_Enqueue {

        /**
         * Enqueue all the necessary JS and CSS
         *
         * since @1.0.0
         */
        function __construct() {
            add_action('admin_enqueue_scripts', array($this, 'smcw_register_admin_assets'));
            add_action('wp_enqueue_scripts', array($this, 'smcw_register_frontend_assets'));
        }

        function smcw_register_admin_assets($hook) {
            $page_array = array('smcw-mini-cart');
            if (isset($_GET['page']) && in_array(sanitize_text_field($_GET['page']), $page_array)) {
                wp_enqueue_media();
                wp_enqueue_script('wp-color-picker');
                wp_enqueue_script('smcw-admin-script', SMCW_JS_DIR . 'smcw-admin.js', array('jquery', 'wp-color-picker'), SMCW_VERSION);
                wp_enqueue_style('wp-color-picker');
                wp_enqueue_style('dashicons');
                wp_enqueue_style('linear', SMCW_CSS_DIR . 'linear-style.css', false, SMCW_VERSION);
                wp_enqueue_style('elegant', SMCW_CSS_DIR . 'elegant-icons.css', false, SMCW_VERSION);
                wp_enqueue_style('fa-brands', SMCW_CSS_DIR . 'fa-brands.css', false, SMCW_VERSION);
                wp_enqueue_style('fa-regular', SMCW_CSS_DIR . 'fa-regular.css', false, SMCW_VERSION);
                wp_enqueue_style('fa-solid', SMCW_CSS_DIR . 'fa-solid.css', false, SMCW_VERSION);
                wp_enqueue_style('fontawesome', SMCW_CSS_DIR . 'fontawesome.css', false, SMCW_VERSION);
                wp_enqueue_style('font-awesome-min', SMCW_CSS_DIR . 'font-awesome.min.css', false, SMCW_VERSION);
                wp_enqueue_style('smcw-admin', SMCW_CSS_DIR . 'smcw-admin.css', false, SMCW_VERSION);
                $admin_ajax_nonce = wp_create_nonce('smcw-admin-ajax-nonce');
                $admin_ajax_object = array('ajax_url' => admin_url('admin-ajax.php'), 'ajax_nonce' => $admin_ajax_nonce);
                wp_localize_script('smcw-admin-script', 'smcw_backend_js_params', $admin_ajax_object);
            }
        }

        function smcw_register_frontend_assets() {

            /**
             * Styles
             */
            wp_enqueue_style('dashicons');
            wp_enqueue_style('google-fonts', '//fonts.googleapis.com/css?family=Rubik:300,400,500,700&display=swap|Open+Sans:300,400,600,700&display=swap|Lato:300,400,700&display=swap|Poppins:300,400,500,600,700&display=swap|Roboto:300,400,500,700&display=swap', array(), SMCW_VERSION);
            wp_enqueue_style('jquery.mCustomScrollbar', SMCW_CSS_DIR . 'jquery.mCustomScrollbar.css', array(), SMCW_VERSION);
            wp_enqueue_style('linear', SMCW_CSS_DIR . 'linear-style.css', array(), SMCW_VERSION);
            wp_enqueue_style('elegant', SMCW_CSS_DIR . 'elegant-icons.css', false, SMCW_VERSION);
            wp_enqueue_style('fa-brands', SMCW_CSS_DIR . 'fa-brands.css', false, SMCW_VERSION);
            wp_enqueue_style('fa-regular', SMCW_CSS_DIR . 'fa-regular.css', false, SMCW_VERSION);
            wp_enqueue_style('fa-solid', SMCW_CSS_DIR . 'fa-solid.css', false, SMCW_VERSION);
            wp_enqueue_style('fontawesome', SMCW_CSS_DIR . 'fontawesome.css', false, SMCW_VERSION);
            wp_enqueue_style('font-awesome-min', SMCW_CSS_DIR . 'font-awesome.min.css', false, SMCW_VERSION);
            wp_enqueue_style('reset', SMCW_CSS_DIR . 'reset.css', array(), SMCW_VERSION);
            wp_enqueue_style('jquery.bxslider', SMCW_CSS_DIR . 'jquery.bxslider.css', array(), SMCW_VERSION);
            wp_enqueue_style('smcw-frontend', SMCW_CSS_DIR . 'smcw-frontend.css', array('jquery.mCustomScrollbar', 'jquery.bxslider', 'linear'), SMCW_VERSION);
            $smcw_settings = get_option('smcw_settings');
            $enable_custom = isset($smcw_settings['enable_custom_color']) ? esc_attr($smcw_settings['enable_custom_color']) : '0';
            $bg_color = isset($smcw_settings['smcw_bg_color']) ? esc_attr($smcw_settings['smcw_bg_color']) : '';
            $cart_color = isset($smcw_settings['smcw_cart_color']) ? esc_attr($smcw_settings['smcw_cart_color']) : '';
            $count_color = isset($smcw_settings['smcw_count_color']) ? esc_attr($smcw_settings['smcw_count_color']) : '';
            $border_color = isset($smcw_settings['smcw_border_color']) ? esc_attr($smcw_settings['smcw_border_color']) : '';
            if ($enable_custom == '1') {
                $custom_css = "
                .smcw-template-1 .smcw-cart-icon-inner-wrap>span,.smcw-template-3 .smcw-cart-icon-inner-wrap {
    background: {$bg_color};
    border: 1px solid {$border_color};
        color:{$cart_color};
}.smcw-cart-icons .smcw-cart-icon-inner-wrap .smcw-product-quantity-wrap {
    background-color: {$count_color};}.smcw-template-1 .smcw-total-price-wrapper span.woocommerce-Price-amount {
    background-color: {$count_color};
}.smcw-template-1 .smcw-cart-icons .smcw-cart-icon-inner-wrap .smcw-product-quantity-wrap {
    background-color: {$count_color};
}.smcw-cart-icons {
    background-color: {$bg_color};
        color:{$cart_color};
}.smcw-template-2 .smcw-cart-icons .smcw-cart-icon-inner-wrap .smcw-product-quantity-wrap {
    background-color: {$count_color};
}
.smcw-template-2 .smcw-total-price-wrapper span.woocommerce-Price-amount {
    background-color: {$count_color};
}.smcw-template-3 .smcw-total-price-wrapper span.woocommerce-Price-amount {
    background-color: {$bg_color};
}.smcw-template-4 .smcw-total-price-wrapper span.woocommerce-Price-amount {
    background-color: {$count_color};
}.smcw-template-4 .smcw-cart-icons {
    background-color: {$bg_color};
    color: {$cart_color};
}.smcw-template-5 .smcw-cart-icons {
     background-color: {$bg_color};
    color: {$cart_color};
}.smcw-template-5 .smcw-cart-icons .smcw-cart-icon-inner-wrap .smcw-product-quantity-wrap,.smcw-template-5 .smcw-total-price-wrapper span.woocommerce-Price-amount {
    background-color: {$count_color};
}.smcw-template-6 .smcw-total-price-wrapper span.woocommerce-Price-amount, .smcw-template-7 .smcw-total-price-wrapper span.woocommerce-Price-amount,.smcw-template-9 .smcw-cart-icons .smcw-cart-icon-inner-wrap .smcw-product-quantity-wrap {
    background-color: {$count_color};
}.smcw-template-8 .smcw-cart-icons,.smcw-template-9 .smcw-cart-icons {
    background-color: {$bg_color};
        color:{$cart_color};
}.smcw-template-8 .smcw-cart-icons .smcw-cart-icon-inner-wrap .smcw-product-quantity-wrap {
    border: 3px solid {$bg_color};
}.smcw-template-8 .smcw-total-price-wrapper span.woocommerce-Price-amount,.smcw-template-9 .smcw-total-price-wrapper span.woocommerce-Price-amount,.smcw-template-10 .smcw-total-price-wrapper span.woocommerce-Price-amount {
    background-color: {$count_color};
}";
                wp_add_inline_style('smcw-frontend', $custom_css);
            }

            /**
             * Scripts
             */
            wp_enqueue_script("jquery-effects-core");
            wp_enqueue_script('jquery-ui-core');
            wp_enqueue_script('jquery-effects-shake');
            wp_enqueue_script('flyto', SMCW_JS_DIR . 'flyto.js', array('jquery', 'jquery-ui-core', 'jquery-effects-shake'), SMCW_VERSION);
            wp_enqueue_script('jquery.bxslider', SMCW_JS_DIR . 'jquery.bxslider.js', array('jquery'), SMCW_VERSION);
            wp_enqueue_script('jquery.mCustomScrollbar', SMCW_JS_DIR . 'jquery.mCustomScrollbar.concat.js', array('jquery'), SMCW_VERSION);
            wp_enqueue_script('smcw-frontend-script', SMCW_JS_DIR . 'smcw-frontend.js', array('jquery', 'jquery-ui-core', 'jquery-effects-shake', 'jquery.mCustomScrollbar', 'jquery.bxslider', 'jquery-effects-core', 'flyto'), SMCW_VERSION);
            $frontend_ajax_nonce = wp_create_nonce('smcw-frontend-ajax-nonce');
            $frontend_ajax_object = array('ajax_url' => admin_url('admin-ajax.php'), 'ajax_nonce' => $frontend_ajax_nonce);
            wp_localize_script('smcw-frontend-script', 'cart_ajax', array('ajaxurl' => admin_url('admin-ajax.php')));
            wp_localize_script('smcw-frontend-script', 'smcw_frontend_js_params', $frontend_ajax_object);
        }

    }

    new SMCW_Enqueue();
}