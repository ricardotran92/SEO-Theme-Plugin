<?php
defined( 'ABSPATH' ) or die( 'No script kiddies please!!' );
if ( ! class_exists( 'SMCW_Shortcode' ) ) {

    /**
     * Frontend Shortcode
     */
    class SMCW_Shortcode extends SMCW_Library{

        function __construct(){
            add_shortcode( 'smcw_mini_cart', array( $this, 'smcw_shortcode_generator' ) );
        }

        /*
         * Generating shortcode with attributes
         */

        public function smcw_shortcode_generator( $atts ){
            ob_start();
            include(SMCW_PATH . 'inc/frontend/smcw-view.php' );
            $html = ob_get_contents();
            ob_get_clean();
            return $html;
        }

    }

    new SMCW_Shortcode();
}