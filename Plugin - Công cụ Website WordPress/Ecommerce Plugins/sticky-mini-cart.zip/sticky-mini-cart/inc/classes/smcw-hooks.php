<?php

defined('ABSPATH') or die('No script kiddies please!!');
if (!class_exists('SMCW_Setup')) {

    class SMCW_Setup extends SMCW_Library {

        /**
         * Includes all the backend functionality
         *
         * @since 1.0.0
         */
        function __construct() {
            add_action('admin_post_smcw_settings_save', array($this, 'smcw_save_form_settings'));
            add_action('wp_ajax_smcw_delete_action', array($this, 'smcw_delete_action'));
            add_action('wp_ajax_nopriv_smcw_delete_action', array($this, 'smcw_delete_action'));
            add_action('wp_ajax_smcw_plus_action', array($this, 'smcw_plus_action'));
            add_action('wp_ajax_nopriv_smcw_plus_action', array($this, 'smcw_plus_action'));
            add_action('wp_ajax_smcw_minus_action', array($this, 'smcw_minus_action'));
            add_action('wp_ajax_nopriv_smcw_minus_action', array($this, 'smcw_minus_action'));
            add_action('wp_ajax_smcw_count_action', array($this, 'smcw_count_action'));
            add_action('wp_ajax_nopriv_smcw_count_action', array($this, 'smcw_count_action'));
            add_action('wp_ajax_smcw_no_product_action', array($this, 'smcw_no_product_action'));
            add_action('wp_ajax_nopriv_smcw_no_product_action', array($this, 'smcw_no_product_action'));
            add_action('wp_footer', array($this, 'smcw_add_lightbox_footer'));
            add_action('wp_ajax_nopriv_smcw_view_lightbox', array($this, 'smcw_view_lightbox'));
            add_action('wp_ajax_smcw_view_lightbox', array($this, 'smcw_view_lightbox'));
            add_action('wp_ajax_nopriv_smcw_add_cart_action', array($this, 'smcw_add_cart_action'));
            add_action('wp_ajax_smcw_add_cart_action', array($this, 'smcw_add_cart_action'));
            add_action('wp_ajax_nopriv_smcw_cart_action', array($this, 'smcw_cart_action'));
            add_action('wp_ajax_smcw_cart_action', array($this, 'smcw_cart_action'));
            add_action('wp_ajax_nopriv_smcw_pagination_action', array($this, 'smcw_pagination_action'));
            add_action('wp_ajax_smcw_pagination_action', array($this, 'smcw_pagination_action'));
            add_action('wp_ajax_nopriv_smcw_pages_action', array($this, 'smcw_pages_action'));
            add_action('wp_ajax_smcw_pages_action', array($this, 'smcw_pages_action'));
            add_action('wp_footer', array($this, 'smcw_add_cart_footer'));
            add_action('wp_ajax_smcw_woocommerce_ajax_add_to_cart', array($this, 'smcw_woocommerce_ajax_add_to_cart'));
            add_action('wp_ajax_nopriv_smcw_woocommerce_ajax_add_to_cart', array($this, 'smcw_woocommerce_ajax_add_to_cart'));
        }

        function smcw_save_form_settings() {
            if (isset($_POST['smcw_form_nonce_field']) && wp_verify_nonce($_POST['smcw_form_nonce_field'], 'smcw_form_nonce')) {
                if (isset($_POST['smcw_settings'])) {
                    $smcw_common = (array) $_POST['smcw_settings'];
// sanitize array
                    $smcw_common_option = array_map('sanitize_text_field', $smcw_common);
// save data
                    update_option('smcw_settings', $smcw_common_option);
                }
            }
            wp_redirect(admin_url('admin.php?page=smcw-mini-cart&message=1'));
            exit;
        }

        function smcw_delete_action($response) {
            $key = sanitize_text_field($_POST['product_key']);
            $ItemKey = sanitize_text_field($_POST['item_key']);
            WC()->cart->remove_cart_item($ItemKey);
            $total_count = WC()->cart->get_cart_contents_count();
            $total_price = WC()->cart->total;
            $sub_total_price = WC()->cart->get_subtotal();
            $tax_calculate = wc_round_tax_total(WC()->cart->get_cart_contents_tax() + WC()->cart->get_shipping_tax() + WC()->cart->get_fee_tax());
            $response = array(
                'total_count' => $total_count,
                'total_price' => $total_price,
                'sub_total' => $sub_total_price,
                'tax_price' => $tax_calculate
            );
            echo json_encode($response);
            die();
        }

        function smcw_plus_action() {
            $cart_item_key = sanitize_text_field($_POST['item_key']);
            $quantity = sanitize_text_field($_POST['currentVal']);
            $price = sanitize_text_field($_POST['itemPrice']);
            WC()->cart->set_quantity($cart_item_key, $quantity, $refresh_totals = true);
            WC()->cart->calculate_totals();
            WC()->cart->maybe_set_cart_cookies();
            $total_count = WC()->cart->get_cart_contents_count();
            $total_price = WC()->cart->total;
            $sub_total_price = WC()->cart->get_subtotal();
            $tax_calculate = wc_round_tax_total(WC()->cart->get_cart_contents_tax() + WC()->cart->get_shipping_tax() + WC()->cart->get_fee_tax());
            $added_new_price = $quantity * $price;
            $response = array(
                'total_count' => $total_count,
                'total_price' => $total_price,
                'sub_total' => $sub_total_price,
                'tax_price' => $tax_calculate,
                'new_price' => $added_new_price
            );
            echo json_encode($response);
            die();
        }

        function smcw_count_action() {
            $total_count = WC()->cart->get_cart_contents_count();
            $total_price = WC()->cart->total;
            $response = array(
                'total_price' => $total_price,
                'total_count' => $total_count
            );
            echo json_encode($response);
            die();
        }

        function smcw_minus_action() {
            $cart_item_key = sanitize_text_field($_POST['item_key']);
            $quantity = sanitize_text_field($_POST['currentVal']);
            $price = sanitize_text_field($_POST['itemPrice']);
            WC()->cart->set_quantity($cart_item_key, $quantity, $refresh_totals = true);
            WC()->cart->calculate_totals();
            WC()->cart->maybe_set_cart_cookies();
            $total_count = WC()->cart->get_cart_contents_count();
            $total_price = WC()->cart->total;
            $sub_total_price = WC()->cart->get_subtotal();
            $tax_calculate = wc_round_tax_total(WC()->cart->get_cart_contents_tax() + WC()->cart->get_shipping_tax() + WC()->cart->get_fee_tax());
            $added_new_price = $quantity * $price;
            $response = array(
                'total_count' => $total_count,
                'total_price' => $total_price,
                'sub_total' => $sub_total_price,
                'tax_price' => $tax_calculate,
                'new_price' => $added_new_price
            );
            echo json_encode($response);
            die();
        }

        function smcw_add_lightbox_footer() {
            include (SMCW_PATH . 'inc/frontend/items-lightbox.php');
        }

        /*
         * Inline view
         */

        function smcw_view_lightbox() {
            include (SMCW_PATH . 'inc/frontend/data/ajax-content.php');
            die();
        }

        function smcw_add_cart_action() {
            include (SMCW_PATH . 'inc/frontend/data/cart-action.php');
            die();
        }

        function smcw_cart_action() {
            $template = sanitize_text_field($_POST['template']);
            include (SMCW_PATH . 'inc/frontend/data/mini-action.php');
            die();
        }

        function smcw_no_product_action() {
            $template = sanitize_text_field($_POST['template']);
            $key = sanitize_text_field($_POST['product_key']);
            $ItemKey = sanitize_text_field($_POST['item_key']);
            WC()->cart->remove_cart_item($ItemKey);
            include (SMCW_PATH . 'inc/frontend/layout/empty-action.php');
            die();
        }

        function smcw_pagination_action() {
            include (SMCW_PATH . 'inc/backend/smcw-pagination.php');
            die();
        }

        function smcw_pages_action() {
            include (SMCW_PATH . 'inc/backend/settings/page-action.php');
            die();
        }

        function smcw_add_cart_footer() {
            $smcw_settings = get_option('smcw_settings');
            $required_keys = array('enable_floating_button', 'floating_cart_position', 'floating_cart_effects', 'auto_open_cart', 'cart_loader', 'loader', 'cart_icon', 'template');
            $shortcode_atts = array();
            if (!empty($smcw_settings)) {
                foreach ($smcw_settings as $key => $val) {
                    if ((is_array($val) || in_array($key, $required_keys))) {
                        $shortcode_atts[] = $key . "='" . $val . "'";
                    }
                }
            }
            $shortcode_atts = implode(' ', $shortcode_atts);
            $shortcode = '[smcw_mini_cart ' . $shortcode_atts . ' ]';
            global $post;
            if ((!is_page('cart') || !is_cart()) && !is_product()) {
                if (isset($smcw_settings['show_cart_page'])) {
                    if ($smcw_settings['show_cart_page'] == 'specific_page') {
                        if (is_shop()) {
                            $id = wc_get_page_id('shop');
                        } else {
                            $id = $post->ID;
                        }
                        $speci_pages = (!empty($smcw_settings['specific_pages_list'])) ? esc_attr($smcw_settings['specific_pages_list']) : '';
                        $specific_pages = explode(",", $speci_pages);
                        if (in_array($id, $specific_pages)) {
                            echo do_shortcode("$shortcode");
                        }
                    } else {
                        echo do_shortcode("$shortcode");
                    }
                }
            }
            if (isset($smcw_settings['show_cart_product']) && is_product()) {
                if ($smcw_settings['show_cart_product'] == 'specific_product') {
                    $product_pages = (!empty($smcw_settings['specific_product_pages_list'])) ? $smcw_settings['specific_product_pages_list'] : '';
                    $specific_product_pages = explode(",", $product_pages);
                    if (in_array($post->ID, $specific_product_pages)) {
                        echo do_shortcode("$shortcode");
                    }
                } else {
                    echo do_shortcode("$shortcode");
                }
            }
        }

        function smcw_woocommerce_ajax_add_to_cart() {
            include (SMCW_PATH . 'inc/frontend/data/single-action.php');
            wp_die();
        }

    }

    new SMCW_Setup();
}