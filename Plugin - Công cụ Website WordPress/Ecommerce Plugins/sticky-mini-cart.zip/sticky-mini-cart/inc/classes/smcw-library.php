<?php

defined('ABSPATH') or die('No script kiddies please!!');
if (!class_exists('SMCW_Library')) {

    class SMCW_Library {

        /**
         * Prints array in pre format
         *
         * @since 1.0.0
         *
         * @param array $array
         */
        function smcw_check_array($array) {
            echo "<pre>";
            print_r($array);
            echo "</pre>";
        }

        /**
         * Sanitizes Multi Dimensional Array
         * @param array $array
         * @param array $sanitize_rule
         * @return array
         *
         * @since 1.0.0
         */
        function smcw_array_sanitize($array = array(), $sanitize_rule = array()) {
            if (!is_array($array) || count($array) == 0) {
                return array();
            }

            foreach ($array as $k => $v) {
                if (!is_array($v)) {

                    $default_sanitize_rule = (is_numeric($k)) ? 'html' : 'text';
                    $sanitize_type = isset($sanitize_rule[$k]) ? $sanitize_rule[$k] : $default_sanitize_rule;
                    $array[$k] = $this->smcw_value_sanitize($v, $sanitize_type);
                }
                if (is_array($v)) {
                    $array[$k] = $this->smcw_array_sanitize($v, $sanitize_rule);
                }
            }

            return $array;
        }

        /**
         * Sanitizes Value
         *
         * @param type $value
         * @param type $sanitize_type
         * @return string
         *
         * @since 1.0.0
         */
        function smcw_value_sanitize($value = '', $sanitize_type = 'text') {
            switch ($sanitize_type) {
                case 'html':
                    $allowed_html = wp_kses_allowed_html('post');
                    return wp_kses($value, $allowed_html);
                    break;
                default:
                    return sanitize_text_field($value);
                    break;
            }
        }

        function smcw_print_checkbox($form = '', $field_title = '', $selected_page = array()) {
            foreach ($selected_page as $page) {
                $option_value = get_the_ID();
                $name = the_title();
                if (is_array($selected_page)) {
                    $checked = (in_array($option_value, $selected_page)) ? 'checked="checked"' : '';
                } else {
                    $checked = ($selected_page == $option_value) ? 'checked="checked"' : '';
                }
                $form .= '<label class="smcw-checkbox-label"><input type="checkbox" name="' . $field_title . '[]"  value="' . $option_value . '" ' . $checked . '/>' . $name . '</label>';

                if (!empty($page->children)) {

                    $form .= $this->smcw_print_checkbox($field_title, $selected_page);
                }
            }

            return $form;
        }

        function smcw_cart_totals_coupon_html($coupon) {
            if (is_string($coupon)) {
                $coupon = new WC_Coupon($coupon);
            }

            $discount_amount_html = '';

            $amount = WC()->cart->get_coupon_discount_amount($coupon->get_code(), WC()->cart->display_cart_ex_tax);
            $discount_amount_html = '-' . wc_price($amount);

            if ($coupon->get_free_shipping() && empty($amount)) {
                $discount_amount_html = __('Free shipping coupon', 'woocommerce');
            }

            $discount_amount_html = apply_filters('woocommerce_coupon_discount_amount_html', $discount_amount_html, $coupon);
            $coupon_html = $discount_amount_html . ' <a href="javascript:void(0);" class="smcw-woocommerce-remove-coupon" data-coupon="' . esc_attr($coupon->get_code()) . '">' . __('[Remove]', 'woocommerce') . '</a>';
            echo $coupon_html;
        }

    }

}