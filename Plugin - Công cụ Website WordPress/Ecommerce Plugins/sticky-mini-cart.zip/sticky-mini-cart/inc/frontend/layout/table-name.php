<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-table-header-wrap">
    <div class="smcw-item-label-wrap">
        <?php esc_html_e('Image', SMCW_TD); ?>
    </div>
    <div class="smcw-item-label-wrap">
        <?php esc_html_e('Product', SMCW_TD); ?>
    </div>
    <div class="smcw-item-label-wrap">
        <?php esc_html_e('Quantity', SMCW_TD); ?>
    </div>
    <div class="smcw-item-label-wrap">
        <?php esc_html_e('Price', SMCW_TD); ?>
    </div>
</div>