<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-related-main-container">
    <div class="smcw-related-prd-title">
        <?php
        if (isset($smcw_settings['smcw_suggested_title_cart'])) {
            echo esc_attr($smcw_settings['smcw_suggested_title_cart']);
        } else {
            esc_html_e('You may also like', SMCW_TD);
        }
        ?>
    </div>
    <div class="smcw-related-product">
        <?php
        $crosssells = get_post_meta($last_item_id, '_crosssell_ids', true);
        $args = array(
            'post_type' => 'product',
            'order' => 'desc',
            'orderby' => 'id',
            'posts_per_page' => 3,
            'post__in' => $crosssells
        );
        $query = new WP_Query($args);
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $product_item_id = get_the_ID();
                $thumbnail_url = get_the_post_thumbnail_url($product_item_id, 'thumbnail');
                ?>
                <div class="smcw-inner-related-wrap">
                    <?php if ($template == 'template-7' || $template == 'template-10') {
                        ?>
                        <div class="smcw-simg-wrap">
                            <a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url($thumbnail_url); ?>"></a>
                        </div>
                        <div class="smcw-sp-inner-wrap">
                            <div class="smcw-sp-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </div>
                            <div class="smcw-sp-price">
                                <?php woocommerce_template_loop_price($product_item_id); ?>
                            </div>
                            <div class="smcw-button-cart">
                                <?php
                                if (class_exists('WooCommerce')) {
                                    woocommerce_template_loop_add_to_cart();
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="smcw-simg-wrap">
                            <a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url($thumbnail_url); ?>"></a>
                        </div>
                        <div class="smcw-sp-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </div>
                        <div class="smcw-sp-price">
                            <?php woocommerce_template_loop_price($product_item_id); ?>
                        </div>
                    <?php } ?>
                </div>
                <?php
            }
        }
        ?>
    </div>
</div>
