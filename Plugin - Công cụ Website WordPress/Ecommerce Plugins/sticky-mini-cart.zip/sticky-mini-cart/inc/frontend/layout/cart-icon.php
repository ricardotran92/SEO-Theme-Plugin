<?php
defined('ABSPATH') or die("No script kiddies please!");
global $woocommerce;
if ($template == 'template-1') {
    ?>
    <div class="smcw-cart-icon-inner-wrap">
        <?php
        $v = explode('|', $icon);
        if (isset($v[1])) {
            ?>
            <span class="<?php echo esc_attr($v[0] . ' ' . $v[1]); ?>"></span>
            <?php
        }
        ?>
        <div class="smcw-product-quantity-wrap">
            <?php
            if (WC()->cart->cart_contents_count > 0) {
                echo WC()->cart->get_cart_contents_count();
            } else {
                echo '0';
            }
            ?>
        </div>
        <?php if (isset($smcw_settings['enable_floating_price']) && $smcw_settings['enable_floating_price'] == '1') { ?>
            <div class="smcw-side-price-wrapper">
                <div class="smcw-total-price-wrapper" data-symbol="<?php echo get_woocommerce_currency_symbol(); ?>">
                    <?php
                    $total = WC()->cart->total;
                    echo wc_price($total);
                    ?>
                </div>
            </div>
        <?php } ?>
    </div>
    <?php
} else if ($template == 'template-2') {
    ?>
    <div class="smcw-cart-icon-inner-wrap">
        <?php
        $v = explode('|', $icon);
        if (isset($v[1])) {
            ?>
            <span class="<?php echo esc_attr($v[0] . ' ' . $v[1]); ?>"></span>
            <?php
        }
        ?>
        <div class="smcw-product-quantity-wrap">
            <?php
            if (WC()->cart->cart_contents_count > 0) {
                echo WC()->cart->get_cart_contents_count();
            } else {
                echo '0';
            }
            ?>
        </div>
        <?php if (isset($smcw_settings['enable_floating_price']) && $smcw_settings['enable_floating_price'] == '1') { ?>
            <div class="smcw-side-price-wrapper">
                <div class="smcw-total-price-wrapper" data-symbol="<?php echo get_woocommerce_currency_symbol(); ?>">
                    <?php
                    $total = WC()->cart->total;
                    echo wc_price($total);
                    ?>
                </div>
            </div>
        <?php } ?>
    </div>
    <?php
} else {
    ?>
    <div class="smcw-cart-icon-inner-wrap">
        <?php
        $v = explode('|', $icon);
        if (isset($v[1])) {
            ?>
            <span class="<?php echo esc_attr($v[0] . ' ' . $v[1]); ?>"></span>
            <?php
        }
        ?>
        <div class="smcw-product-quantity-wrap">
            <?php
            if (WC()->cart->cart_contents_count > 0) {
                echo WC()->cart->get_cart_contents_count();
            } else {
                echo '0';
            }
            ?>
        </div>
        <?php if (isset($smcw_settings['enable_floating_price']) && $smcw_settings['enable_floating_price'] == '1') { ?>
            <div class="smcw-side-price-wrapper">
                <div class="smcw-total-price-wrapper" data-symbol="<?php echo get_woocommerce_currency_symbol(); ?>">
                    <?php
                    $total = WC()->cart->total;
                    echo wc_price($total);
                    ?>
                </div>
            </div>
        <?php } ?>
    </div>
    <?php
}