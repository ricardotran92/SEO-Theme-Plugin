<?php
defined('ABSPATH') or die("No script kiddies please!");
$smcw_settings = get_option('smcw_settings');
?>
<div class="smcw-price-container" data-symbol="<?php echo get_woocommerce_currency_symbol(); ?>">
    <?php
    if (isset($smcw_settings['smcw_enable_subtotal_price']) && $smcw_settings['smcw_enable_subtotal_price'] == '1') {
        ?>
        <div class="smcw-subtotal-wrap">
            <span class="smcw-subtotal-label">
                <?php
                esc_html_e('Subtotal', SMCW_TD);
                ?>
            </span>
            <div class="smcw-items-subtotal-price">
                <?php
                echo WC()->cart->get_cart_subtotal();
                ?>
            </div>
        </div>
        <?php
    }
    if (isset($smcw_settings['smcw_enable_shipping_price']) && $smcw_settings['smcw_enable_shipping_price'] == '1') {
        ?>
        <div class="smcw-items-shiping-price">
            <span class="smcw-shipping-label">
                <?php esc_html_e('Shipping', SMCW_TD); ?>
            </span>
            <div class="smcw-shipping-price-wrap">
                <?php
                echo WC()->cart->get_cart_shipping_total();
                ?>
            </div>
        </div>
        <?php
    }
    if (isset($smcw_settings['smcw_enable_tax_price']) && $smcw_settings['smcw_enable_tax_price'] == '1') {
        ?>
        <div class="smcw-items-tax-price">
            <span class="smcw-taxes-label">
                <?php
                esc_html_e('Taxes', SMCW_TD);
                ?>
            </span>
            <div class="smcw-tax-price-wrap">
                <?php
                echo wc_price(wc_round_tax_total(WC()->cart->get_cart_contents_tax() + WC()->cart->get_shipping_tax() + WC()->cart->get_fee_tax()));
                ?>
            </div>
        </div>
    <?php } ?>
</div>
<?php
if (isset($smcw_settings['smcw_enable_total_price']) && $smcw_settings['smcw_enable_total_price'] == '1') {
    ?>
    <div class="smcw-total-price-container">
        <span class="smcw-total-label">
            <?php esc_html_e('Total', SMCW_TD); ?>
        </span>
        <div class="smcw-total-price-wrap">
            <?php
            $total = WC()->cart->total;
            echo wc_price($total);
            ?>
        </div>
    </div>
    <?php
}
