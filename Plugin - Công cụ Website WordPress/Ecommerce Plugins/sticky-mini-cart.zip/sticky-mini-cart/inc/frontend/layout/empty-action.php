<?php
defined('ABSPATH') or die("No script kiddies please!");
$enable_shopping = isset($smcw_settings['smcw_shopping_button']) ? esc_attr($smcw_settings['smcw_shopping_button']) : '1';
?>
<div class="smcw-empty-cart-wrap">
    <?php
    if ($template == 'template-4') {
        ?>
        <div class="smcw-zero-wrap">
            <?php
            echo '0';
            esc_html_e(' Items', SMCW_TD);
            ?>
        </div>
        <div class="smcw-empty-label">
            <?php
            esc_html_e('No product in the cart', SMCW_TD);
            ?>
        </div>
        <?php
        include(SMCW_PATH . 'inc/frontend/data/start-button.php' );
    } else {
        ?>

        <div class="smcw-empty-label">
            <?php
            esc_html_e('No product in the cart', SMCW_TD);
            ?>
        </div>
        <?php
        include(SMCW_PATH . 'inc/frontend/data/start-button.php' );
    }
    ?>
</div>
