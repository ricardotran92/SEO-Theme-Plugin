<?php
defined('ABSPATH') or die("No script kiddies please!");
$scroll_class = 'smcw-cart-max-wrap';
$smcw_settings = get_option('smcw_settings');
if ($template == 'template-10') {
    include(SMCW_PATH . 'inc/frontend/layout/table-name.php');
}
?>
<div class="<?php echo esc_attr($scroll_class); ?>">
    <?php
    $ids = array();
    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
        $item = $cart_item['data'];
        if (!empty($item)) {
            $product_id = $cart_item['product_id'];
            $product = new WC_product($product_id);
            $ids[] = $product_id;
            $product_name = $product->get_name();
            $thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
            $product_permalink = $product->get_permalink();
            $product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
            ?>
            <div class="smcw-product-inner-wrap" data-item-key="<?php echo esc_attr($cart_item_key); ?>" data-product-price="<?php echo $cart_item['data']->get_price();?>" data-product-key="<?php echo esc_attr($product_id); ?>" <?php
            if ($_product->is_type('variation')) {
                $variation_id = $cart_item['variation_id'];
                ?>
                     data-item-variation="<?php echo esc_attr($variation_id); ?>"
                 <?php }
                 ?>>
                     <?php if ($template == 'template-1') {
                         ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-left-wrap">
                            <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                        </div>
                        <div class="smcw-right-wrapper">
                            <div class="smcw-product-title">
                                <?php echo esc_attr($product_name); ?>
                            </div>
                            <div class="smcw-product-price-wrap">
                                <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                    <div class="smcw-cart-quantity">
                                        <div class="smcw-item-quty">
                                            <span class="quantity">
                                                <?php echo esc_attr($cart_item['quantity']); ?>
                                            </span>
                                            <span class="eleganticons icon_close"></span>
                                            <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                        </div>
                                    </div>
                                <?php } include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            </div>
                            <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                                <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                    <span class="dashicons dashicons-no-alt"></span>
                                </div>
                                <?php
                            }
                            if (!empty($_product) && $_product->is_type('variation')) {
                                ?>
                                <div class="smcw-items-variation-wrap">
                                    <?php
                                    echo wc_get_formatted_variation($_product->get_variation_attributes(), false, true, true);
                                    ?> </div><?php
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                } else if ($template == 'template-2') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-item-detail-wrap">
                            <div class="smcw-left-wrap">
                                <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                            </div>
                            <div class="smcw-right-wrapper">
                                <div class="smcw-inner-title-wrap">
                                    <div class="smcw-product-title">
                                        <?php echo esc_attr($product_name); ?>
                                    </div>
                                    <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                                        <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                            <span class="lnr lnr-trash"></span>
                                        </div>
                                    <?php } ?>
                                </div>
                                <div class="smcw-cart-quantity">
                                    <div class="smcw-item-quty">
                                        <?php
                                        esc_html_e('Qty:', SMCW_TD);
                                        ?>
                                        <span class="quantity">
                                            <?php echo esc_attr($cart_item['quantity']); ?>
                                        </span>
                                    </div>
                                    <?php include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                                </div>
                                <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                    <div class="smcw-item-price">
                                        <?php echo wc_price($cart_item['quantity']*$cart_item['data']->get_price()); //apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);//
                                        ?>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php
                        $product_item = $cart_item['data'];
                        if (!empty($_product) && $_product->is_type('variation')) {
                            ?>
                            <div class="smcw-items-variation-wrap">
                                <div class="smcw-attribute-down">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                </div>
                                <div class="smcw-variation-wrapper" style="display: none;">
                                    <?php
                                    echo wc_get_formatted_variation($_product->get_variation_attributes());
                                    ?>
                                </div>
                            </div>
                        <?php }
                        ?>
                    </div>
                    <?php
                } else if ($template == 'template-3') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-left-wrap">
                            <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                        </div>
                        <div class="smcw-right-wrapper">
                            <div class="smcw-inner-title-wrap">
                                <div class="smcw-product-title">
                                    <?php echo esc_attr($product_name); ?>
                                </div>
                            </div>
                            <?php include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            <div class="smcw-cart-quantity">
                                <div class="smcw-item-quty">
                                    <dl class="smcw-qty-wrap">
                                        <dt>
                                            <?php
                                            esc_html_e('Qty:', SMCW_TD);
                                            ?></dt>
                                        <dd>
                                            <?php
                                            echo esc_attr($cart_item['quantity']);
                                            ?>
                                        </dd>
                                    </dl>
                                </div>
                                <?php
                                if (!empty($_product) && $_product->is_type('variation')) {
                                    ?>
                                    <div class="smcw-items-variation-wrap">
                                        <?php
                                        echo wc_get_formatted_variation($_product->get_variation_attributes());
                                        ?>
                                    </div>
                                <?php }
                                ?>
                            </div>
                        </div>
                        <div class="smcw-corner-wrap">
                            <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                <div class="smcw-item-price">
                                    <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                </div>
                            <?php } if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                                <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                    <?php esc_html_e('Remove', SMCW_TD); ?>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <?php
                } else if ($template == 'template-4') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                            <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                <span class="dashicons dashicons-no-alt"></span>
                            </div>
                        <?php } ?>
                        <div class="smcw-left-wrap">
                            <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                        </div>
                        <div class="smcw-right-wrapper">
                            <div class="smcw-product-title">
                                <?php echo esc_attr($product_name); ?>
                            </div>
                            <?php include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                <div class="smcw-cart-quantity">
                                    <div class="smcw-item-quty">
                                        <span class="quantity">
                                            <?php echo esc_attr($cart_item['quantity']); ?>
                                        </span>
                                        <span class="eleganticons icon_close"></span>
                                        <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                    </div>
                                </div>
                                <?php
                            }
                            $product_item = $cart_item['data'];
                            if (!empty($_product) && $_product->is_type('variation')) {
                                ?>
                                <div class="smcw-items-variation-wrap">
                                    <?php
                                    echo wc_get_formatted_variation($_product->get_variation_attributes(), false, true, true);
                                    ?> </div><?php
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                } else if ($template == 'template-5') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-item-detail-wrap">
                            <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                                <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                    <span class="lnr lnr-trash"></span>
                                </div>
                            <?php } ?>
                            <div class="smcw-left-wrapper">
                                <div class="smcw-product-title">
                                    <?php echo esc_attr($product_name); ?>
                                </div>
                                <?php include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                                <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                    <div class="smcw-cart-quantity">
                                        <div class="smcw-item-quty">
                                            <span class="quantity">
                                                <?php echo esc_attr($cart_item['quantity']); ?>
                                            </span>
                                            <span class="eleganticons icon_close"></span>
                                            <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="smcw-right-wrap">
                                <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                            </div>
                        </div>
                        <?php
                        $product_item = $cart_item['data'];
                        if (!empty($_product) && $_product->is_type('variation')) {
                            ?>
                            <div class="smcw-items-variation-wrap">
                                <div class="smcw-attribute-down">
                                    <span class="lnr lnr-chevron-down"></span>
                                </div>
                                <div class="smcw-variation-wrapper smcw-nonactive">
                                    <?php
                                    echo wc_get_formatted_variation($_product->get_variation_attributes());
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <?php
                } else if ($template == 'template-6') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-left-wrap">
                            <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                        </div>
                        <div class="smcw-right-wrapper">
                            <div class="smcw-product-title">
                                <?php echo esc_attr($product_name); ?>
                            </div>
                            <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                <div class="smcw-cart-quantity">
                                    <div class="smcw-item-quty">
                                        <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                        <?php echo esc_attr('('); ?>
                                        <span class="eleganticons icon_close"></span>
                                        <span class="quantity">
                                            <?php echo esc_attr($cart_item['quantity']); ?>
                                        </span>
                                        <?php echo esc_attr(')'); ?>
                                    </div>
                                </div>
                            <?php } include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            <?php
                            $product_item = $cart_item['data'];
                            if (!empty($_product) && $_product->is_type('variation')) {
                                ?>
                                <div class="smcw-items-variation-wrap">
                                    <div class="smcw-variation-wrapper">
                                        <?php
                                        echo wc_get_formatted_variation($_product->get_variation_attributes());
                                        ?>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                            <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                <span class="lnr lnr-trash"></span>
                            </div>
                        <?php } ?>
                    </div>
                    <?php
                } else if ($template == 'template-7') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                            <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                <span class="lnr lnr-trash"></span>
                            </div>
                        <?php } ?>
                        <div class="smcw-left-wrap">
                            <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                        </div>
                        <div class="smcw-right-wrapper">
                            <div class="smcw-title-inner-wrap">
                                <div class="smcw-product-title">
                                    <?php echo esc_attr($product_name); ?>
                                </div>
                                <?php
                                $product_item = $cart_item['data'];
                                if (!empty($_product) && $_product->is_type('variation')) {
                                    ?>
                                    <div class="smcw-items-variation-wrap">
                                        <div class="smcw-variation-wrapper">
                                            <?php
                                            echo wc_get_formatted_variation($_product->get_variation_attributes());
                                            ?>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                <div class="smcw-cart-quantity">
                                    <span class="dashicons dashicons-no-alt"></span>
                                    <div class="smcw-item-quty">
                                        <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <?php
                } else if ($template == 'template-8') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-item-detail-wrap">
                            <div class="smcw-left-wrap">
                                <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                            </div>
                            <div class="smcw-right-wrapper">
                                <div class="smcw-inner-title-wrap">
                                    <div class="smcw-product-title">
                                        <?php echo esc_attr($product_name); ?>
                                    </div>
                                </div>
                                <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                    <div class="smcw-item-price">
                                        <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                    </div>
                                <?php } include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            </div>
                        </div>
                        <div class="smcw-bottom-wrap">
                            <?php
                            $product_item = $cart_item['data'];
                            if (!empty($_product) && $_product->is_type('variation')) {
                                ?>
                                <div class="smcw-items-variation-wrap">
                                    <div class="smcw-items-more-down">
                                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    </div>
                                    <div class="smcw-variation-container smcw-nonactive">
                                        <?php
                                        echo wc_get_formatted_variation($_product->get_variation_attributes());
                                        ?>
                                    </div>
                                </div>
                                <?php
                            }
                            if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') {
                                ?>
                                <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                    <span class="fas fa-trash"></span>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <?php
                } else if ($template == 'template-9') {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-left-wrapper">
                            <div class="smcw-product-title">
                                <?php echo esc_attr($product_name); ?>
                            </div>
                            <?php include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                <div class="smcw-product-price-wrap">
                                    <div class="smcw-cart-quantity">
                                        <div class="smcw-item-quty">
                                            <span class="quantity">
                                                <?php echo esc_attr($cart_item['quantity']); ?>
                                            </span>
                                            <span class="eleganticons icon_close"></span>
                                            <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            $product_item = $cart_item['data'];
                            if (!empty($_product) && $_product->is_type('variation')) {
                                ?>
                                <div class="smcw-items-variation-wrap">
                                    <?php
                                    echo wc_get_formatted_variation($_product->get_variation_attributes(), false, true, true);
                                    ?> </div><?php
                            }
                            ?>
                        </div>
                        <div class="smcw-right-wrap">
                            <?php include (SMCW_PATH . 'inc/frontend/data/image.php');
                            ?>
                        </div>
                        <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                            <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                <span class="eleganticons icon_close"></span>
                            </div>
                        <?php } ?>
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="smcw-each-item-wrapper">
                        <div class="smcw-left-wrap">
                            <?php include (SMCW_PATH . 'inc/frontend/data/image.php'); ?>
                        </div>
                        <div class="smcw-right-wrapper">
                            <div class="smcw-title-inner-wrap">
                                <div class="smcw-product-title">
                                    <?php echo esc_attr($product_name); ?>
                                </div>
                                <?php
                                $product_item = $cart_item['data'];
                                if (!empty($_product) && $_product->is_type('variation')) {
                                    ?>
                                    <div class="smcw-items-variation-wrap">
                                        <div class="smcw-variation-wrapper">
                                            <?php
                                            echo wc_get_formatted_variation($_product->get_variation_attributes());
                                            ?>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php include(SMCW_PATH . 'inc/frontend/data/quantity.php' ); ?>
                            <?php if (isset($smcw_settings['smcw_enable_price_tag']) && $smcw_settings['smcw_enable_price_tag'] == '1') { ?>
                                <div class="smcw-item-price">
                                    <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                                </div>
                            <?php } ?>
                        </div>
                        <?php if (isset($smcw_settings['smcw_remove_product']) && $smcw_settings['smcw_remove_product'] == '1') { ?>
                            <div class="smcw-delete-product" data-product-key="<?php echo esc_attr($product_id); ?>">
                                <span class="lnr lnr-trash"></span>
                            </div>
                        <?php } ?>
                    </div>
                    <?php
                }
                ?>  </div>
            <?php
        }
    }
    $last_item_id = end($ids);
    ?>
</div>
<div class="smcw-bottom-container">
    <?php
    include(SMCW_PATH . 'inc/frontend/layout/price.php');
    include(SMCW_PATH . 'inc/frontend/data/buttons.php');
    ?>
</div>
<?php
if (isset($smcw_settings['smcw_suggest_product']) && $smcw_settings['smcw_suggest_product'] == '1') {
    include(SMCW_PATH . 'inc/frontend/layout/relate-item.php');
}