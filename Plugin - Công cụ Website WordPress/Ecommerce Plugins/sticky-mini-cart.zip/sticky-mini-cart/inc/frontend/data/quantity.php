<?php
defined('ABSPATH') or die("No script kiddies please!");
$enable_quantity_change = isset($smcw_settings['smcw_product_quantity']) ? esc_attr($smcw_settings['smcw_product_quantity']) : '0';
if ($enable_quantity_change == '1') {
    if ($template == 'template-2') {
        ?>
        <div class="smcw-quantity">
            <div class="smcw-input">
                <input type="text" class="smcw-quantity-inputs" value="<?php
                echo esc_attr($cart_item['quantity']);
                ?>" />
            </div>
            <div class="smcw-minus-button"><?php echo esc_attr('-'); ?></div>
            <div class="smcw-plus-button"><?php echo esc_attr('+'); ?></div>
            <div class="smcw-hiden-wrap smcw-nonactive">
                <?php esc_html_e('Min quantity required', SMCW_TD); ?>
            </div>
        </div>
        <?php
    } 
    else if ($template == 'template-3') {
        ?>
        <div class="smcw-quantity">
            <div class="smcw-input">
                <input type="text" class="smcw-quantity-inputs" value="<?php
                echo esc_attr($cart_item['quantity']);
                ?>" />
            </div>
            <div class="smcw-qnty-container">
                <div class="smcw-plus-button">
                    <span class="eleganticons arrow_carrot-up"></span>
                </div>
                <div class="smcw-minus-button">
                    <span class="eleganticons arrow_carrot-down"></span>
                </div>
            </div>
            <div class="smcw-hiden-wrap smcw-nonactive">
                <?php esc_html_e('Min quantity required', SMCW_TD); ?>
            </div>
        </div>
        <?php
    } else if ($template == 'template-6') {
        ?>
        <div class="smcw-quantity">
            <div class="smcw-input">
                <input type="text" class="smcw-quantity-inputs" value="<?php
                echo esc_attr($cart_item['quantity']);
                ?>" />
            </div>
            <div class="smcw-qnty-container">
                <div class="smcw-plus-button">
                    <span class="eleganticons arrow_triangle-up"></span>
                </div>
                <div class="smcw-minus-button">
                    <span class="eleganticons arrow_triangle-down"></span>
                </div>
            </div>
            <div class="smcw-hiden-wrap smcw-nonactive">
                <?php esc_html_e('Min quantity required', SMCW_TD); ?>
            </div>
        </div>
        <?php
    } else if ($template == 'template-9') {
        ?>
        <div class="smcw-quantity">
            <?php esc_html_e('Quantity ', SMCW_TD); ?>
            <div class="smcw-input">
                <input type="text" class="smcw-quantity-inputs" value="<?php
                echo esc_attr($cart_item['quantity']);
                ?>" />
            </div>
            <div class="smcw-qnty-container">
                <div class="smcw-plus-button">
                    <span class="eleganticons arrow_carrot-up"></span>
                </div>
                <div class="smcw-minus-button">
                    <span class="eleganticons arrow_carrot-down"></span>
                </div>
            </div>
            <div class="smcw-hiden-wrap smcw-nonactive">
                <?php esc_html_e('Min quantity required', SMCW_TD); ?>
            </div>
        </div>
        <?php
    } else {
        ?>
        <div class="smcw-quantity">
            <div class="smcw-minus-button">-</div>
            <div class="smcw-input">
                <input type="text" class="smcw-quantity-inputs" value="<?php
                echo esc_attr($cart_item['quantity']);
                ?>" />
            </div>
            <div class="smcw-plus-button">+</div>
            <div class="smcw-hiden-wrap smcw-nonactive">
                <?php esc_html_e('Min quantity required', SMCW_TD); ?>
            </div>
        </div>
        <?php
    }
}
