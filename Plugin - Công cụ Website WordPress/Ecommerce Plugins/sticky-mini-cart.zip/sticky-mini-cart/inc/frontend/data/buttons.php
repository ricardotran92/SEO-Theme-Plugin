<?php
defined('ABSPATH') or die("No script kiddies please!");
$checkout_url = wc_get_checkout_url();
$cart_url = wc_get_cart_url();
$enable_checkout = isset($smcw_settings['smcw_checkout_button']) ? esc_attr($smcw_settings['smcw_checkout_button']) : '0';
?>
<div class="smcw-buttons-wrapper">
    <div class="smcw-cart-url-wrap">
        <a href="<?php echo esc_url($cart_url); ?>"><?php esc_html_e('Cart', SMCW_TD); ?></a>
    </div>
    <?php if ($enable_checkout == '1') {
        ?>
        <div class="smcw-checkout-wrap">
            <a href="<?php echo esc_url($checkout_url); ?>">
                <?php
                if (isset($smcw_settings['smcw_checkout_text']) && $smcw_settings['smcw_checkout_text']!='' ) {
                    echo esc_attr($smcw_settings['smcw_checkout_text']);
                } else {
                     esc_html_e('Checkout', SMCW_TD);
                }
                ?>
            </a>
        </div>
    <?php } ?>
</div>

