<?php
defined('ABSPATH') or die("No script kiddies please!");
$product_item_id = sanitize_text_field($_POST['product_id']);
$args = array(
    'p' => $product_item_id, // ID of a page, post, or custom type
    'post_type' => 'product'
);
$query = new WP_Query($args);
?>
<div class="woocommerce smcw-variation-container">
    <div class="smcw-close-variation">
        <span class="dashicons dashicons-no smcw-close"></span>
    </div>
    <?php
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            include (SMCW_PATH . 'inc/frontend/data/content.php');
        }
    }
    ?>

</div>
<?php
wp_reset_postdata();




