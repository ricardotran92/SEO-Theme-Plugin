<?php
defined('ABSPATH') or die("No script kiddies please!");
$product = new WC_product($product_item_id);
$attachment_ids = $product->get_gallery_attachment_ids();
$id = rand(1111111, 9999999);
?>
<div class="smcw-lbx-image-conatiner">
    <div class="smcw-slider-wrap" data-id="<?php echo intval($id); ?>">
        <?php if (has_post_thumbnail($product_item_id)) {
            ?>
            <div class="smcw-slider-inner-wrap">
                <?php
                echo get_the_post_thumbnail($product_item_id, 'full');
                ?>
            </div>
            <?php
        }
        foreach ($attachment_ids as $attachment_id) {
            $image_link = wp_get_attachment_url($attachment_id, 'full');
            ?>
            <div class="smcw-slider-inner-wrap">
                <img src="<?php echo esc_url($image_link); ?>" alt="">
            </div>
            <?php
        }
        ?>
    </div>
    <?php
    $l = 1;
    if (isset($attachment_id)) {
        ?>
        <div class="smcw-lbx-thumb-wrap">
            <div class="smcw-thumb-slider" data-id="<?php echo intval($id); ?>" id="smcw-pager-<?php echo intval($id); ?>">
                <?php
                if (has_post_thumbnail($product_item_id)) {
                    ?>
                    <div class="smcw-each-thumb">
                        <a data-slide-index="0" href="">
                            <?php
                            echo get_the_post_thumbnail($product_item_id, 'thumbnail');
                            ?>
                        </a>
                    </div>
                    <?php
                }
                foreach ($attachment_ids as $attachment_id) {
                    $image_link = wp_get_attachment_url($attachment_id, 'thumbnail');
                    ?>
                    <div class="smcw-each-thumb">
                        <a data-slide-index="<?php echo intval($l); ?>" href="">
                            <img src="<?php echo esc_url($image_link); ?>" alt="">
                        </a>
                    </div>
                    <?php
                    $l ++;
                }
                ?>
            </div>
        </div>
        <?php
    }
    ?>
</div>