<?php
defined('ABSPATH') or die("No script kiddies please!");
$enable_shopping = isset($smcw_settings['smcw_shopping_button']) ? esc_attr($smcw_settings['smcw_shopping_button']) : '1';
if ($enable_shopping == '1') {
    ?>
    <div class="smcw-button-wrap">
        <?php
        if (isset($smcw_settings['smcw_continue_button_url'])) {
            ?><a href="<?php echo esc_url($smcw_settings['smcw_continue_button_url']); ?>">
            <?php } else {
                ?>
                <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>">
                    <?php
                }
                if (isset($smcw_settings['smcw_continue_button_text'])) {
                    echo esc_attr($smcw_settings['smcw_continue_button_text']);
                } else {
                    esc_html_e('Start shopping', SMCW_TD);
                }
                ?>
                <span class="eleganticons arrow_right"></span></a>
    </div>
    <?php
}
