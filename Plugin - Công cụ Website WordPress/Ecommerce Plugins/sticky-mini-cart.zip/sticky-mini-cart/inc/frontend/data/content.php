<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-items-lightbox-container">
    <div class="smcw-item-image-container">
        <?php include (SMCW_PATH . 'inc/frontend/data/gallery.php'); ?>
    </div>
    <div class="smcw-lbx-content">
        <div class="smcw-item-lbx-title">
            <a href="<?php the_permalink(); ?>" target="_blank">
                <?php the_title(); ?></a>
        </div>
        <div class="smcw-lbx-rating">
            <?php
            woocommerce_template_loop_rating($product_item_id);
            ?>
        </div>
        <div class="smcw-lbx-content">
            <?php echo wp_trim_words(strip_tags(strip_shortcodes(get_the_content())), 100, '...'); ?>
        </div>
        <div class="smcw-lbx-cart">
            <?php
            $_product = wc_get_product($product_item_id);
            if ($_product->is_type('simple')) {
                woocommerce_template_loop_price();
                woocommerce_template_loop_add_to_cart();
            } else {
                woocommerce_variable_add_to_cart();
            }
            ?>
        </div>
    </div>
</div>