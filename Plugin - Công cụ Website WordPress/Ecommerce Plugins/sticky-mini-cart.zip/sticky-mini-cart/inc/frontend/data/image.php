<?php
defined('ABSPATH') or die("No script kiddies please!");
$smcw_settings = get_option('smcw_settings');
?>
<div class="smcw-product-thumb">
    <?php echo apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key ); ?>
</div>
<?php
if (isset($smcw_settings['smcw_display_popup_details']) && $smcw_settings['smcw_display_popup_details'] == '1') {
    ?>
    <div class="smcw-lightbox-wrap">
        <span class="eleganticons icon_search"></span>
    </div>
    <?php
}