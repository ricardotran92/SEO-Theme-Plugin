<?php
defined('ABSPATH') or die("No script kiddies please!");
?>
<div class="smcw-lightbox-loader smcw-nonactive">
    <img src="<?php echo SMCW_IMG_DIR . '/loader/loader-1.gif'; ?>" class="smcw-ajax-loader" style="display:none;"/>
</div>
<div class="smcw-display-popup">
</div>

