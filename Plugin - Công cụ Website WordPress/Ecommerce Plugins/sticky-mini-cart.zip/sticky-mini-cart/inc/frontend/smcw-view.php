<?php
defined('ABSPATH') or die('No script kiddies please!');
$smcw_settings = get_option('smcw_settings');
$enable_floating_button = (isset($atts['enable_floating_button'])) ? $atts['enable_floating_button'] : '';
$floating_cart_position = (isset($atts['floating_cart_position'])) ? $atts['floating_cart_position'] : 'left_center';
$icon = (isset($atts['cart_icon'])) ? $atts['cart_icon'] : 'eleganticons|icon_cart_alt';
$auto_open_cart = (isset($atts['auto_open_cart'])) ? $atts['auto_open_cart'] : '0';
$cart_loader = (isset($atts['cart_loader'])) ? $atts['cart_loader'] : '';
$loader = (isset($atts['loader'])) ? $atts['loader'] : 'loader-1';
$template = (isset($atts['template'])) ? $atts['template'] : 'template-1';
$floating_cart_effect = (isset($atts['floating_cart_effects'])) ? $atts['floating_cart_effects'] : 'fly_image_effects';
$class = ' smcw-position-' . $floating_cart_position;
if ($template == 'template-7' || $template == 'template-10') {
    $temp_class = 'smcw-cart-icons-lightbox';
} else {
    $temp_class = 'smcw-cart-icons';
}
if ($enable_floating_button == 1) {
    include(SMCW_PATH . 'inc/frontend/items-details.php' );
}



