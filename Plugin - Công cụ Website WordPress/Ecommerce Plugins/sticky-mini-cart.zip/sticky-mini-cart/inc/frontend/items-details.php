<?php
defined('ABSPATH') or die("No script kiddies please!");
$count = WC()->cart->cart_contents_count; 
?>
<div class="woocommerce smcw-cart-wrapper smcw-<?php
echo esc_attr($template);
echo esc_attr($class);
?> smcw-effect-main-wrap" data-template="<?php echo esc_attr($template); ?>" data-effect="<?php echo esc_attr($floating_cart_effect); ?>" data-auto-effect="<?php echo esc_attr($auto_open_cart); ?>">
    <div class="smcw-cart-icons">
        <?php
        include(SMCW_PATH . 'inc/frontend/layout/cart-icon.php');
        ?>
    </div>
    <?php if ($floating_cart_effect != 'fly_image_effects') { ?>
        <div class="smcw-ajax-loader smcw-nonactive">
            <img src="<?php echo SMCW_IMG_DIR . '/loader/' . $loader . '.gif'; ?>"/>
        </div>
    <?php } ?>
    <div class="smcw-cart-main-container">
        <div class="smcw-cart-container <?php
        if ($count == 0) {
            echo esc_attr('smcw-empty-wrap');
        }
        ?>">
                 <?php
                 global $woocommerce;
                 if ($template == 'template-6') {
                     $value_class = 'template-3';
                 } else if ($template == 'template-8') {
                     $value_class = 'template-5';
                 } else if ($template == 'template-9') {
                     $value_class = 'template-2';
                 } else if ($template == 'template-10') {
                     $value_class = 'template-7';
                 } else {
                     $value_class = $template;
                 }
                 ?>
            <div class="smcw-cart-items-wrapper smcw-close-effect-<?php echo esc_attr($value_class); ?>">
                <div class="smcw-cart-main-title">
                    <?php
                    if (isset($smcw_settings['smcw_title_text_cart']) && $smcw_settings['smcw_title_text_cart'] != '') {
                        echo esc_attr($smcw_settings['smcw_title_text_cart']);
                    } else {
                        esc_html_e('Your Cart', SMCW_TD);
                    }
                    ?>
                </div>
                <div class="smcw-close-lightbox">
                    <span class="lnr lnr-cross"></span>
                </div>
                <div class="smcw-ajax-inner-loader smcw-nonactive">
                    <?php $link = 'loader/' . $smcw_settings["inner_loader"]; ?>
                    <img src="<?php echo SMCW_IMG_DIR . '/' . $link . '.gif'; ?>"/>
                </div>
                <div class="smcw-cart-details-wrapper">
                    <div class="smcw-detail-box">
                        <?php
                        if ($count != 0) {

                            include(SMCW_PATH . 'inc/frontend/data/mini-action.php');
                        } else {
                            include(SMCW_PATH . 'inc/frontend/layout/empty-action.php');
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>