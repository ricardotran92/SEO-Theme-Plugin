<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body><table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%"><tr><td align="center" valign="top" style="background-color: #f7f7f7; padding: 70px 0;"><table cellpadding="0" cellspacing="0" border="0" width="600" id="tpf_t_builder" class="thwecmf-main-builder" style="max-width: 600px; width: 600px; margin: auto;"><tbody><tr>
<td class="thwecmf-builder-column" style="vertical-align: top; border: 1px solid #dedede; border-radius: 2px; border-top: 1px; border-right: 1px; border-bottom: 1px; border-left: 1px; border-style: solid; border-color: #dedede; background-color: #ffffff;">
												<table class="thwecmf-row thwecmf-block-one-column" id="tpf_1001" data-name="one_column" data-column-count="1" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border: 0px solid transparent; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: transparent; background-color: transparent;"><tbody><tr>
<td class="thwecmf-column-padding thwecmf-col thwecmf-columns" id="tpf_1002" data-name="one_column_one" style="vertical-align: top; box-sizing: border-box; border: 1px dotted #dddddd; word-break: break-word; padding: 10px 10px; width: 100%; text-align: center; padding-top: 48px; padding-right: 48px; padding-bottom: 48px; padding-left: 48px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: #dddddd; background-color: #96588a; min-height: 0px;">
															<table class="thwecmf-block thwecmf-block-text" id="tpf_1016" data-block-name="text" cellspacing="0" cellpadding="0" style='table-layout: fixed; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; margin: 0 auto; box-sizing: border-box; color: #ffffff; font-size: 30px; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: left;'><tbody style="color: #ffffff; font-size: 30px;"><tr style="color: #ffffff; font-size: 30px;">
<td class="thwecmf-block-text-holder" style='vertical-align: top; box-sizing: border-box; width: 100%; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; padding: 15px 15px; color: #ffffff; font-size: 30px; text-align: left; background-color: transparent; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-color: transparent; border-style: none; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;'>
					<div class="wecmf-txt-wrap" style="color: #ffffff; font-size: 30px;">A note has been added to your order<br style="color: #ffffff; font-size: 30px;">
</div>				</td>
			</tr></tbody></table>
</td>
																				</tr></tbody></table>
<table class="thwecmf-row thwecmf-block-one-column" id="tpf_1010" data-name="one_column" data-column-count="1" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border: 0px solid transparent; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: transparent; background-color: transparent;"><tbody><tr>
<td class="thwecmf-column-padding thwecmf-col thwecmf-columns" id="tpf_1011" data-name="one_column_one" style="vertical-align: top; box-sizing: border-box; border: 1px dotted #dddddd; word-break: break-word; padding: 10px 10px; padding-top: 48px; padding-right: 48px; padding-bottom: 0px; padding-left: 48px; width: 100%; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: #dddddd; background-color: transparent; text-align: center; min-height: 0px;">
															<table class="thwecmf-block thwecmf-block-text" id="tpf_1012" data-block-name="text" cellspacing="0" cellpadding="0" style='table-layout: fixed; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; margin: 0 auto; box-sizing: border-box; color: #636363; font-size: 14px; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: left;'><tbody style="color: #636363; font-size: 14px;"><tr style="color: #636363; font-size: 14px;">
<td class="thwecmf-block-text-holder" style='vertical-align: top; box-sizing: border-box; width: 100%; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; padding: 15px 15px; color: #636363; font-size: 14px; text-align: left; background-color: transparent; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-color: transparent; border-style: none; padding-top: 0px; padding-right: 0px; padding-bottom: 10px; padding-left: 0px;'>
<div class="wecmf-txt-wrap" style="color: #636363; font-size: 14px;">Hi <?php if(isset($order)){ echo esc_html($order->get_billing_first_name()); }elseif(isset($user_login)){ echo esc_html($user_login); } ?>,<br style="color: #636363; font-size: 14px;">
</div>
<div class="wecmf-txt-wrap" style="color: #636363; font-size: 14px;"><br style="color: #636363; font-size: 14px;"></div>
<div class="wecmf-txt-wrap" style="color: #636363; font-size: 14px;">The following note has been added to your order: <?php if(isset($customer_note)){ echo "<blockquote>".wpautop( wptexturize( $customer_note ) )."</blockquote>"; } ?> As a reminder, here are your order details:<br style="color: #636363; font-size: 14px;">
</div>
</td>
			</tr></tbody></table>
<?php if(isset($order)){ 
 					do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email ); 
 				}?>
			
			<?php if(isset($order)){ 
  					do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email ); 
  				}?>
					<?php if(isset($order)){ 
  					do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email ); 
  				}?>
				<table class="thwecmf-block thwecmf-block-text" id="tpf_1020" data-block-name="text" cellspacing="0" cellpadding="0" style='table-layout: fixed; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; margin: 0 auto; box-sizing: border-box; color: #636363; font-size: 14px; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: left;'><tbody style="color: #636363; font-size: 14px;"><tr style="color: #636363; font-size: 14px;">
<td class="thwecmf-block-text-holder" style='vertical-align: top; box-sizing: border-box; width: 100%; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; padding: 15px 15px; color: #636363; font-size: 14px; text-align: left; background-color: transparent; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 0px; padding-bottom: 15px; padding-left: 0px;'><div class="wecmf-txt-wrap" style="color: #636363; font-size: 14px;">Thank you for reading.<br style="color: #636363; font-size: 14px;">
</div></td>
			</tr></tbody></table>
</td>
																				</tr></tbody></table>
<table class="thwecmf-row thwecmf-block-one-column" id="tpf_1013" data-name="one_column" data-column-count="1" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border: 0px solid transparent; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: transparent; background-color: transparent;"><tbody><tr>
<td class="thwecmf-column-padding thwecmf-col thwecmf-columns" id="tpf_1014" data-name="one_column_one" style="vertical-align: top; box-sizing: border-box; border: 1px dotted #dddddd; word-break: break-word; padding: 10px 10px; width: 100%; text-align: center; padding-top: 0px; padding-right: 48px; padding-bottom: 48px; padding-left: 48px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-style: none; border-color: #dddddd; background-color: transparent; min-height: 0px;">
															<table class="thwecmf-block thwecmf-block-text" id="tpf_1015" data-block-name="text" cellspacing="0" cellpadding="0" style='table-layout: fixed; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; margin: 0 auto; box-sizing: border-box; color: #636363; font-size: 13px; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: center;'><tbody style="color: #636363; font-size: 13px;"><tr style="color: #636363; font-size: 13px;">
<td class="thwecmf-block-text-holder" style='vertical-align: top; box-sizing: border-box; width: 100%; font-family: "Helvetica Neue",Helvetica,Roboto,Arial,sans-serif; line-height: 22px; padding: 15px 15px; color: #636363; font-size: 13px; text-align: center; background-color: transparent; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 0px; padding-bottom: 15px; padding-left: 0px;'><div class="wecmf-txt-wrap" style="color: #636363; font-size: 13px;"><?php echo esc_html( get_bloginfo() );?><br style="color: #636363; font-size: 13px;">
</div></td>
			</tr></tbody></table>
</td>
																				</tr></tbody></table>
</td>
			</tr></tbody></table></td></tr></table></body>
</html>
