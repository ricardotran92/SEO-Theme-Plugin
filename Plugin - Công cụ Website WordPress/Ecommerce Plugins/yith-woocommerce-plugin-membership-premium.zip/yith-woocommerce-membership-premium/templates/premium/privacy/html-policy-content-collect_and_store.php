<p><?php echo esc_html_x( 'While you visit our site, we’ll track:', 'Privacy Policy Content', 'yith-woocommerce-membership' ) ?></p>
<p><?php echo esc_html_x( 'Information about memberships users belong to.', 'Privacy Policy Content', 'yith-woocommerce-membership' ) ?></p>
<p><?php echo esc_html_x( 'The report of the memberships and the products in them downloaded by the user.', 'Privacy Policy Content', 'yith-woocommerce-membership' ) ?></p>
