<?php
/**
 * Template for Message in FRONTEND
 * @deprecated since 2.3.0
 */

