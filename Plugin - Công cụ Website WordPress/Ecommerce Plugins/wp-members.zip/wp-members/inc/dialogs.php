<?php
/**
 * Included for legacy reasons: backward compatibility with
 * older WP-Members extensions and custom snippets. Those 
 * will actually still work, and there is no front end issue,
 * but removing this file causes a PHP error notice for 
 * certain configurations.
 *
 * Remove later.
 */