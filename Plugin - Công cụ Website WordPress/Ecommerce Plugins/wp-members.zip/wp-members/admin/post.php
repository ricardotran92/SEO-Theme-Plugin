<?php
/**
 * Included for legacy reasons: backward compatibility.
 *
 * Remove later.
 */