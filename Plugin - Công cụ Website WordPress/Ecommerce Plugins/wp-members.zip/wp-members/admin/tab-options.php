<?php
/**
 * Included for legacy reasons: backward compatibility with
 * WP-Members User List 1.9.4 and earlier. Those will actually
 * still function, and there is no front end issue, but removing
 * this file causes a PHP notice in the admin panel.
 *
 * Remove later.
 */