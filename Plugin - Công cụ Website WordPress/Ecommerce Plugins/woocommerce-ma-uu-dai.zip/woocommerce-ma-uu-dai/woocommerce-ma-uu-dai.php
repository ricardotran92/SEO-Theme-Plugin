<?php
/**
 * Plugin Name: Woocommerce mã ưu đãi
 * Plugin URI: #
 * Description: Plugin hiển thị mã ưu đãi. Shortcode: <code>[ma-uu-dai slide_width="25%" slide_width__sm="50%" slide_width__md="33%" slide_item_padding="15px" slide_align="left"]</code>
 * Version: 1.0
 * Author: Thuan Nguyen
 * Author URI: #
 *
 */
add_action( 'init',function(){
    if(!function_exists('WC')) return;
    define('MGG_DIR', plugin_dir_path( __FILE__ ));
    define('MGG_BASENAME', plugin_basename(__FILE__));
    define('MGG_BASENAME_URL', plugin_dir_url(plugin_basename(__FILE__)));
    require plugin_dir_path( __FILE__ )."/shortcode.php";
} );