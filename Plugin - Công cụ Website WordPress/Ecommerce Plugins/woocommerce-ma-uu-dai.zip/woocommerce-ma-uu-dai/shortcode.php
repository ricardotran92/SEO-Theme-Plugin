<?php 
add_shortcode( 'ma-uu-dai', function($atts, $content=null) {
	extract( shortcode_atts( array(
        '_id' => 'slider-'.rand(),
        'timer' => '6000',
        'bullets' => 'true',
        'visibility' => '',
        'class' => '',
        'type' => 'slide',
        'bullet_style' => '',
        'auto_slide' => 'true',
        'auto_height' => 'false',
        'bg_color' => '',
        'slide_align' => 'left',
        'style' => 'normal',
        'slide_width' => '25%',
        'slide_width__md' => '',
        'slide_width__sm' => '',        
        'slide_item_padding'=> '15px',
        'arrows' => 'true',
        'pause_hover' => 'true',
        'hide_nav' => '',
        'nav_style' => 'circle',
        'nav_color' => 'light',
        'nav_size' => 'large',
        'nav_pos' => '',
        'infinitive' => 'true',
        'freescroll' => 'false',
        'parallax' => '0',
        'margin' => '',
        'margin__md' => '',
        'margin__sm' => '',
        'columns' => '1',
        'height' => '',
        'rtl' => 'false',
        'draggable' => 'true',
        'friction' => '0.6',
        'selectedattraction' => '0.1',
        'threshold' => '10',
        'as_nav_for'=> '',        
        'mobile' => 'true',
    ), $atts ) );          
    if($visibility == 'hidden') return;
    if($mobile !==  'true' && !$visibility) {$visibility = 'hide-for-small';}
    ob_start();
    $wrapper_classes = array('slider-wrapper', 'relative', 'adminz_slider_custom');
    if( $class ) $wrapper_classes[] = $class;
    if( $visibility ) $wrapper_classes[] = $visibility;
    $wrapper_classes = implode(" ", $wrapper_classes);
    $classes = array('slider');
    if ($type == 'fade') $classes[] = 'slider-type-'.$type;    
    if($bullet_style) $classes[] = 'slider-nav-dots-'.$bullet_style;    
    if($nav_style) $classes[] = 'slider-nav-'.$nav_style;    
    if($nav_size) $classes[] = 'slider-nav-'.$nav_size;    
    if($nav_color) $classes[] = 'slider-nav-'.$nav_color;    
    if($nav_pos) $classes[] = 'slider-nav-'.$nav_pos;    
    if($auto_slide == 'true') $auto_slide = $timer;    
    if($style) $classes[] = 'slider-style-'.$style;    
    if($hide_nav ==  'true') {$classes[] = 'slider-show-nav';}    
    $is_arrows = 'true';
    $is_bullets = 'true';
    if($arrows == 'false') $is_arrows = 'false';
    if($bullets == 'false') $is_bullets = 'false';
    if(is_rtl()) $rtl = 'true';
    $classes = implode(" ", $classes);    
	$css_args = array(
		'bg_color' => array(
			'attribute' => 'background-color',
			'value'     => $bg_color,
		),
	);
	$args = array(
		'margin' => array(
			'selector' => '',
			'property' => 'margin-bottom',
		)
	);
	$args_respondsive_item = array(
		'slide_width' => array(
			'selector' => '',
			'property' => 'max-width',
			'unit'     => '%',
		),
	);
 	echo ux_builder_element_style_tag( $_id ." .flickity-slider > *", $args_respondsive_item, $atts ); 	
 	?>
 	<style type="text/css"> <?php if($slide_item_padding){ ?> #<?php echo $_id;?> .slider{margin-left:  -<?php echo $slide_item_padding;?>; margin-right:  -<?php echo $slide_item_padding;?>;} #<?php echo $_id;?> .flickity-slider >*{padding-left:  <?php echo $slide_item_padding;?>; padding-right:  <?php echo $slide_item_padding;?>;} <?php } ?> #<?php echo $_id; ?> .slider:not(.flickity-enabled){visibility: hidden; } <?php if($as_nav_for): ?> #<?php echo $_id; ?> .is-selected >* {border:  1px solid var(--secondary-color); margin:  1px; } <?php endif; ?> </style>
 	<div class="<?php echo $wrapper_classes; ?> ma-uu-dai" id="<?php echo $_id; ?>" <?php echo get_shortcode_inline_css($css_args); ?>>
	    <div class="<?php echo $classes; ?>"
	        data-flickity-options='{"cellAlign": "<?php echo $slide_align; ?>","imagesLoaded": true ,"lazyLoad": 1 ,"freeScroll": <?php echo $freescroll; ?> ,"wrapAround": <?php echo $infinitive; ?> ,"autoPlay": <?php echo $auto_slide;?> ,"pauseAutoPlayOnHover" : <?php echo $pause_hover; ?> ,"prevNextButtons": <?php echo $is_arrows; ?> ,"contain" : true ,"adaptiveHeight" : <?php echo $auto_height;?> ,"dragThreshold" : <?php echo $threshold ;?> ,"percentPosition": true ,"pageDots": <?php echo $is_bullets; ?> ,"rightToLeft": <?php echo $rtl; ?> ,"draggable": <?php echo $draggable; ?> ,"selectedAttraction": <?php echo $selectedattraction; ?> ,"parallax" : <?php echo $parallax; ?> ,"friction": <?php echo $friction; ?> ,"groupCells": "<?php echo $slide_width; ?>"<?php if($as_nav_for): ?>,"asNavFor": "<?php echo $as_nav_for ." .slider" ; ?>" <?php endif; ?> }'>
	        <?php 	        
	        $content = '';
            global $current_user, $woocommerce; 
            global $wpdb;
            wp_get_current_user(); 
            $current_user = wp_get_current_user(); 
            $user_id = $current_user->ID; 
            $email = $current_user->user_email;             
            $couponlist = $wpdb->get_results("SELECT {$wpdb->postmeta}.`post_id`
            FROM {$wpdb->postmeta}
            WHERE {$wpdb->postmeta}.`meta_key` LIKE 'customer_email'
            AND {$wpdb->postmeta}.`meta_value` LIKE '%".$email."%'");
            $couponarrayfinal = array( );
            foreach( $couponlist as $key => $row) {
                $value = $row->post_id;
                $couponarrayfinal[] = $value ;
            }
            wp_reset_postdata(); 
            $couponargs = array(
                'post_type' => 'shop_coupon',
                'post__in' => $couponarrayfinal,
                'orderby' => 'date',
                'order' => 'DESC',
                'posts_per_page' => '-1'
            );
            $couponquery = new WP_Query($couponargs);
            if ($couponquery->have_posts()) :
                while($couponquery->have_posts()) :
                    $couponquery->the_post();                    
                    $amount = get_post_meta( get_the_ID(), 'coupon_amount', true ); 
                    $type = get_post_meta( get_the_ID(), 'discount_type', true ); 
                    $used = get_post_meta( get_the_ID(), '_used_by', false);
                    $expiry_date = get_post_meta(get_the_ID(),'date_expires',true);
                    $id = wp_rand();
                    if(!$expiry_date or $expiry_date > current_time('timestamp')):
                        ?>
                        <div class="ma-uu-dai-item">
                            <div class="ma-uu-dai-inner">
                            <h5 class="title uppercase">
                                <span>Nhập mã: </span>
                                <span class="ma_sao_chep"><?php the_title(); ?></span>
                            </h5>
                            <p class="excerpt">
                                <?php echo trim(get_the_excerpt()); ?>
                            </p>
                            <p class="action">
                                <?php                             
                                echo '<a href="#" target="_self" class="button primary lowercase sao_chep" data-ma="'.get_the_title().'">Sao chép</a>';
                                echo do_shortcode('[button text="Điều kiện" letter_case="lowercase" class="button-dieu-kien"  style="simple" link="#lightbox_'.$id.'"]'); 
                                // lightbox content
                                ob_start();
                                ?>
                                <h4 class="uppercase text-center">Nhập mã: <?php the_title(); ?></h4>
                                <div class="intro">Mã khuyến mãi: <span><?php the_title(); ?></span></div>
                                <p class="dieu_kien">
                                    <span class="ma_sao_chep hidden"><?php the_title(); ?></span>
                                    <p>Điều kiện:</p>
                                    <p>
                                        <?php echo trim(get_the_excerpt()); ?>
                                    </p>
                                    <?php echo do_shortcode('[divider width="100%"]'); ?>
                                    <?php 
                                        echo '<a href="#" target="_self" class="button primary lowercase sao_chep" data-ma="'.get_the_title().'">Sao chép</a>';
                                    ?>
                                    <button class="button is-outline white" onClick="jQuery.magnificPopup.close();">Đóng</button>
                                </p>
                                <?php 
                                $lightbox = ob_get_clean();
                                echo do_shortcode('[lightbox id="lightbox_'.$id.'" width="600px" padding="20px"]'.$lightbox.'[/lightbox]');
                                ?>
                            </p>
                        </div>
                        </div>
                    <?php      
                    endif;              
                endwhile; 
            endif;
            wp_reset_postdata();
	        echo do_shortcode($content);
	        ?>
	 	</div>
	 	<div class="loading-spin dark large centered admz"></div>	 	
		<?php echo ux_builder_element_style_tag( $_id, $args, $atts ); ?>        
        <script type="text/javascript">
            jQuery(document).ready(function($){
                $("body").on("click",".sao_chep",function(){
                    var ma_uu_dai = $(this).attr("data-ma");
                    var $temp = $("<input>");
                    $(this).closest("div").append($temp);
                    $temp.val(ma_uu_dai).select();
                    document.execCommand("copy");
                    $temp.remove();
                    $(this).text("Đã chép");
                    $(this).addClass("op-5");
                });
            });
        </script>
	</div>
	<?php	
    $content = ob_get_contents();    
    ob_end_clean();
    return apply_filters('adminz_output_debug',$content);
});